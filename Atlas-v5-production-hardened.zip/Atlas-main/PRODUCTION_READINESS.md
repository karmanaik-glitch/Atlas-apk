# Atlas 5.0 — Production Readiness

## Included
- Dexie schema migration boundary v5
- Backup validation with schema compatibility and SHA-256 integrity checks
- Atomic restore transaction
- 25 MB backup size guard
- React render-error recovery boundary
- Keyboard/focus accessibility baseline
- Reduced-motion support
- CI typecheck + production build gate
- Android debug APK and signed AAB workflows

## Release checklist
- [ ] Configure Android signing secrets in GitHub
- [ ] Add production privacy policy URL
- [ ] Verify Play Console Data Safety declarations
- [ ] Test Android 10–16 on physical devices
- [ ] Test import/export on a fresh install and an upgraded install
- [ ] Test notification permissions and share-to-Atlas
- [ ] Verify adaptive icon and splash assets
- [ ] Create a signed release AAB and upload to Play Console internal testing

## Security note
Atlas remains local-first, but IndexedDB itself should not be described as encrypted storage. Sensitive-data encryption at rest requires a native secure-storage design and should be implemented before positioning biometric lock as a security boundary.
