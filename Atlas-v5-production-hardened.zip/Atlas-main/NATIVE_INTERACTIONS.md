# Atlas Native Interactions

## Android quick capture
- App shortcut: Capture
- Home-screen widget: Capture
- Android Share Sheet: share text into Atlas; Atlas opens Capture prefilled as a note
- Deep link: `atlas://capture`

## Interaction contract
- Native haptic feedback is only enabled on native platforms.
- Web/PWA keeps browser share behavior.
- Android back button is handled by Capacitor App lifecycle.
- Native share payloads are normalized into an Atlas deep link so the React layer stays platform-agnostic.

## Build
Run `npm run android:sync` after dependencies are installed. The sync script patches the generated Android project with the widget, shortcuts, share receiver and deep-link intent filter.
