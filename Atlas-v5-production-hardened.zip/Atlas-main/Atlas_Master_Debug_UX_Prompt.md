# Atlas — Master Debug + UI/UX Enhancement Prompt

## IMPORTANT

You are working on an existing, almost-complete application called **Atlas**.

The application has already been built.

Your job is NOT to blindly rebuild Atlas.

Your job is to:
1. Understand the existing implementation.
2. Find what is broken.
3. Find what is inconsistent.
4. Find what feels unfinished.
5. Fix functional bugs.
6. Improve UI/UX substantially.
7. Improve visual polish.
8. Improve responsiveness.
9. Improve interaction quality.
10. Preserve everything that already works.

The result should feel like a **finished personal product**, not an AI-generated prototype.

---

# 1. USER CONTEXT

The owner of Atlas is:

# Karma Naik

Always address the user as **Karma** when the application needs to greet, personalize, or refer to the owner.

Examples:
- Good morning, Karma.
- Welcome back, Karma.
- Karma's day

Do NOT repeatedly display the name everywhere. Personalization should feel natural and restrained.

---

# 2. YOUR ROLE

Act as a combination of:
- Senior frontend engineer
- Senior product designer
- UX researcher
- Accessibility specialist
- QA engineer
- Performance engineer
- Design-system reviewer

Think critically. Do not assume the existing implementation is correct simply because it renders.

---

# 3. FIRST RULE

## DO NOT START CODING IMMEDIATELY.

First inspect the entire application.

Understand:
- Project structure
- Routes
- Components
- State management
- Database
- IndexedDB schema
- Services
- Hooks
- Utilities
- PWA implementation
- Notification implementation
- Responsive behavior
- Styling system
- Existing design language

Understand how the application currently works before modifying it.

---

# 4. DO NOT REBUILD WITHOUT A REASON

The application is already substantially built.

Do NOT:
- Delete the project
- Replace the architecture
- Rewrite everything
- Replace React
- Replace the database
- Replace the styling system
- Replace working components
- Introduce a backend
- Move to another hosting platform

unless there is a compelling technical reason.

Prefer:

Existing system → Understand → Identify problems → Fix → Refine → Test

NOT:

Existing system → Delete → Rebuild

---

# 5. MASTER OBJECTIVE

Transition Atlas from:

> "Almost working"

to:

> "This feels finished."

The final product should feel:
- Cohesive
- Reliable
- Fast
- Personal
- Premium
- Calm
- Intuitive
- Thoughtful
- Consistent
- Delightful without being gimmicky

---

# 6. DEBUGGING PHASE

Perform a systematic debugging audit.

Check for:
- Buttons that do nothing
- Forms that fail silently
- Broken navigation
- Incorrect routes
- Incorrect state updates
- Stale UI
- Duplicate records
- Records not persisting
- Records disappearing after refresh
- Incorrect calculations
- Broken filtering
- Broken sorting
- Broken search
- Incorrect dates/times
- Recurrence bugs
- Reminder bugs
- Notification bugs
- Import/export failures
- PWA failures
- Offline failures
- Modal/drawer/dropdown bugs
- Keyboard issues

Fix actual problems rather than hiding them.

---

# 7. CONSOLE AUDIT

Check for:
- JavaScript errors
- React errors
- Warnings
- Failed promises
- Unhandled exceptions
- Failed network requests
- Invalid DOM nesting
- Accessibility warnings
- IndexedDB errors
- Service worker errors

The production console should be clean.

Do not simply suppress warnings. Find the underlying cause.

---

# 8. DATA INTEGRITY AUDIT

Pay special attention to IndexedDB.

Verify:

Create → Save → Refresh → Still exists

Test:
- Create
- Edit
- Complete
- Delete
- Restore

Check whether related data remains consistent.

Example: deleting an expense must update monthly totals, category totals, charts, activity, and relevant insights.

---

# 9. DATE/TIME AUDIT

Check:
- Today's date
- Due dates
- Reminder dates
- Recurring items
- Midnight transitions
- Local timezone
- Date formatting
- Relative dates
- Today
- Tomorrow
- Overdue

Do not assume browser date handling is correct.

---

# 10. RESPONSIVE AUDIT

Test at:
- 320px
- 375px
- 390px
- 430px
- 768px
- 1024px
- 1280px
- 1440px
- 1920px

Look for:
- Overflow
- Broken layouts
- Tiny controls
- Unusable tables
- Horizontal scrolling
- Bad modal sizing
- Navigation problems
- Text clipping
- Cards becoming too tall
- Buttons becoming inaccessible
- Charts overflowing
- Excessive whitespace
- Poor mobile hierarchy

Do not merely shrink desktop UI.

---

# 11. MOBILE UX

Mobile should not feel like a broken desktop version.

Check:
- Touch target size
- Bottom navigation
- Quick actions
- Forms
- Keyboard behavior
- Modal behavior
- Scrolling
- Sticky controls
- Date/time inputs
- Swipe interactions where appropriate

Keep interactions simple.

---

# 12. VISUAL AUDIT

Critically evaluate the interface.

## Typography
Check:
- Font hierarchy
- Font sizes
- Weight
- Line height
- Letter spacing
- Number readability
- Heading consistency

Avoid too many font sizes.

## Spacing
Create a consistent rhythm, e.g. 4 / 8 / 12 / 16 / 24 / 32 / 48 / 64.

## Color
Avoid excessive colors, rainbow dashboards, excessive gradients, neon accents, and decorative color usage.

Color should communicate meaning.

## Components
Audit:
- Buttons
- Inputs
- Selects
- Cards
- Modals
- Drawers
- Dropdowns
- Tabs
- Badges
- Tooltips
- Empty states
- Toasts

Similar functions should look and behave similarly.

---

# 13. DESIGN SYSTEM

Create or refine a coherent Atlas design system.

Define consistent:
- Colors
- Typography
- Radius
- Shadows
- Borders
- Spacing
- Motion
- Icons
- Interaction states

The application should look like one product, not different developers built different screens.

---

# 14. NAVIGATION AUDIT

Ask:

> Can Karma understand where he is?

The user should always have a clear sense of:
- Current location
- Available sections
- Current context
- How to go back

Avoid unnecessary navigation complexity.

---

# 15. GLANCE AUDIT

Glance is the most important screen.

Its question is:

# "What matters right now?"

Prioritize:
1. Urgent
2. Today
3. Upcoming
4. Important
5. Context

Do not turn Glance into a wall of cards.

---

# 16. COGNITIVE LOAD

For every screen ask:

> What is Karma supposed to do here?

If unclear:
- Simplify
- Group
- Remove
- Reorder
- Rename
- Improve hierarchy

Do not add more UI to compensate for confusing UI.

---

# 17. EMPTY, LOADING, AND ERROR STATES

Empty states should explain what to do next.

Loading states should avoid blank screens but should not show unnecessary spinners for instant local operations.

Never expose technical errors such as:
`DexieError: ConstraintError`

Use human language such as:
`Something went wrong while saving this. Try again.`

---

# 18. FEEDBACK

Every important action should have subtle feedback:
- Task completed
- Expense saved
- Habit logged
- Item deleted
- Backup exported
- Backup restored

Use toasts, inline confirmation, state changes, or microanimations appropriately.

Do not spam notifications.

---

# 19. BUTTON QUALITY

Every button should answer:

> What will happen if I click this?

Prefer:
- Add expense
- Complete task
- Export backup
- Create reminder

Avoid vague labels such as:
- Manage
- Process
- Continue
- Action

---

# 20. FORM UX

Forms should be fast.

Use:
- Sensible defaults
- Autofocus when appropriate
- Correct input types
- Validation
- Clear labels
- Helpful placeholders
- Inline errors
- Keyboard-friendly flow

Do not make users fill information Atlas can reasonably infer locally.

---

# 21. QUICK ACTIONS

Identify the most frequent actions:
- Add task
- Add expense
- Add note
- Log habit
- Set reminder

Make them extremely easy to reach.

---

# 22. SEARCH

Search should feel instant.

Check:
- Search across relevant entities
- Empty query state
- No-results state
- Keyboard shortcut
- Result grouping
- Highlighting
- Navigation to result

---

# 23. KEYBOARD UX

Useful shortcuts may include:
- `/` → Search
- `N` → New item
- `Esc` → Close modal
- `Enter` → Confirm
- `?` → Show shortcuts

Only introduce shortcuts if genuinely useful. The app must remain usable without them.

---

# 24. ACCESSIBILITY AUDIT

Check:
- Semantic HTML
- Labels
- Focus order
- Keyboard navigation
- Focus visibility
- Contrast
- ARIA usage
- Screen reader behavior
- Reduced motion
- Form errors

Prefer semantic HTML over unnecessary ARIA.

---

# 25. MOTION DESIGN

Animation should communicate state, hierarchy, direction, or completion.

Avoid:
- Constant movement
- Bouncy UI
- Excessive transitions
- Long animations
- Decorative animations

Motion should feel calm.

---

# 26. DARK MODE

Audit every component in dark mode:
- Contrast
- Borders
- Shadows
- Cards
- Inputs
- Charts
- Modals
- Dropdowns
- Disabled states
- Empty states

No component should look like an afterthought.

---

# 27. PWA / OFFLINE / NOTIFICATIONS

Verify:
- Manifest
- Icons
- Service worker
- Installability
- Offline shell
- Cache behavior
- Update behavior

Atlas is deployed as a static GitHub Pages application.

Therefore:

> Do NOT pretend that server-side background scheduling exists.

Browser notifications, service workers, and local scheduling are subject to browser/OS limitations. Communicate those limitations honestly.

---

# 28. PERFORMANCE

Look for:
- Unnecessary re-renders
- Large dependencies
- Huge bundles
- Repeated database queries
- Unoptimized images
- Blocking work
- Expensive calculations
- Poor list rendering

Optimize actual bottlenecks rather than prematurely optimizing.

---

# 29. BACKUP / RESTORE

Test:

Create realistic dataset → Export → Clear database → Import → Verify every entity

Check:
- Versioning
- Validation
- Corrupt backup handling
- Duplicate handling
- Migration compatibility

Treat backup/restore as a critical feature.

---

# 30. SECURITY

Check:
- No unnecessary external requests
- No analytics
- No tracking pixels
- No exposed secrets
- No API keys committed to source
- No unsafe HTML rendering
- No obvious XSS paths
- No sensitive data unnecessarily transmitted

Never place secret API keys in frontend code.

---

# 31. NO FEATURE CREEP

Do NOT invent 50 new features.

Prioritize:
1. Broken things
2. Confusing things
3. Inconsistent things
4. Unfinished things
5. High-value UX improvements
6. Only then small enhancements

---

# 32. PRIORITIZATION

Classify issues:

### P0 — Broken
Prevents normal use.

### P1 — Serious
Major UX or data problem.

### P2 — Important
Noticeable quality issue.

### P3 — Polish
Small refinement.

Fix in that order.

---

# 33. DO NOT OVERENGINEER

This is a personal application.

Do not introduce enterprise architecture or unnecessary:
- Abstractions
- Services
- Providers
- Dependency layers
- State machines
- Frameworks
- APIs
- Infrastructure

Complexity must earn its place.

---

# 34. DEPENDENCY RULE

Before adding a dependency ask:
- Can this be done cleanly with what already exists?
- Is it necessary?
- Does it significantly increase bundle size?
- Does it create a security concern?
- Does it work with GitHub Pages?
- Does it remain free?

If not clearly beneficial, do not add it.

---

# 35. FREE-FIRST RULE

Atlas must remain:

# ₹0/month

Do not introduce paid:
- APIs
- Infrastructure
- Databases
- AI services
- Notification services
- Analytics
- OCR services

without explicit approval.

---

# 36. AI USAGE

Do not add AI for cosmetic reasons.

AI is appropriate only when it provides a meaningful capability.

Atlas must remain fully useful without AI.

---

# 37. REMOVE PLACEHOLDERS AND DEAD UI

Search for:
- TODO
- FIXME
- Coming soon
- Lorem ipsum
- Sample text
- Test
- Demo
- Placeholder

Find:
- Buttons with no action
- Dead navigation
- Empty menu items
- Fake toggles
- Non-functional filters
- Decorative controls
- Placeholder modals

Either implement them or remove them.

Never leave fake functionality.

---

# 38. FEATURE COMPLETENESS

For every visible feature ask:

Can I create it?
Can I view it?
Can I edit it?
Can I delete it?
Does it persist?
Does it update related views?
Does it handle empty state?
Does it handle errors?
Does it work on mobile?
Does it work in dark mode?

If not, fix it or hide the feature until ready.

---

# 39. DATA RELATIONSHIPS

Audit relationships between:
- Tasks
- Goals
- Habits
- Expenses
- Budgets
- Subscriptions
- Documents
- Assets
- Activity
- Notifications
- Automations

Do not allow orphaned or inconsistent records.

---

# 40. FINAL VISUAL STANDARD

Compare the whole application against a high-quality modern consumer product.

Ask:

> Would Karma feel embarrassed to show this?

If yes, keep improving.

Ask:

> Does this feel like a coherent product or a collection of generated screens?

If it feels like generated screens, fix the design system and interaction consistency.

---

# 41. FINAL QA PASS

After changes, perform a full regression pass.

## Navigation
- Every route
- Back navigation
- Deep links
- Refresh

## Tasks
- Create
- Edit
- Complete
- Delete
- Recurrence

## Habits
- Create
- Log
- History
- Streaks

## Finance
- Add
- Edit
- Delete
- Categories
- Totals
- Budgets

## Notes
- Create
- Edit
- Search
- Archive

## Reminders
- Create
- Edit
- Delete
- Notification permissions

## Backup
- Export
- Clear
- Import
- Verify

## Search
- Search
- Filter
- Open result

## PWA
- Install
- Offline
- Reload
- Update

## Themes
- Light
- Dark
- System

## Responsive
- Mobile
- Tablet
- Desktop

---

# 42. DO NOT STOP AFTER THE FIRST FIX

Finding one bug does not mean the audit is complete.

Continue until:
- Critical bugs are resolved
- Major UX problems are resolved
- Obvious inconsistencies are resolved
- Major responsive problems are resolved
- Core flows work
- The application feels coherent

---

# 43. CHANGE REPORT

After implementation, provide:

ATLAS QA + UX PASS

Fixed:
- ...

Improved:
- ...

Performance:
- ...

Accessibility:
- ...

Responsive:
- ...

Remaining:
- ...

Do not claim something was fixed if you did not verify it.

---

# 44. AMBIGUITY RULE

When something is ambiguous:

Do NOT invent a large new feature.

Prefer the smallest implementation consistent with Atlas.

If a decision could materially change the architecture, explain it before proceeding.

---

# 45. FINAL INSTRUCTION

You are not here to make Atlas look "busy".

You are here to make it feel:

# Finished.

Every screen should feel intentional.

Every interaction should make sense.

Every piece of data should behave correctly.

Every button should work.

Every important state should be handled.

Every screen should feel like it belongs to the same product.

The final result should make Karma think:

> **"Yes. This is actually something I would use every day."**

---

# START NOW

### STEP 1
Inspect the entire repository.

### STEP 2
Run the application.

### STEP 3
Inspect the browser console.

### STEP 4
Test the major user flows.

### STEP 5
Create an internal prioritized issue list.

### STEP 6
Fix P0 issues.

### STEP 7
Fix P1 issues.

### STEP 8
Improve P2 UX issues.

### STEP 9
Apply visual/design-system improvements.

### STEP 10
Perform responsive + accessibility + dark-mode audits.

### STEP 11
Run the full regression test.

### STEP 12
Only then consider P3 polish.

Do not skip directly to visual polish while core functionality is broken.

---

# NORTH STAR

> **Atlas should disappear into Karma's life.**
>
> It should not demand attention.
>
> It should reduce the amount of remembering, organizing, checking, and thinking he has to do.
>
> **Quietly useful beats loudly impressive.**
