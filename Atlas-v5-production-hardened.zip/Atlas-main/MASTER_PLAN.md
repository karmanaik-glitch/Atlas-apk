# PROJECT ATLAS
## Master Product & Engineering Specification
### Version 1.0 — Single Source of Truth

> **This document is the authoritative specification for Project Atlas.**
> Any AI coding agent, IDE, developer, or future contributor working on Atlas must read and follow this document before making changes.

---

# 0. NON-NEGOTIABLE PRODUCT DEFINITION

**Atlas is a personal-use, browser-based, private life-management application.**

Atlas is:

- Personal
- Web-only
- Local-first
- Free to operate
- Button/form driven
- Offline-capable
- Designed primarily for one person
- Deployable through GitHub Pages
- Designed without a mandatory backend

Atlas is **NOT**:

- An enterprise SaaS product
- A team collaboration tool
- A social platform
- A generic AI chatbot
- A command-line assistant
- A medical/scientific application
- A productivity platform for organizations
- A cloud-first data platform
- A subscription service

The goal is not to build the largest possible application.

The goal is to build a **small personal operating system that genuinely makes life easier.**

---

# 1. PRODUCT PHILOSOPHY

## Personal First

Atlas is designed for one person.

Do NOT introduce:

- Teams
- Organizations
- Roles
- Permissions
- Admin dashboards
- Multi-tenancy
- Enterprise billing
- Collaboration systems
- Organization-level analytics

unless explicitly requested later.

The application should feel:

- Personal
- Calm
- Private
- Intelligent
- Useful
- Fast
- Intentional

It should NOT feel like enterprise software.

---

# 2. INTERACTION PHILOSOPHY

## NO COMMAND-BASED UX

The user should never need to learn commands.

Do NOT design interactions such as:

```text
/add task
/expense 500 food
/remind tomorrow
```

Instead use:

- Buttons
- Forms
- Cards
- Toggles
- Checkboxes
- Dropdowns
- Selectors
- Date pickers
- Time pickers
- Context menus
- Quick actions
- Drag and drop where useful
- Search
- Optional voice input

The UI should make the available actions obvious.

---

# 3. CORE PRODUCT PRINCIPLE

Atlas exists to solve five problems.

### Remember

> Don't make me remember this.

### Organize

> Put this somewhere useful.

### Understand

> Show me what's happening.

### Act

> Let me do this quickly.

### Anticipate

> Tell me before I need to worry about it.

---

# 4. PLATFORM

Atlas must be:

- A web application
- Desktop-first but responsive
- Usable on mobile browsers
- Installable as a PWA
- Capable of working offline
- Deployable on GitHub Pages

There must be no dependency on a native mobile application.

---

# 5. COST REQUIREMENT

## HARD REQUIREMENT

Atlas must cost:

# ₹0/month

The application must be designed so that the core product can operate completely free.

Avoid mandatory:

- Paid APIs
- Paid AI APIs
- Paid databases
- Paid hosting
- Paid notification services
- Paid OCR
- Paid speech APIs
- Paid analytics
- Paid authentication systems

Free tiers may be used only when they are genuinely sufficient for personal usage.

The application must never silently create an infrastructure bill.

---

# 6. HOSTING

## Primary deployment

**GitHub Pages**

There must be:

- No mandatory backend
- No mandatory server
- No mandatory cloud database
- No dependency on Vercel
- No server-side cron system

The application should function as a static web application.

---

# 7. MASTER ARCHITECTURE

```text
                         ATLAS
                           │
                     GitHub Pages
                           │
                  React + TypeScript
                           │
                         Vite
                           │
          ┌────────────────┼────────────────┐
          │                │                │
        UI Layer       Domain Logic      Storage
          │                │                │
       React          Atlas Services    Dexie.js
          │                │                │
       Zustand       Business Rules    IndexedDB
          │                │
          └────────────────┘
                           │
                    Browser APIs
                           │
        ┌──────────────────┼──────────────────┐
        │                  │                  │
  Notifications        Service Worker       PWA
        │                  │
     Microphone        Offline Cache
```

---

# 8. TECHNOLOGY STACK

## Frontend

- React
- TypeScript
- Vite

## Styling

- Tailwind CSS
- Custom Atlas design system
- shadcn/ui where useful

Do not blindly use every shadcn component.

Use only what improves the product.

## Icons

- Lucide

## State Management

- Zustand

Do not put all application state into one enormous global store.

Prefer feature/domain-specific state.

## Database

- IndexedDB
- Dexie.js

## Forms

- React Hook Form
- Zod

## Charts

- Recharts

Only use charts where they communicate something useful.

## PWA

- Service Worker
- Web App Manifest
- Offline caching

## Notifications

- Web Notifications API
- Service Worker capabilities where supported

## Voice

Initially:

- Browser microphone APIs
- Browser speech capabilities where available

Future:

- Local speech models

---

# 9. DATA ARCHITECTURE

Atlas should maintain structured local data.

Suggested entities:

```text
tasks
habits
habitRecords
expenses
categories
notes
reminders
calendarEvents
goals
shoppingItems
subscriptions
assets
documents
waitingItems
notifications
automations
activity
settings
```

The exact schema may evolve.

However:

> **Database schemas must always be versioned.**

Never casually modify an existing schema.

Use Dexie migrations.

---

# 10. DATA OWNERSHIP

The user's data belongs to the user.

Atlas should:

- Store data locally
- Avoid unnecessary transmission
- Avoid third-party tracking
- Avoid advertising SDKs
- Avoid unnecessary telemetry

No data should leave the user's browser unless explicitly required for a feature.

---

# 11. BACKUP SYSTEM

Backup is a core feature.

Local browser storage can disappear.

Therefore Atlas must provide:

```text
Settings
   ↓
Data
   ├── Export Atlas
   └── Import Atlas
```

Export should contain all important user-created information.

Example:

```json
{
  "atlasVersion": "1.0",
  "schemaVersion": 1,
  "exportedAt": "...",
  "data": {}
}
```

Filename:

```text
atlas-backup-YYYY-MM-DD.json
```

---

# 12. ENCRYPTED BACKUPS

Optional future feature.

After basic backup/restore is reliable:

- Allow encrypted backups
- Use client-side encryption
- Never store the user's backup password

This is NOT a V1 blocker.

---

# 13. INFORMATION ARCHITECTURE

Primary navigation:

```text
GLANCE
CAPTURE
TASKS
LIFE
MONEY
```

Secondary:

```text
Search
Activity
Insights
Automations
Settings
```

Do not expose every feature as a primary navigation item.

---

# 14. GLANCE

Glance is the Atlas home screen.

Its purpose:

# "What matters right now?"

Potential sections:

- Greeting
- Today's tasks
- Next event
- Reminders
- Habits
- Spending
- Weather
- Important item
- Quick actions

Do NOT attempt to show every piece of information.

Glance should reduce cognitive load.

---

# 15. CAPTURE

Capture is the central quick-add mechanism.

Possible types:

```text
Task
Expense
Note
Reminder
Shopping Item
Event
Goal
```

The user should be able to select the type and fill in a simple form.

Optional voice:

```text
Speech
   ↓
Structured form
   ↓
User confirmation
   ↓
Save
```

Never silently create important records from ambiguous speech.

---

# 16. TASKS

Tasks should support:

- Title
- Description
- Due date
- Due time
- Priority
- Category
- Status
- Recurrence
- Reminder
- Created date
- Completed date

Views:

```text
Inbox
Today
Upcoming
Overdue
Completed
```

Actions:

```text
Complete
Edit
Postpone
Delete
Snooze
Convert to recurring
```

---

# 17. HABITS

Habits represent recurring behaviors.

Support:

- Daily schedules
- Weekly schedules
- Completion tracking
- Streaks
- Calendar history
- Completion percentage
- Missed days

Avoid excessive gamification.

Atlas should help the user maintain habits, not turn life into a game.

---

# 18. FINANCE

Finance should make expense tracking extremely frictionless.

Expense fields:

```text
Amount
Category
Date
Merchant
Note
Payment Method
Receipt
```

Categories should be customizable.

---

# 19. FINANCE DASHBOARD

Example:

```text
THIS MONTH

₹32,480 SPENT

Food             ₹8,200
Transport        ₹4,500
Shopping         ₹7,100
Bills            ₹9,300
Other            ₹3,380
```

Charts must answer questions.

Do not create charts merely because charts look impressive.

---

# 20. BUDGETS

Allow optional category budgets.

Example:

```text
Food

Budget: ₹10,000
Spent:  ₹8,200

82%
```

Allow warning thresholds.

Example:

```text
Notify when:
80%
90%
100%
```

---

# 21. SUBSCRIPTIONS

Track recurring payments.

Fields:

```text
Name
Amount
Frequency
Next Payment
Category
Reminder
Active / Inactive
```

---

# 22. NOTES

Atlas should support lightweight notes.

Fields:

```text
Title
Content
Tags
Created
Modified
Archived
```

Do NOT turn Atlas into Notion.

The notes feature should remain intentionally simple.

---

# 23. UNIVERSAL SEARCH

Search should work across:

- Tasks
- Notes
- Expenses
- Assets
- Documents
- Activity

Search must be:

- Fast
- Local
- Simple

---

# 24. CALENDAR / AGENDA

Provide a chronological view combining:

- Calendar events
- Tasks
- Habits
- Reminders

The goal is not to compete with dedicated calendar applications.

Atlas should provide a useful personal timeline.

---

# 25. GOALS

Goals represent longer-term objectives.

Connect goals to:

- Tasks
- Habits
- Milestones

Display:

```text
Goal
Progress
Milestones
Related actions
```

---

# 26. WAITING FOR

A dedicated place for things that depend on someone/something else.

Examples:

```text
Contractor quotation
Refund
Email reply
Delivery
Application response
Repair
```

Allow tracking:

```text
Item
Person / Source
Date requested
Expected date
Status
Notes
```

Atlas may highlight things that have been waiting unusually long.

---

# 27. SHOPPING

Shopping should be separate from normal tasks.

Support:

- Item
- Quantity
- Category
- Purchased state
- Recurring item
- Optional price

---

# 28. ASSETS / THINGS

Track personal possessions.

Examples:

```text
Laptop
Phone
Camera
Headphones
Appliance
Furniture
```

Potential fields:

```text
Name
Purchase Date
Purchase Price
Warranty
Serial Number
Notes
Documents
Service History
```

---

# 29. DOCUMENTS

Track important documents.

Examples:

```text
Insurance
Warranty
Certificate
ID
Receipt
Contract
```

Support:

```text
Issue Date
Expiry Date
Attachment / Reference
Reminder
Notes
```

---

# 30. RECEIPTS

Future workflow:

```text
Receipt
   ↓
OCR
   ↓
Merchant
Amount
Date
   ↓
Expense Form
   ↓
User Confirmation
   ↓
Save
```

OCR is not a V1 requirement.

---

# 31. ACTIVITY TIMELINE

Atlas should maintain a chronological activity history.

Examples:

```text
Expense added
Task completed
Habit completed
Event created
Budget threshold reached
Reminder triggered
```

Activity should be useful for understanding what happened.

---

# 32. INSIGHTS

Insights should primarily use deterministic calculations.

Examples:

```text
Monthly spending
Habit completion
Task completion
Budget usage
Subscription totals
Goal progress
```

Do NOT use AI to generate obvious statistics.

---

# 33. AUTOMATIONS

Automations must be visual.

Never require commands.

Model:

```text
TRIGGER
   ↓
CONDITION
   ↓
ACTION
```

Example:

```text
Every Friday at 7 PM
        ↓
       —
        ↓
Remind me to review spending
```

Another:

```text
Food budget reaches 80%
        ↓
Notify me
```

---

# 34. NOTIFICATIONS

Potential notification types:

- Task reminders
- Habit reminders
- Budget alerts
- Recurring reminders
- Document expiry
- Waiting-for reminders
- Morning briefing
- Evening summary

Allow users to enable/disable categories.

---

# 35. IMPORTANT NOTIFICATION LIMITATION

Because Atlas is deployed as a static application through GitHub Pages:

> Guaranteed server-side background scheduling is NOT available.

Do not pretend otherwise.

Atlas can use:

- Browser notifications
- Service workers
- Local scheduling where supported
- In-app notifications

But browser/OS behavior varies.

The UI must communicate this honestly where relevant.

---

# 36. MORNING BRIEFING

Generate locally from Atlas data.

Possible content:

```text
Good morning.

Today:
3 tasks
2 habits
1 event

Money:
₹1,240 spent this week

Important:
Insurance expires in 14 days
```

Keep it concise.

---

# 37. WEATHER

Weather is optional.

Requirements:

- Free API
- Manual location configuration
- Minimal location exposure
- Atlas must continue functioning if weather is unavailable

Weather must never become a core dependency.

---

# 38. VOICE

Voice is optional.

It must NOT become a command language.

Correct:

```text
User speaks
     ↓
Atlas understands intent
     ↓
Structured form appears
     ↓
User confirms
     ↓
Atlas saves
```

Incorrect:

```text
User must memorize special voice syntax
```

---

# 39. DESIGN SYSTEM

Atlas should feel:

- Calm
- Premium
- Personal
- Fast
- Intentional

Avoid:

- Visual noise
- Excessive gradients
- Excessive glassmorphism
- Dashboard overload
- Decorative charts
- Meaningless animations
- Excessive rounded cards
- Generic "AI app" aesthetics

---

# 40. VISUAL LANGUAGE

Prioritize:

- Strong typography
- Clear hierarchy
- Generous spacing
- Restrained colors
- Subtle borders
- Soft surfaces
- Meaningful accent color
- Purposeful animation
- Excellent empty states
- Excellent loading states
- Excellent error states

Every visual element should have a reason to exist.

---

# 41. RESPONSIVE DESIGN

Desktop is primary.

Tablet:

- Condensed navigation
- Adaptive layouts

Mobile:

- Responsive cards
- Compact navigation
- Bottom navigation where appropriate
- Touch-friendly controls

Do NOT build a separate mobile product.

---

# 42. DARK MODE

Support:

```text
Light
Dark
System
```

Persist the user's choice locally.

---

# 43. ACCESSIBILITY

Atlas must support:

- Keyboard navigation
- Visible focus states
- Semantic HTML
- Accessible labels
- Adequate contrast
- Screen reader compatibility
- Reduced-motion preference

Accessibility is not a later polish task.

---

# 44. UX RULES

### Rule 1

Never make the user remember syntax.

### Rule 2

Never hide the primary action.

### Rule 3

Never make a simple action require unnecessary screens.

### Rule 4

Destructive actions require confirmation.

### Rule 5

Saving should feel immediate.

### Rule 6

Every action should provide feedback.

### Rule 7

Empty states should explain what to do next.

### Rule 8

Glance should never become overwhelming.

---

# 45. ERROR HANDLING

Normal users should never see raw technical errors.

Bad:

```text
DexieError: ConstraintError...
```

Good:

```text
Atlas couldn't save that item.

Try again.
```

Provide diagnostics only when useful.

---

# 46. VALIDATION

Use Zod for data validation.

Validate at application boundaries.

Never assume IndexedDB contains valid data.

---

# 47. DATA INTEGRITY

Correctness is more important than cleverness.

Examples:

Deleting an expense must not corrupt totals.

Completing a habit must not create duplicate records.

Recurring tasks must behave deterministically.

Budget calculations must remain accurate.

---

# 48. TIME HANDLING

Time is a critical domain concern.

Be careful with:

- Local timezone
- Date-only values
- Timestamps
- Midnight
- Recurring events
- Recurring tasks
- Daylight-saving transitions

Use explicit date/time handling.

---

# 49. ARCHITECTURE PRINCIPLE

Keep UI separate from business logic.

Prefer:

```text
UI
 ↓
Atlas Service
 ↓
Domain Logic
 ↓
Repository
 ↓
Dexie
 ↓
IndexedDB
```

Do NOT put complex business logic directly inside React components.

---

# 50. RECOMMENDED PROJECT STRUCTURE

```text
src/
│
├── components/
│
├── pages/
│
├── features/
│   ├── tasks/
│   ├── habits/
│   ├── finance/
│   ├── notes/
│   ├── goals/
│   └── reminders/
│
├── core/
│   ├── domain/
│   ├── services/
│   ├── rules/
│   └── events/
│
├── db/
│   ├── schema/
│   ├── migrations/
│   └── repositories/
│
├── hooks/
│
├── stores/
│
├── lib/
│
└── types/
```

This structure may evolve, but maintain separation of concerns.

---

# 51. DOMAIN EVENTS

Useful events may include:

```text
TASK_CREATED
TASK_COMPLETED
HABIT_COMPLETED
EXPENSE_ADDED
BUDGET_THRESHOLD_REACHED
REMINDER_DUE
DOCUMENT_EXPIRING
```

Domain events can feed:

- Activity
- Notifications
- Insights
- Automations

This keeps features decoupled.

---

# 52. FEATURE PRIORITY

## V1 — CORE

Build first:

### Foundation

- React
- TypeScript
- Vite
- PWA
- IndexedDB
- Dexie
- Design system
- Settings

### Core Modules

- Glance
- Tasks
- Habits
- Finance
- Capture
- Reminders
- Activity
- Search
- Backup / Restore

### UX

- Responsive
- Dark mode
- Keyboard support
- Command-free interaction

---

# 53. V1.1

Add:

- Calendar
- Goals
- Budgets
- Subscriptions
- Shopping
- Notifications
- Morning briefing
- Weather
- Basic voice capture

---

# 54. V1.2

Add:

- Waiting For
- Assets
- Documents
- Receipt attachments
- Better analytics
- Automation builder
- Encrypted backups

---

# 55. V2

Potential future features:

- OCR
- Local speech model
- Advanced personal analytics
- Richer automation
- Stronger local encryption
- Free synchronization mechanism if a viable option exists

---

# 56. FEATURES TO AVOID

Do NOT add these unless explicitly requested:

- Social feeds
- Chat
- Collaboration
- Team accounts
- Enterprise billing
- Advertisements
- Cryptocurrency
- Excessive gamification
- Complex project management
- Unnecessary integrations
- Paid infrastructure
- AI chatbot just for the sake of having AI

---

# 57. AI POLICY

AI is NOT the foundation of Atlas.

AI may eventually assist with:

- Natural-language capture
- Categorization
- Summarization
- OCR cleanup
- Optional recommendations

But:

> **Atlas must remain useful without AI.**

---

# 58. NO AI DEPENDENCY

These must work without an AI API:

- Task creation
- Task completion
- Habit tracking
- Expense tracking
- Budgeting
- Notes
- Reminders
- Calendar
- Search
- Backup
- Analytics
- Settings

---

# 59. SECURITY

Atlas should use:

- HTTPS when deployed
- Local storage
- No unnecessary third-party tracking
- No advertising SDKs
- No analytics by default
- No unnecessary data transmission

---

# 60. ANALYTICS

Default:

# NONE

Do not install:

- Google Analytics
- Mixpanel
- Hotjar
- Tracking pixels
- Advertising identifiers

unless explicitly requested.

---

# 61. PERFORMANCE TARGETS

Atlas should feel immediate.

Targets:

- Fast initial load
- Near-instant navigation
- Immediate task completion
- Immediate expense creation
- Fast local search
- Fast dashboard rendering
- Small bundle where practical

Avoid unnecessary dependencies.

---

# 62. OFFLINE-FIRST

The application shell should work offline.

Existing data should remain accessible offline.

Core operations should work offline:

- View tasks
- Create tasks
- Complete tasks
- Add expenses
- Complete habits
- Edit notes
- Search local data

---

# 63. PWA

Include:

- Web manifest
- Service worker
- App icons
- Offline caching
- Install metadata

The PWA should feel like an application rather than merely a website.

---

# 64. TESTING

Testing should cover:

### Unit

Business logic.

### Integration

IndexedDB/repository operations.

### UI

Critical user flows.

Critical flows:

```text
Create task
Complete task

Create habit
Complete habit

Add expense
Edit expense
Delete expense

Create reminder

Export data
Import data

Search

Change theme
```

---

# 65. MIGRATION TESTING

Before changing database schema:

1. Create representative old data.
2. Apply migration.
3. Verify records.
4. Verify relationships.
5. Verify calculations.
6. Verify export.
7. Verify import.

Never assume migrations work.

---

# 66. BACKUP TESTING

Test:

```text
Create data
   ↓
Export
   ↓
Clear database
   ↓
Import
   ↓
Verify
```

All important data must survive the round trip.

---

# 67. AI IDE DEVELOPMENT RULES

Every AI coding agent must follow these rules.

## Rule 1

Read `MASTER_PLAN.md` before modifying Atlas.

## Rule 2

Inspect the existing code before making changes.

## Rule 3

Do not rewrite working architecture without a strong reason.

## Rule 4

Do not introduce a dependency without justification.

## Rule 5

Do not introduce paid services.

## Rule 6

Do not introduce a backend unless explicitly approved.

## Rule 7

Do not introduce command-based UX.

## Rule 8

Do not add AI merely because it is available.

## Rule 9

Preserve existing functionality.

## Rule 10

Do not implement multiple unrelated features in one change.

---

# 68. CHANGE MANAGEMENT

Classify changes as:

```text
Bug Fix
UX Improvement
New Feature
Architecture Change
Dependency Change
Breaking Change
```

Architecture and dependency changes require explicit consideration.

---

# 69. AI AGENT HANDOFF PROTOCOL

The project should maintain:

```text
PROJECT ATLAS
│
├── MASTER_PLAN.md
├── README.md
├── CHANGELOG.md
├── ARCHITECTURE.md
├── DATA_MODEL.md
├── DESIGN_SYSTEM.md
└── TODO.md
```

## MASTER_PLAN.md

Defines what Atlas is.

## ARCHITECTURE.md

Defines how Atlas is built.

## DATA_MODEL.md

Defines the database structure.

## DESIGN_SYSTEM.md

Defines visual and interaction rules.

## TODO.md

Defines what should be built next.

## CHANGELOG.md

Records what changed.

---

# 70. DEFINITION OF DONE

A feature is NOT finished merely because the main screen works.

A feature is done when:

- UI works
- Data persists
- Validation works
- Empty state works
- Loading state works
- Error state works
- Mobile layout works
- Dark mode works
- Keyboard interaction works where relevant
- Data survives refresh
- Activity is recorded where appropriate
- Tests exist where appropriate
- Existing functionality does not regress

---

# 71. ATLAS QUALITY BAR

Before considering a feature complete, ask:

```text
Is it useful?

Is it obvious?

Is it fast?

Does it look intentional?

Does it reduce cognitive load?

Does it work without documentation?

Does it feel like Atlas?
```

If the answer is no, improve it.

---

# 72. MOST IMPORTANT UX TEST

> **Can the user understand what to do without reading documentation?**

If not:

# Improve the UI.

Do not solve poor UX by writing more documentation.

---

# 73. FINAL PRODUCT MAP

```text
ATLAS
│
├── GLANCE
│
├── CAPTURE
│
├── TASKS
│
├── HABITS
│
├── MONEY
│
│   ├── Expenses
│   ├── Budgets
│   └── Subscriptions
│
├── LIFE
│
│   ├── Calendar
│   ├── Goals
│   ├── Shopping
│   ├── Waiting
│   ├── Assets
│   └── Documents
│
└── ATLAS CORE
    │
    ├── Search
    ├── Activity
    ├── Rules
    ├── Automation
    ├── Analytics
    └── Notifications


Storage:
Dexie → IndexedDB

Deployment:
GitHub Pages

Architecture:
Local-first

Cost:
₹0/month

Interaction:
Buttons + Forms

AI:
Optional

Backend:
None
```

---

# 74. NORTH STAR

Atlas should make the user's life feel simpler.

It should NOT make the user learn how Atlas works.

Atlas should be:

```text
Quiet
rather than noisy.

Useful
rather than impressive.

Predictable
rather than magical.

Personal
rather than corporate.

Local
rather than dependent.

Button-driven
rather than command-driven.

Free
rather than infrastructure-heavy.
```

---

# 75. RECOMMENDED BUILD SEQUENCE

## Phase 1
Foundation + Design System

## Phase 2
IndexedDB + Data Model

## Phase 3
Glance

## Phase 4
Tasks + Habits

## Phase 5
Finance

## Phase 6
Capture + Reminders

## Phase 7
Search + Activity

## Phase 8
PWA + Offline

## Phase 9
Notifications

## Phase 10
Life Modules

## Phase 11
Automations

## Phase 12
Polish + Testing

---

# 76. MASTER AI IMPLEMENTATION INSTRUCTION

When an AI coding agent is asked to work on Atlas:

1. Read this entire specification.
2. Inspect the current repository.
3. Understand the existing architecture before changing anything.
4. Identify the specific feature/task being requested.
5. Implement only the requested scope.
6. Follow the architecture and UX rules defined here.
7. Do not introduce paid infrastructure.
8. Do not introduce a backend without explicit approval.
9. Do not introduce command-based interactions.
10. Do not introduce unnecessary AI.
11. Do not break existing functionality.
12. Test the feature.
13. Check responsive behavior.
14. Check dark mode.
15. Check persistence.
16. Check empty/loading/error states.
17. Summarize exactly what changed.

If a requested implementation conflicts with this document, **stop and explain the conflict before changing the architecture.**

---

# FINAL PRINCIPLE

> **Atlas is not trying to impress the user with technology.**
>
> **Atlas is trying to make the user's life easier.**
>
> Every feature, architectural decision, UI element, dependency, and line of code should serve that goal.
