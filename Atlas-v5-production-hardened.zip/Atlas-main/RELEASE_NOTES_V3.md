# Atlas v3 — Product Experience Release

Atlas v3 is a product redesign, not a theme swap.

### Experience principles
- **Calm:** fewer competing colors and effects.
- **Direct:** every screen answers what should happen next.
- **Tactile:** controls are sized and placed for mobile use.
- **Private:** local-first storage is visible but never noisy.
- **Distinct:** each module has its own job and interaction model.

### Android path
```bash
npm install
npm run android:build
```

Or run the repository's GitHub Actions Android workflow to generate an APK artifact without Android Studio on the local machine.
