# PROJECT ATLAS — BUILD ROADMAP

- [x] **Phase 1: Foundation + Design System**
- [ ] **Phase 2: IndexedDB + Data Model (Dexie.js)**
- [ ] **Phase 3: Glance Dashboard**
- [ ] **Phase 4: Tasks + Habits**
- [ ] **Phase 5: Finance (Expenses, Budgets, Subscriptions)**
- [ ] **Phase 6: Capture + Reminders**
- [ ] **Phase 7: Search + Activity**
- [ ] **Phase 8: PWA + Offline**
- [ ] **Phase 9: Notifications & Morning Briefing**
- [ ] **Phase 10: Life Modules (Calendar, Goals, Assets)**
- [ ] **Phase 11: Visual Automations Builder**
- [ ] **Phase 12: Polish + Testing**
