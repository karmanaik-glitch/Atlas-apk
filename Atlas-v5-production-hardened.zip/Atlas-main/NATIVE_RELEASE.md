# Atlas native release checklist

## Debug APK

Run `npm run android:build` or the **Build Atlas Android APK** GitHub Action.

## Play Store AAB

Use **Build Atlas Android Release Bundle**. Configure these repository secrets:

- `ANDROID_KEYSTORE_B64` — base64-encoded release keystore
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

The workflow produces `atlas-release-aab`.

## Deep links

Atlas registers the `atlas://` scheme. Examples:

- `atlas://home`
- `atlas://tasks`
- `atlas://money`
- `atlas://capture`
- `atlas://search`

The generated Android manifest is patched during `npm run android:sync`.

## Biometrics

The UI/service boundary is prepared, but no paid native biometric dependency is bundled. For production biometric unlock, install a supported Capacitor biometric provider and implement `src/core/services/biometricService.ts`.
