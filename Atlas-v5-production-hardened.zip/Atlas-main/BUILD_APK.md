# Build Atlas APK

## GitHub Actions — recommended

1. Push the repository to GitHub.
2. Open **Actions → Build Atlas Android APK**.
3. Select **Run workflow**.
4. Download the `atlas-debug-apk` artifact after the job completes.

The workflow installs Node 22, Java 21 and the Android SDK, builds the Vite app, creates/syncs the Capacitor Android project, and runs Gradle `assembleDebug`.

## Local Android build

Requires Node 22+, Android SDK, Java 21 and Gradle access through the generated Capacitor project.

```bash
npm install
npm run android:build
```

The debug APK is produced at:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

## Production distribution

For Play Store distribution, create a signed release keystore and build an Android App Bundle:

```bash
npm run android:release
```

Do not use the debug APK as the Play Store artifact.
