# PROJECT ATLAS

**The 100% Private, Local-First Personal Life Management OS**

Atlas is a personal-use, browser-based, local-first life management application operating at **₹0/month** cost with zero latency and complete privacy.

---

## Technical Stack

- **Framework**: React 18 + TypeScript + Vite
- **Styling**: Tailwind CSS + Atlas Design System
- **State Management**: Zustand
- **Database**: IndexedDB via Dexie.js
- **Hosting**: GitHub Pages (Static Web App)

---

## Quick Start

```bash
# Install dependencies
npm install

# Start local dev server
npm run dev

# Build production bundle
npm run build
```

---

## Master Specification

Refer to `MASTER_PLAN.md` for single source of truth rules and product vision.

## Atlas v3

Atlas v3 is the product-experience redesign release. See `RELEASE_NOTES_V3.md` for the design and interaction changes and `BUILD_APK.md` for Android build instructions.

## Native Android capabilities

Atlas includes Capacitor boundaries for haptics, system share, lifecycle/back handling, deep links, local notifications and native preferences. The web/PWA experience remains functional when these native APIs are unavailable.

## Production hardening
Atlas 5 adds a validated backup format with SHA-256 integrity checking, atomic restore, an explicit database schema migration boundary, UI error recovery, accessibility defaults, and a CI build gate. See `PRODUCTION_READINESS.md` before a public release.
