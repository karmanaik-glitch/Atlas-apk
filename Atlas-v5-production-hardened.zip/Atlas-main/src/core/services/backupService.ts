import { db } from '../../db/schema';

export const BACKUP_SCHEMA_VERSION = 5;

export type BackupPayload = {
  atlasVersion: string;
  schemaVersion: number;
  exportedAt: string;
  checksum?: string;
  data: Record<string, unknown[]>;
};

const TABLES = [
  'tasks','habits','habitRecords','expenses','categories','notes','reminders','budgets',
  'subscriptions','goals','waitingItems','shoppingItems','assetItems','automations','activity','settings',
] as const;

async function checksum(value: string): Promise<string> {
  const bytes = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, '0')).join('');
}

export async function createBackup(): Promise<string> {
  const data: Record<string, unknown[]> = {};
  for (const table of TABLES) data[table] = await (db as any)[table].toArray();

  const payload: BackupPayload = {
    atlasVersion: '5.0.0',
    schemaVersion: BACKUP_SCHEMA_VERSION,
    exportedAt: new Date().toISOString(),
    data,
  };
  payload.checksum = await checksum(JSON.stringify({ ...payload, checksum: undefined }));
  return JSON.stringify(payload, null, 2);
}

export async function parseAndValidateBackup(jsonString: string): Promise<BackupPayload> {
  if (jsonString.length > 25 * 1024 * 1024) throw new Error('Backup is larger than the supported 25 MB limit.');

  let parsed: BackupPayload;
  try { parsed = JSON.parse(jsonString) as BackupPayload; }
  catch { throw new Error('The selected file is not valid JSON.'); }

  if (!parsed || typeof parsed !== 'object' || typeof parsed.schemaVersion !== 'number' || !parsed.data) {
    throw new Error('This is not a valid Atlas backup.');
  }
  if (parsed.schemaVersion > BACKUP_SCHEMA_VERSION) {
    throw new Error(`Backup schema v${parsed.schemaVersion} is newer than this Atlas version (v${BACKUP_SCHEMA_VERSION}).`);
  }
  for (const table of TABLES) {
    if (!Array.isArray(parsed.data[table])) throw new Error(`Backup is missing the ${table} dataset.`);
  }

  if (parsed.checksum) {
    const expected = await checksum(JSON.stringify({ ...parsed, checksum: undefined }));
    if (expected !== parsed.checksum) throw new Error('Backup integrity check failed. The file may be corrupted or modified.');
  }
  return parsed;
}
