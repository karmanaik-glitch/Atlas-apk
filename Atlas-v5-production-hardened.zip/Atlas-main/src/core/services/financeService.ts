import { db } from '../../db/schema';
import { Expense, ExpenseSchema } from '../../types/models';
import { activityService } from './activityService';
import { useToastStore } from '../../stores/toastStore';

export const financeService = {
  async getAllExpenses(): Promise<Expense[]> {
    return await db.expenses.orderBy('date').reverse().toArray();
  },

  async addExpense(rawExpense: Partial<Expense>): Promise<number> {
    const todayStr = new Date().toISOString().split('T')[0];
    const newExpense: Expense = {
      amount: Number(rawExpense.amount) || 0,
      category: rawExpense.category || 'Other',
      merchant: rawExpense.merchant,
      note: rawExpense.note,
      paymentMethod: rawExpense.paymentMethod || 'cash',
      date: rawExpense.date || todayStr,
      createdAt: new Date().toISOString(),
    };

    const validated = ExpenseSchema.parse(newExpense);
    const id = await db.expenses.add(validated as Expense);

    await activityService.logActivity(
      'expense_added',
      `Logged expense: ₹${validated.amount} for ${validated.category}`,
      id
    );

    useToastStore.getState().showToast(`Logged expense: ₹${validated.amount} (${validated.category})`, 'success');

    return id;
  },

  async deleteExpense(id: number): Promise<void> {
    await db.expenses.delete(id);
    useToastStore.getState().showToast(`Expense record removed`, 'info');
  },

  async getMonthlySpend(yearMonthStr?: string): Promise<{ total: number; byCategory: Record<string, number> }> {
    const targetYM = yearMonthStr || new Date().toISOString().substring(0, 7); // YYYY-MM
    const allExpenses = await db.expenses.toArray();

    const monthlyExpenses = allExpenses.filter((e) => e.date.startsWith(targetYM));

    let total = 0;
    const byCategory: Record<string, number> = {};

    monthlyExpenses.forEach((e) => {
      total += e.amount;
      byCategory[e.category] = (byCategory[e.category] || 0) + e.amount;
    });

    return { total, byCategory };
  },
};
