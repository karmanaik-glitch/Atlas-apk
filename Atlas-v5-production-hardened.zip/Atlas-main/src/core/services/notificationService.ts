import { db } from '../../db/schema';
import { activityService } from './activityService';

export const notificationService = {
  isSupported(): boolean {
    return typeof window !== 'undefined' && 'Notification' in window;
  },

  getPermissionStatus(): NotificationPermission {
    if (!this.isSupported()) return 'denied';
    return Notification.permission;
  },

  async requestPermission(): Promise<NotificationPermission> {
    if (!this.isSupported()) return 'denied';
    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
      await activityService.logActivity('reminder_triggered', 'Browser notifications enabled.');
    }
    return permission;
  },

  sendNotification(title: string, options?: NotificationOptions) {
    if (!this.isSupported() || Notification.permission !== 'granted') return;

    try {
      new Notification(title, {
        icon: '/pwa-192x192.png',
        badge: '/pwa-192x192.png',
        silent: false,
        ...options,
      });
    } catch (err) {
      console.error('Failed to trigger notification:', err);
    }
  },

  async sendTestNotification(): Promise<boolean> {
    if (!this.isSupported()) return false;
    const perm = await this.requestPermission();
    if (perm === 'granted') {
      this.sendNotification('Project Atlas Test Notification', {
        body: 'Local notifications are configured and functioning correctly.',
        tag: 'test-notification',
      });
      return true;
    }
    return false;
  },

  // Notification Engine Loop: Checks due reminders and overdue tasks periodically
  async checkPendingNotifications() {
    if (!this.isSupported() || Notification.permission !== 'granted') return;

    const now = new Date();
    const nowIso = now.toISOString();

    try {
      // 1. Check Untriggered Due Reminders
      const dueReminders = await db.reminders
        .filter((r) => !r.isTriggered && new Date(r.datetime) <= now)
        .toArray();

      for (const rem of dueReminders) {
        this.sendNotification(`Reminder: ${rem.title}`, {
          body: `Scheduled for ${new Date(rem.datetime).toLocaleTimeString()}`,
          tag: `rem-${rem.id}`,
        });

        await db.reminders.update(rem.id!, { isTriggered: true });
        await activityService.logActivity('reminder_triggered', `Triggered notification: "${rem.title}"`);
      }
    } catch (err) {
      console.error('Notification engine check failed:', err);
    }
  },

  // Start periodic polling loop (runs every 30 seconds)
  startNotificationEngine(intervalMs = 30000) {
    this.checkPendingNotifications();
    const timerId = setInterval(() => {
      this.checkPendingNotifications();
    }, intervalMs);

    return () => clearInterval(timerId);
  },
};
