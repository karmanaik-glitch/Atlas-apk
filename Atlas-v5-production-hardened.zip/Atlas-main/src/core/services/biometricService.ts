/**
 * Biometric boundary for Atlas.
 *
 * Atlas keeps the app-lock policy separate from storage and navigation so a
 * native biometric provider can be plugged in without changing the product UI.
 * The default implementation intentionally reports unavailable until a native
 * biometric provider is installed in the Android build.
 */
export type BiometricStatus = 'available' | 'unavailable' | 'unknown';

export async function getBiometricStatus(): Promise<BiometricStatus> {
  return 'unavailable';
}

export async function authenticateWithBiometrics(): Promise<boolean> {
  return false;
}
