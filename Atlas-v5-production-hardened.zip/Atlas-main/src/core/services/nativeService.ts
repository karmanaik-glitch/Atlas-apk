import { Capacitor } from '@capacitor/core';
import { Haptics, ImpactStyle } from '@capacitor/haptics';
import { Share } from '@capacitor/share';
import { App } from '@capacitor/app';
import { Preferences } from '@capacitor/preferences';

const LOCK_KEY = 'atlas.appLock.enabled';

export const isNative = () => Capacitor.isNativePlatform();

export async function tapHaptic(style: ImpactStyle = ImpactStyle.Light) {
  if (!isNative()) return;
  try { await Haptics.impact({ style }); } catch { /* no-op on unsupported devices */ }
}

export async function shareAtlas(text: string, title = 'Atlas') {
  if (!isNative()) {
    if (navigator.share) return navigator.share({ title, text });
    return false;
  }
  try {
    await Share.share({ title, text, dialogTitle: 'Share from Atlas' });
    return true;
  } catch {
    return false;
  }
}

export async function setAppLockEnabled(enabled: boolean) {
  await Preferences.set({ key: LOCK_KEY, value: String(enabled) });
}

export async function isAppLockEnabled() {
  const { value } = await Preferences.get({ key: LOCK_KEY });
  return value === 'true';
}

export function onNativeUrlOpen(handler: (url: string) => void) {
  if (!isNative()) return () => undefined;
  let active = true;
  App.addListener('appUrlOpen', ({ url }) => { if (active) handler(url); });
  return () => { active = false; };
}
