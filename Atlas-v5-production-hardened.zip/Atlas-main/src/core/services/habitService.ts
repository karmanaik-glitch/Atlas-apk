import { db } from '../../db/schema';
import { Habit, HabitSchema, HabitRecord } from '../../types/models';
import { activityService } from './activityService';
import { useToastStore } from '../../stores/toastStore';

export const habitService = {
  async getAllHabits(): Promise<Habit[]> {
    return await db.habits.toArray();
  },

  async addHabit(rawHabit: Partial<Habit>): Promise<number> {
    const newHabit: Habit = {
      name: rawHabit.name || 'New Habit',
      category: rawHabit.category,
      frequency: rawHabit.frequency || 'daily',
      targetDaysPerWeek: rawHabit.targetDaysPerWeek || 7,
      streak: 0,
      bestStreak: 0,
      createdAt: new Date().toISOString(),
    };

    const validated = HabitSchema.parse(newHabit);
    const id = await db.habits.add(validated as Habit);
    useToastStore.getState().showToast(`Habit tracked: "${validated.name}"`, 'success');
    return id;
  },

  async isHabitCompletedToday(habitId: number): Promise<boolean> {
    const todayStr = new Date().toISOString().split('T')[0];
    const record = await db.habitRecords.where({ habitId, date: todayStr }).first();
    return record?.status === 'completed';
  },

  async toggleHabitCompletion(habitId: number, dateStr?: string): Promise<boolean> {
    const targetDate = dateStr || new Date().toISOString().split('T')[0];
    const habit = await db.habits.get(habitId);
    if (!habit) return false;

    const existingRecord = await db.habitRecords
      .where('[habitId+date]')
      .equals([habitId, targetDate])
      .first();

    if (existingRecord && existingRecord.status === 'completed') {
      // Un-complete
      await db.habitRecords.delete(existingRecord.id!);
      const newStreak = Math.max(0, habit.streak - 1);
      await db.habits.update(habitId, { streak: newStreak });
      useToastStore.getState().showToast(`Habit un-checked`, 'info');
      return false;
    } else {
      // Complete
      if (existingRecord) {
        await db.habitRecords.update(existingRecord.id!, { status: 'completed' });
      } else {
        await db.habitRecords.add({
          habitId,
          date: targetDate,
          status: 'completed',
        });
      }

      const newStreak = habit.streak + 1;
      const bestStreak = Math.max(habit.bestStreak, newStreak);
      await db.habits.update(habitId, {
        streak: newStreak,
        bestStreak,
        lastCompletedDate: targetDate,
      });

      await activityService.logActivity('habit_completed', `Completed habit: "${habit.name}" (${newStreak} day streak!)`, habitId);
      useToastStore.getState().showToast(`🔥 "${habit.name}" completed! Streak: ${newStreak} days`, 'success');
      return true;
    }
  },

  async deleteHabit(habitId: number): Promise<void> {
    await db.habits.delete(habitId);
    await db.habitRecords.where({ habitId }).delete();
    useToastStore.getState().showToast(`Habit removed`, 'info');
  },
};
