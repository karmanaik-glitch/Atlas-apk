import { db } from '../../db/schema';
import { Goal, WaitingItem, ShoppingItem, AssetItem } from '../../types/models';
import { activityService } from './activityService';

export const goalService = {
  async addGoal(goal: Omit<Goal, 'id' | 'createdAt'>): Promise<number> {
    const id = await db.goals.add({
      ...goal,
      createdAt: new Date().toISOString(),
    });
    await activityService.logActivity('goal_created' as any, `Created goal: "${goal.title}"`);
    return id as number;
  },

  async updateGoal(id: number, updates: Partial<Goal>): Promise<void> {
    await db.goals.update(id, updates);
  },

  async deleteGoal(id: number): Promise<void> {
    await db.goals.delete(id);
  },
};

export const waitingService = {
  async addWaitingItem(item: Omit<WaitingItem, 'id' | 'dateRequested'>): Promise<number> {
    const id = await db.waitingItems.add({
      ...item,
      dateRequested: new Date().toISOString().split('T')[0],
    });
    await activityService.logActivity('waiting_created' as any, `Added waiting item: "${item.title}" (${item.personOrSource})`);
    return id as number;
  },

  async toggleResolved(id: number, currentStatus: 'pending' | 'resolved'): Promise<void> {
    const newStatus = currentStatus === 'pending' ? 'resolved' : 'pending';
    await db.waitingItems.update(id, { status: newStatus });
  },

  async deleteWaitingItem(id: number): Promise<void> {
    await db.waitingItems.delete(id);
  },
};

export const shoppingService = {
  async addShoppingItem(item: Omit<ShoppingItem, 'id' | 'isPurchased'>): Promise<number> {
    const id = await db.shoppingItems.add({
      ...item,
      isPurchased: false,
    });
    return id as number;
  },

  async togglePurchased(id: number, current: boolean): Promise<void> {
    await db.shoppingItems.update(id, { isPurchased: !current });
  },

  async deleteShoppingItem(id: number): Promise<void> {
    await db.shoppingItems.delete(id);
  },

  async clearPurchased(): Promise<void> {
    const purchased = await db.shoppingItems.filter((i) => i.isPurchased).toArray();
    for (const p of purchased) {
      if (p.id) await db.shoppingItems.delete(p.id);
    }
  },
};

export const assetService = {
  async addAsset(asset: Omit<AssetItem, 'id'>): Promise<number> {
    const id = await db.assetItems.add(asset);
    await activityService.logActivity('asset_created' as any, `Cataloged asset: "${asset.name}"`);
    return id as number;
  },

  async updateAsset(id: number, updates: Partial<AssetItem>): Promise<void> {
    await db.assetItems.update(id, updates);
  },

  async deleteAsset(id: number): Promise<void> {
    await db.assetItems.delete(id);
  },
};
