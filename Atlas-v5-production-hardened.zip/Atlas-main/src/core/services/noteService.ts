import { db } from '../../db/schema';
import { Note } from '../../types/models';
import { activityService } from './activityService';

export const noteService = {
  async getAllNotes(): Promise<Note[]> {
    return await db.notes.orderBy('updatedAt').reverse().toArray();
  },

  async addNote(rawNote: Partial<Note>): Promise<number> {
    const now = new Date().toISOString();
    const newNote: Note = {
      title: rawNote.title || 'Untitled Note',
      content: rawNote.content || '',
      tags: rawNote.tags || [],
      archived: false,
      createdAt: now,
      updatedAt: now,
    };

    const id = await db.notes.add(newNote);
    await activityService.logActivity('task_created', `Created note: "${newNote.title}"`, id);
    return id;
  },

  async updateNote(id: number, updates: Partial<Note>): Promise<void> {
    await db.notes.update(id, {
      ...updates,
      updatedAt: new Date().toISOString(),
    });
  },

  async deleteNote(id: number): Promise<void> {
    await db.notes.delete(id);
  },
};
