import { db } from '../../db/schema';
import { AutomationRule } from '../../types/models';
import { notificationService } from './notificationService';
import { activityService } from './activityService';
import { taskService } from './taskService';

export const automationService = {
  async addRule(rule: Omit<AutomationRule, 'id'>): Promise<number> {
    const id = await db.automations.add(rule);
    await activityService.logActivity('automation_created' as any, `Created automation rule: "${rule.name}"`);
    return id as number;
  },

  async toggleActive(id: number, currentActive: boolean): Promise<void> {
    await db.automations.update(id, { isActive: !currentActive });
  },

  async deleteRule(id: number): Promise<void> {
    await db.automations.delete(id);
  },

  async seedDefaultTemplates(): Promise<void> {
    const count = await db.automations.count();
    if (count === 0) {
      await db.automations.bulkAdd([
        {
          name: 'Friday Weekly Financial Review',
          description: 'Reminds you to review weekly expenses and category budgets every Friday evening.',
          triggerType: 'schedule',
          triggerConfig: {
            scheduleTime: '19:00',
            scheduleDays: ['Friday'],
          },
          actionType: 'send_notification',
          actionConfig: {
            title: 'Weekly Finance Review',
            body: 'Open Atlas Money tab to review your weekly spending and category budgets.',
          },
          isActive: true,
        },
        {
          name: 'Category Budget Alert (80%)',
          description: 'Triggers a desktop alert when any spending category reaches 80% of limit.',
          triggerType: 'budget_threshold',
          triggerConfig: {
            thresholdPercent: 80,
          },
          actionType: 'send_notification',
          actionConfig: {
            title: 'Budget Alert Threshold',
            body: 'A spending category has exceeded 80% of its budget limit.',
          },
          isActive: true,
        },
      ]);
    }
  },

  async evaluateAutomations(): Promise<void> {
    const rules = await db.automations.filter((r) => r.isActive).toArray();
    const now = new Date();

    for (const rule of rules) {
      try {
        if (rule.triggerType === 'schedule') {
          // Check time schedule
          const dayName = now.toLocaleDateString('en-US', { weekday: 'long' });
          const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

          const matchesDay = rule.triggerConfig.scheduleDays?.includes('daily') || rule.triggerConfig.scheduleDays?.includes(dayName);
          const matchesTime = rule.triggerConfig.scheduleTime === timeStr;

          if (matchesDay && matchesTime) {
            // Avoid triggering multiple times in the same minute
            const lastRunDate = rule.lastRunAt ? new Date(rule.lastRunAt).toDateString() : '';
            if (lastRunDate !== now.toDateString()) {
              await this.executeRuleAction(rule);
              await db.automations.update(rule.id!, { lastRunAt: now.toISOString() });
            }
          }
        }
      } catch (err) {
        console.error('Automation evaluation error:', err);
      }
    }
  },

  async executeRuleAction(rule: AutomationRule): Promise<void> {
    if (rule.actionType === 'send_notification') {
      notificationService.sendNotification(rule.actionConfig.title || rule.name, {
        body: rule.actionConfig.body || 'Atlas Automation Action Executed',
        tag: `auto-${rule.id}`,
      });
    } else if (rule.actionType === 'create_task') {
      await taskService.addTask({
        title: rule.actionConfig.title || rule.name,
        description: rule.actionConfig.body,
        priority: 'medium',
        status: 'today',
        dueDate: new Date().toISOString().split('T')[0],
      });
    }

    await activityService.logActivity('automation_triggered' as any, `Executed automation rule: "${rule.name}"`);
  },
};
