import { db } from '../../db/schema';
import { Reminder } from '../../types/models';
import { activityService } from './activityService';

export const reminderService = {
  async getAllReminders(): Promise<Reminder[]> {
    return await db.reminders.orderBy('datetime').toArray();
  },

  async addReminder(rawReminder: Partial<Reminder>): Promise<number> {
    const newReminder: Reminder = {
      title: rawReminder.title || 'Untitled Reminder',
      datetime: rawReminder.datetime || new Date().toISOString(),
      entityType: rawReminder.entityType || 'custom',
      entityId: rawReminder.entityId,
      isTriggered: false,
    };

    const id = await db.reminders.add(newReminder);
    await activityService.logActivity('reminder_triggered', `Set reminder: "${newReminder.title}"`, id);
    return id;
  },

  async toggleTriggered(id: number): Promise<void> {
    const rem = await db.reminders.get(id);
    if (rem) {
      await db.reminders.update(id, { isTriggered: !rem.isTriggered });
    }
  },

  async deleteReminder(id: number): Promise<void> {
    await db.reminders.delete(id);
  },
};
