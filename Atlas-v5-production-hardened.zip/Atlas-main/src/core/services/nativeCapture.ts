import { Capacitor } from '@capacitor/core';

export function getNativeCaptureText(url: string) {
  if (!Capacitor.isNativePlatform()) return '';
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== 'atlas:' || parsed.hostname !== 'capture') return '';
    return parsed.searchParams.get('text')?.trim() || '';
  } catch {
    return '';
  }
}
