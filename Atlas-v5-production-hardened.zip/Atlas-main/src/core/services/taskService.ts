import { db } from '../../db/schema';
import { Task, TaskSchema, TaskStatus } from '../../types/models';
import { activityService } from './activityService';
import { useToastStore } from '../../stores/toastStore';

export const taskService = {
  async getAllTasks(): Promise<Task[]> {
    return await db.tasks.orderBy('createdAt').reverse().toArray();
  },

  async getTasksByStatus(status: TaskStatus): Promise<Task[]> {
    return await db.tasks.where({ status }).toArray();
  },

  async getTodayTasks(): Promise<Task[]> {
    const todayStr = new Date().toISOString().split('T')[0];
    return await db.tasks
      .filter((task) => task.status === 'today' || (task.dueDate === todayStr && task.status !== 'completed'))
      .toArray();
  },

  async addTask(rawTask: Partial<Task>): Promise<number> {
    const newTask: Task = {
      title: rawTask.title || 'Untitled Task',
      description: rawTask.description || '',
      priority: rawTask.priority || 'medium',
      status: rawTask.status || 'inbox',
      category: rawTask.category,
      dueDate: rawTask.dueDate,
      dueTime: rawTask.dueTime,
      recurrence: rawTask.recurrence || 'none',
      createdAt: new Date().toISOString(),
    };

    const validated = TaskSchema.parse(newTask);
    const id = await db.tasks.add(validated as Task);

    await activityService.logActivity('task_created', `Created task: "${validated.title}"`, id);
    useToastStore.getState().showToast(`Task created: "${validated.title}"`, 'success');
    return id;
  },

  async updateTask(id: number, updates: Partial<Task>): Promise<void> {
    await db.tasks.update(id, updates);
  },

  async toggleTaskComplete(id: number): Promise<void> {
    const task = await db.tasks.get(id);
    if (!task) return;

    const isCompleted = task.status === 'completed';
    const newStatus: TaskStatus = isCompleted ? 'inbox' : 'completed';
    const completedAt = isCompleted ? undefined : new Date().toISOString();

    await db.tasks.update(id, { status: newStatus, completedAt });

    if (!isCompleted) {
      await activityService.logActivity('task_completed', `Completed task: "${task.title}"`, id);
      useToastStore.getState().showToast(`Task completed! 🎉`, 'success');
    } else {
      useToastStore.getState().showToast(`Task restored to inbox`, 'info');
    }
  },

  async deleteTask(id: number): Promise<void> {
    const task = await db.tasks.get(id);
    if (task) {
      await db.tasks.delete(id);
      useToastStore.getState().showToast(`Deleted task: "${task.title}"`, 'info');
    }
  },
};
