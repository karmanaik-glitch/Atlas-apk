import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';

export async function requestNativeNotifications() {
  if (!Capacitor.isNativePlatform()) return false;
  const result = await LocalNotifications.requestPermissions();
  return result.display === 'granted';
}

export async function scheduleAtlasReminder(id: number, title: string, body: string, at: Date) {
  if (!Capacitor.isNativePlatform()) return false;
  const permission = await LocalNotifications.checkPermissions();
  if (permission.display !== 'granted') return false;
  await LocalNotifications.schedule({ notifications: [{ id, title, body, schedule: { at }, smallIcon: 'ic_stat_atlas' }] });
  return true;
}
