import { db } from '../../db/schema';
import { activityService } from './activityService';
import { useToastStore } from '../../stores/toastStore';
import { BACKUP_SCHEMA_VERSION, createBackup, parseAndValidateBackup, BackupPayload } from './backupService';

export interface BackupDataFormat {
  atlasVersion: string;
  schemaVersion: number;
  exportedAt: string;
  data: {
    tasks: any[];
    habits: any[];
    habitRecords: any[];
    expenses: any[];
    categories: any[];
    notes: any[];
    reminders: any[];
    budgets: any[];
    subscriptions: any[];
    goals: any[];
    waitingItems: any[];
    shoppingItems: any[];
    assetItems: any[];
    automations: any[];
    activity: any[];
    settings: any[];
  };
}

export const settingsService = {
  async exportFullBackup(): Promise<string> {
    const json = await createBackup();
    await activityService.logActivity('backup_created', 'Exported full Atlas JSON backup file.');
    useToastStore.getState().showToast('Backup JSON exported successfully!', 'success');
    return json;
  },

  async importFullBackup(jsonString: string): Promise<{ success: boolean; message: string }> {
    try {
      const parsed: BackupPayload = await parseAndValidateBackup(jsonString);
      const d = parsed.data as any;

      await db.transaction(
        'rw',
        [db.tasks, db.habits, db.habitRecords, db.expenses, db.categories, db.notes, db.reminders, db.budgets,
         db.subscriptions, db.goals, db.waitingItems, db.shoppingItems, db.assetItems, db.automations, db.activity, db.settings],
        async () => {
          for (const table of [db.tasks, db.habits, db.habitRecords, db.expenses, db.categories, db.notes, db.reminders,
            db.budgets, db.subscriptions, db.goals, db.waitingItems, db.shoppingItems, db.assetItems, db.automations, db.activity, db.settings]) await table.clear();
          if (d.tasks.length) await db.tasks.bulkAdd(d.tasks);
          if (d.habits.length) await db.habits.bulkAdd(d.habits);
          if (d.habitRecords.length) await db.habitRecords.bulkAdd(d.habitRecords);
          if (d.expenses.length) await db.expenses.bulkAdd(d.expenses);
          if (d.categories.length) await db.categories.bulkAdd(d.categories);
          if (d.notes.length) await db.notes.bulkAdd(d.notes);
          if (d.reminders.length) await db.reminders.bulkAdd(d.reminders);
          if (d.budgets.length) await db.budgets.bulkAdd(d.budgets);
          if (d.subscriptions.length) await db.subscriptions.bulkAdd(d.subscriptions);
          if (d.goals.length) await db.goals.bulkAdd(d.goals);
          if (d.waitingItems.length) await db.waitingItems.bulkAdd(d.waitingItems);
          if (d.shoppingItems.length) await db.shoppingItems.bulkAdd(d.shoppingItems);
          if (d.assetItems.length) await db.assetItems.bulkAdd(d.assetItems);
          if (d.automations.length) await db.automations.bulkAdd(d.automations);
          if (d.activity.length) await db.activity.bulkAdd(d.activity);
          if (d.settings.length) await db.settings.bulkAdd(d.settings);
        }
      );

      return { success: true, message: `Atlas backup restored successfully (schema v${parsed.schemaVersion}).` };
    } catch (err: any) {
      console.error('Import Error:', err);
      return { success: false, message: err?.message || 'Failed to import Atlas backup.' };
    }
  },

  getBackupSchemaVersion() { return BACKUP_SCHEMA_VERSION; },

  async clearAllData(): Promise<void> {
    await db.transaction(
      'rw',
      [
        db.tasks,
        db.habits,
        db.habitRecords,
        db.expenses,
        db.categories,
        db.notes,
        db.reminders,
        db.budgets,
        db.subscriptions,
        db.goals,
        db.waitingItems,
        db.shoppingItems,
        db.assetItems,
        db.automations,
        db.activity,
        db.settings,
      ],
      async () => {
        await db.tasks.clear();
        await db.habits.clear();
        await db.habitRecords.clear();
        await db.expenses.clear();
        await db.categories.clear();
        await db.notes.clear();
        await db.reminders.clear();
        await db.budgets.clear();
        await db.subscriptions.clear();
        await db.goals.clear();
        await db.waitingItems.clear();
        await db.shoppingItems.clear();
        await db.assetItems.clear();
        await db.automations.clear();
        await db.activity.clear();
        await db.settings.clear();
      }
    );
  },
};
