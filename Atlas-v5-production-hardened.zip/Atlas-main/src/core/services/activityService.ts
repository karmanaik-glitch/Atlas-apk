import { db } from '../../db/schema';
import { ActivityType } from '../../types/models';

export const activityService = {
  async logActivity(type: ActivityType, description: string, entityId?: number) {
    try {
      await db.activity.add({
        type,
        description,
        timestamp: new Date().toISOString(),
        entityId,
      });
    } catch (err) {
      console.error('Failed to log activity:', err);
    }
  },

  async getRecentActivity(limit = 20) {
    return await db.activity
      .orderBy('timestamp')
      .reverse()
      .limit(limit)
      .toArray();
  },
};
