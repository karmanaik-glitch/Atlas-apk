import React from 'react';
import { Sparkles, Calendar, CheckSquare, Flame, Wallet, ShieldCheck } from 'lucide-react';
import { useTodayTasks, useHabits, useMonthlySpend } from '../../hooks/useAtlasData';

export const GreetingBriefingCard: React.FC = () => {
  const { tasks } = useTodayTasks();
  const { habits } = useHabits();
  const { total: monthlySpend } = useMonthlySpend();

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  const todayDateStr = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'short',
    day: 'numeric',
  });

  const pendingTasksCount = tasks.filter((t) => t.status !== 'completed').length;

  return (
    <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-indigo-950/70 via-atlas-card to-atlas-card border border-indigo-500/20 relative overflow-hidden shadow-glass space-y-4">
      <div className="absolute top-0 right-0 -mt-10 -mr-10 w-48 h-48 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none"></div>

      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-atlas-border/50 pb-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-mono text-emerald-400 font-semibold tracking-wider uppercase mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Karma's Daily Briefing</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-atlas-text tracking-tight">
            {getGreeting()}, Karma.
          </h1>
        </div>

        <div className="flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-atlas-surface/80 border border-atlas-border text-xs text-atlas-muted font-medium self-start sm:self-auto">
          <Calendar className="w-4 h-4 text-indigo-400" />
          <span>{todayDateStr}</span>
        </div>
      </div>

      {/* Briefing Stats Pills */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-3 rounded-xl bg-atlas-surface/60 border border-atlas-border/60 flex items-center space-x-3">
          <div className="w-9 h-9 rounded-lg bg-indigo-500/15 text-indigo-400 flex items-center justify-center">
            <CheckSquare className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-atlas-muted">Today's Tasks</div>
            <div className="text-sm font-bold text-atlas-text">
              {pendingTasksCount} {pendingTasksCount === 1 ? 'task' : 'tasks'} pending
            </div>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-atlas-surface/60 border border-atlas-border/60 flex items-center space-x-3">
          <div className="w-9 h-9 rounded-lg bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
            <Flame className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-atlas-muted">Active Habits</div>
            <div className="text-sm font-bold text-atlas-text">
              {habits.length} habits tracked
            </div>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-atlas-surface/60 border border-atlas-border/60 flex items-center space-x-3">
          <div className="w-9 h-9 rounded-lg bg-rose-500/15 text-rose-400 flex items-center justify-center">
            <Wallet className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-atlas-muted">Monthly Spend</div>
            <div className="text-sm font-bold text-atlas-text">
              ₹{monthlySpend.toLocaleString('en-IN')}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
