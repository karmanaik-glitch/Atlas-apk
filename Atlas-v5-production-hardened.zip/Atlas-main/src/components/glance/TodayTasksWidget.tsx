import React, { useState } from 'react';
import { CheckSquare, Plus, Check, Clock, AlertCircle } from 'lucide-react';
import { useTodayTasks } from '../../hooks/useAtlasData';
import { taskService } from '../../core/services/taskService';
import { TaskPriority } from '../../types/models';

export const TodayTasksWidget: React.FC = () => {
  const { tasks } = useTodayTasks();
  const [isAdding, setIsAdding] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newPriority, setNewPriority] = useState<TaskPriority>('medium');

  const handleAddTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    await taskService.addTask({
      title: newTitle.trim(),
      priority: newPriority,
      status: 'today',
      dueDate: new Date().toISOString().split('T')[0],
    });

    setNewTitle('');
    setIsAdding(false);
  };

  const getPriorityBadge = (priority: TaskPriority) => {
    switch (priority) {
      case 'high':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-500/15 text-rose-400 border border-rose-500/20">High</span>;
      case 'medium':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/15 text-amber-400 border border-amber-500/20">Medium</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-500/15 text-slate-400 border border-slate-500/20">Low</span>;
    }
  };

  return (
    <div className="p-6 rounded-2xl bg-atlas-card border border-atlas-border space-y-4 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <CheckSquare className="w-5 h-5 text-indigo-400" />
          <h2 className="font-bold text-atlas-text text-base">Today's Tasks</h2>
          <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 font-mono font-medium">
            {tasks.length}
          </span>
        </div>

        <button
          onClick={() => setIsAdding(!isAdding)}
          className="p-1.5 rounded-lg bg-atlas-surface border border-atlas-border text-atlas-muted hover:text-atlas-text transition-all"
          title="Add task for today"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {/* Quick Add Form */}
      {isAdding && (
        <form onSubmit={handleAddTask} className="p-3 rounded-xl bg-atlas-bg border border-atlas-border space-y-3 animate-fadeIn">
          <input
            type="text"
            placeholder="What needs to be done today?"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            className="w-full px-3 py-1.5 rounded-lg bg-atlas-surface border border-atlas-border text-atlas-text text-xs focus:outline-none focus:border-atlas-accent"
            autoFocus
          />
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center space-x-2">
              <span className="text-atlas-muted text-[11px]">Priority:</span>
              {(['low', 'medium', 'high'] as TaskPriority[]).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setNewPriority(p)}
                  className={`px-2 py-0.5 rounded text-[10px] uppercase font-semibold border ${
                    newPriority === p
                      ? 'bg-atlas-accent/20 border-atlas-accent text-emerald-400'
                      : 'border-atlas-border text-atlas-muted'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>

            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={() => setIsAdding(false)}
                className="px-2.5 py-1 text-atlas-muted hover:text-atlas-text text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-3 py-1 rounded bg-atlas-accent text-slate-950 font-bold text-xs"
              >
                Save
              </button>
            </div>
          </div>
        </form>
      )}

      {/* Task List */}
      <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
        {tasks.length === 0 ? (
          <div className="p-6 rounded-xl border border-dashed border-atlas-border/70 text-center text-atlas-muted text-xs space-y-1">
            <Clock className="w-5 h-5 mx-auto text-atlas-muted opacity-60" />
            <p>No tasks scheduled for today.</p>
          </div>
        ) : (
          tasks.map((task) => {
            const isCompleted = task.status === 'completed';
            return (
              <div
                key={task.id}
                className={`p-3 rounded-xl border transition-all flex items-center justify-between group ${
                  isCompleted
                    ? 'bg-atlas-bg/50 border-atlas-border/50 opacity-60'
                    : 'bg-atlas-surface border-atlas-border hover:border-atlas-muted'
                }`}
              >
                <div className="flex items-center space-x-3 min-w-0 pr-2">
                  <button
                    onClick={() => task.id && taskService.toggleTaskComplete(task.id)}
                    className={`w-5 h-5 rounded-md border flex items-center justify-center transition-all ${
                      isCompleted
                        ? 'bg-emerald-500 border-emerald-500 text-slate-950'
                        : 'border-atlas-muted hover:border-emerald-400 text-transparent'
                    }`}
                  >
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </button>

                  <span className={`text-xs font-medium truncate ${isCompleted ? 'line-through text-atlas-muted' : 'text-atlas-text'}`}>
                    {task.title}
                  </span>
                </div>

                <div className="flex items-center space-x-2 shrink-0">
                  {getPriorityBadge(task.priority)}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
