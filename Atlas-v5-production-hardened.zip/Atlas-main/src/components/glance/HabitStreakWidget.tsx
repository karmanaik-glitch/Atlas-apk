import React, { useState } from 'react';
import { Flame, Plus, Check } from 'lucide-react';
import { useHabits } from '../../hooks/useAtlasData';
import { habitService } from '../../core/services/habitService';

export const HabitStreakWidget: React.FC = () => {
  const { habits } = useHabits();
  const [isAdding, setIsAdding] = useState(false);
  const [newHabitName, setNewHabitName] = useState('');
  const todayStr = new Date().toISOString().split('T')[0];

  const handleAddHabit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHabitName.trim()) return;

    await habitService.addHabit({
      name: newHabitName.trim(),
      frequency: 'daily',
    });

    setNewHabitName('');
    setIsAdding(false);
  };

  return (
    <div className="p-6 rounded-2xl bg-atlas-card border border-atlas-border space-y-4 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Flame className="w-5 h-5 text-emerald-400 animate-pulse" />
          <h2 className="font-bold text-atlas-text text-base">Habits & Streaks</h2>
          <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-mono font-medium">
            {habits.length}
          </span>
        </div>

        <button
          onClick={() => setIsAdding(!isAdding)}
          className="p-1.5 rounded-lg bg-atlas-surface border border-atlas-border text-atlas-muted hover:text-atlas-text transition-all"
          title="New habit"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {/* Quick Add Habit */}
      {isAdding && (
        <form onSubmit={handleAddHabit} className="p-3 rounded-xl bg-atlas-bg border border-atlas-border space-y-2">
          <input
            type="text"
            placeholder="Habit name (e.g., Read 15 mins)"
            value={newHabitName}
            onChange={(e) => setNewHabitName(e.target.value)}
            className="w-full px-3 py-1.5 rounded-lg bg-atlas-surface border border-atlas-border text-atlas-text text-xs focus:outline-none focus:border-atlas-accent"
            autoFocus
          />
          <div className="flex justify-end space-x-2">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-2.5 py-1 text-atlas-muted text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-3 py-1 rounded bg-atlas-accent text-slate-950 font-bold text-xs"
            >
              Save Habit
            </button>
          </div>
        </form>
      )}

      {/* Habit List */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {habits.length === 0 ? (
          <div className="col-span-2 p-6 rounded-xl border border-dashed border-atlas-border/70 text-center text-atlas-muted text-xs">
            No active habits. Click + to add your first habit.
          </div>
        ) : (
          habits.map((habit) => {
            const isCompletedToday = habit.lastCompletedDate === todayStr;
            return (
              <div
                key={habit.id}
                className={`p-3.5 rounded-xl border transition-all flex items-center justify-between ${
                  isCompletedToday
                    ? 'bg-emerald-500/10 border-emerald-500/30'
                    : 'bg-atlas-surface border-atlas-border hover:border-atlas-muted'
                }`}
              >
                <div className="space-y-0.5">
                  <div className="text-xs font-semibold text-atlas-text">{habit.name}</div>
                  <div className="flex items-center space-x-1 text-[11px] text-emerald-400 font-mono">
                    <Flame className="w-3 h-3 fill-emerald-400/20" />
                    <span>{habit.streak} day streak</span>
                  </div>
                </div>

                <button
                  onClick={() => habit.id && habitService.toggleHabitCompletion(habit.id)}
                  className={`px-3 py-1.5 rounded-lg font-semibold text-xs transition-all flex items-center space-x-1 active:scale-95 ${
                    isCompletedToday
                      ? 'bg-emerald-500 text-slate-950 shadow-glow'
                      : 'bg-atlas-bg border border-atlas-border text-atlas-muted hover:text-atlas-text hover:border-emerald-500/50'
                  }`}
                >
                  {isCompletedToday ? (
                    <>
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                      <span>Done</span>
                    </>
                  ) : (
                    <span>Mark</span>
                  )}
                </button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
