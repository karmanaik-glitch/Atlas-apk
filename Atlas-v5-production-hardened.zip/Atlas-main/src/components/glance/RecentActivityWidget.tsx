import React from 'react';
import { History, CheckCircle2, Flame, Wallet, Sparkles } from 'lucide-react';
import { useRecentActivity } from '../../hooks/useAtlasData';

export const RecentActivityWidget: React.FC = () => {
  const { activity } = useRecentActivity(6);

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'task_completed':
      case 'task_created':
        return <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400" />;
      case 'habit_completed':
        return <Flame className="w-3.5 h-3.5 text-emerald-400" />;
      case 'expense_added':
        return <Wallet className="w-3.5 h-3.5 text-rose-400" />;
      default:
        return <Sparkles className="w-3.5 h-3.5 text-sky-400" />;
    }
  };

  const formatTime = (ts: string) => {
    try {
      const date = new Date(ts);
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch {
      return '';
    }
  };

  return (
    <div className="p-6 rounded-2xl bg-atlas-card border border-atlas-border space-y-4 shadow-sm">
      <div className="flex items-center space-x-2">
        <History className="w-5 h-5 text-sky-400" />
        <h2 className="font-bold text-atlas-text text-base">Recent Activity</h2>
      </div>

      <div className="space-y-3">
        {activity.length === 0 ? (
          <div className="text-xs text-atlas-muted text-center py-4">
            No activity recorded yet.
          </div>
        ) : (
          activity.map((item) => (
            <div key={item.id} className="flex items-start space-x-3 text-xs">
              <div className="mt-0.5 p-1 rounded bg-atlas-surface border border-atlas-border shrink-0">
                {getActivityIcon(item.type)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-atlas-text truncate">{item.description}</p>
                <span className="text-[10px] text-atlas-muted font-mono">{formatTime(item.timestamp)}</span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
