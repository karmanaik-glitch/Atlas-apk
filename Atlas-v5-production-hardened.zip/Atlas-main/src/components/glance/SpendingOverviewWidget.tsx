import React, { useState } from 'react';
import { Wallet, Plus, ArrowUpRight } from 'lucide-react';
import { useMonthlySpend, useCategories } from '../../hooks/useAtlasData';
import { financeService } from '../../core/services/financeService';
import { useNavigationStore } from '../../stores/navigationStore';

export const SpendingOverviewWidget: React.FC = () => {
  const { total, byCategory } = useMonthlySpend();
  const { categories } = useCategories();
  const { setActiveTab } = useNavigationStore();

  const [isAdding, setIsAdding] = useState(false);
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('Food & Dining');
  const [merchant, setMerchant] = useState('');

  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) return;

    await financeService.addExpense({
      amount: parsedAmount,
      category,
      merchant: merchant.trim() || undefined,
      date: new Date().toISOString().split('T')[0],
    });

    setAmount('');
    setMerchant('');
    setIsAdding(false);
  };

  // Sort top categories
  const sortedCategories = Object.entries(byCategory)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4);

  return (
    <div className="p-6 rounded-2xl bg-atlas-card border border-atlas-border space-y-4 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Wallet className="w-5 h-5 text-rose-400" />
          <h2 className="font-bold text-atlas-text text-base">Monthly Spending</h2>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsAdding(!isAdding)}
            className="p-1.5 rounded-lg bg-atlas-surface border border-atlas-border text-atlas-muted hover:text-atlas-text transition-all"
            title="Log expense"
          >
            <Plus className="w-4 h-4" />
          </button>
          <button
            onClick={() => setActiveTab('money')}
            className="p-1.5 rounded-lg bg-atlas-surface border border-atlas-border text-atlas-muted hover:text-atlas-text transition-all"
            title="Go to Money section"
          >
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Spend Counter */}
      <div className="p-4 rounded-xl bg-atlas-surface border border-atlas-border flex items-baseline justify-between">
        <div>
          <div className="text-xs text-atlas-muted font-medium">This Month (Total)</div>
          <div className="text-2xl font-bold text-atlas-text font-mono tracking-tight">
            ₹{total.toLocaleString('en-IN')}
          </div>
        </div>
        <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
          In Budget
        </span>
      </div>

      {/* Quick Add Form */}
      {isAdding && (
        <form onSubmit={handleAddExpense} className="p-3 rounded-xl bg-atlas-bg border border-atlas-border space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <input
              type="number"
              placeholder="Amount (₹)"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="px-3 py-1.5 rounded-lg bg-atlas-surface border border-atlas-border text-atlas-text text-xs focus:outline-none focus:border-atlas-accent font-mono"
              autoFocus
              required
            />
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="px-3 py-1.5 rounded-lg bg-atlas-surface border border-atlas-border text-atlas-text text-xs focus:outline-none focus:border-atlas-accent"
            >
              {categories.length > 0 ? (
                categories.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))
              ) : (
                <option value="Food & Dining">Food & Dining</option>
              )}
            </select>
          </div>

          <input
            type="text"
            placeholder="Merchant / Note (optional)"
            value={merchant}
            onChange={(e) => setMerchant(e.target.value)}
            className="w-full px-3 py-1.5 rounded-lg bg-atlas-surface border border-atlas-border text-atlas-text text-xs focus:outline-none focus:border-atlas-accent"
          />

          <div className="flex justify-end space-x-2">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-2.5 py-1 text-atlas-muted text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-3 py-1 rounded bg-atlas-accent text-slate-950 font-bold text-xs"
            >
              Save Expense
            </button>
          </div>
        </form>
      )}

      {/* Category Breakdown Progress Bars */}
      <div className="space-y-2.5 pt-1">
        {sortedCategories.length === 0 ? (
          <div className="text-xs text-atlas-muted text-center py-2">
            No expenses logged yet this month.
          </div>
        ) : (
          sortedCategories.map(([catName, amt]) => {
            const pct = total > 0 ? Math.round((amt / total) * 100) : 0;
            return (
              <div key={catName} className="space-y-1">
                <div className="flex justify-between text-xs font-medium">
                  <span className="text-atlas-text">{catName}</span>
                  <span className="font-mono text-atlas-muted">
                    ₹{amt.toLocaleString('en-IN')} ({pct}%)
                  </span>
                </div>
                <div className="h-1.5 w-full rounded-full bg-atlas-bg overflow-hidden">
                  <div
                    className="h-full bg-indigo-500 rounded-full transition-all duration-500"
                    style={{ width: `${pct}%` }}
                  ></div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
