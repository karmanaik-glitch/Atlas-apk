import React, { useState } from 'react';
import { X, Hourglass } from 'lucide-react';
import { waitingService } from '../../core/services/lifeModuleServices';

interface WaitingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WaitingModal: React.FC<WaitingModalProps> = ({ isOpen, onClose }) => {
  const [title, setTitle] = useState('');
  const [personOrSource, setPersonOrSource] = useState('');
  const [expectedDate, setExpectedDate] = useState('');
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !personOrSource.trim()) return;

    await waitingService.addWaitingItem({
      title: title.trim(),
      personOrSource: personOrSource.trim(),
      expectedDate: expectedDate || undefined,
      notes: notes.trim() || undefined,
      status: 'pending',
    });

    setTitle('');
    setPersonOrSource('');
    setExpectedDate('');
    setNotes('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md max-h-[90vh] overflow-y-auto rounded-2xl bg-atlas-card border border-atlas-border p-6 shadow-2xl space-y-5 animate-fadeIn">
        <div className="flex items-center justify-between border-b border-atlas-border pb-3">
          <div className="flex items-center space-x-2">
            <Hourglass className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-atlas-text text-lg">Log Waiting Item</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-atlas-muted hover:text-atlas-text">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="space-y-1">
            <label className="text-atlas-muted font-semibold">What are you waiting for? *</label>
            <input
              type="text"
              placeholder="e.g. Contractor Quote / Laptop Refund / Email Reply"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text focus:outline-none focus:border-atlas-accent"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-atlas-muted font-semibold">Person / Vendor / Source *</label>
              <input
                type="text"
                placeholder="e.g. John / Amazon / Bank"
                value={personOrSource}
                onChange={(e) => setPersonOrSource(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text focus:outline-none focus:border-atlas-accent"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-atlas-muted font-semibold">Expected By</label>
              <input
                type="date"
                value={expectedDate}
                onChange={(e) => setExpectedDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text focus:outline-none focus:border-atlas-accent"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-atlas-muted font-semibold">Additional Context / Order ID</label>
            <textarea
              placeholder="Notes or tracking details..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              className="w-full px-3.5 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text focus:outline-none focus:border-atlas-accent resize-none font-mono"
            />
          </div>

          <div className="flex items-center justify-end space-x-3 pt-3 border-t border-atlas-border">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-muted hover:text-atlas-text"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold"
            >
              Log Item
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
