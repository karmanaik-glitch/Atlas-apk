import React, { useState } from 'react';
import { X, ShoppingBag } from 'lucide-react';
import { shoppingService } from '../../core/services/lifeModuleServices';

interface ShoppingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShoppingModal: React.FC<ShoppingModalProps> = ({ isOpen, onClose }) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState('Groceries');
  const [quantity, setQuantity] = useState(1);
  const [estimatedPrice, setEstimatedPrice] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const price = parseFloat(estimatedPrice);

    await shoppingService.addShoppingItem({
      name: name.trim(),
      category,
      quantity,
      estimatedPrice: !isNaN(price) && price > 0 ? price : undefined,
    });

    setName('');
    setQuantity(1);
    setEstimatedPrice('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md max-h-[90vh] overflow-y-auto rounded-2xl bg-atlas-card border border-atlas-border p-6 shadow-2xl space-y-5 animate-fadeIn">
        <div className="flex items-center justify-between border-b border-atlas-border pb-3">
          <div className="flex items-center space-x-2">
            <ShoppingBag className="w-5 h-5 text-sky-400" />
            <h3 className="font-bold text-atlas-text text-lg">Add Shopping Item</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-atlas-muted hover:text-atlas-text">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="space-y-1">
            <label className="text-atlas-muted font-semibold">Item Name *</label>
            <input
              type="text"
              placeholder="e.g. Milk / Almonds / HDMI Cable"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text focus:outline-none focus:border-atlas-accent"
              required
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-1">
              <label className="text-atlas-muted font-semibold">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text focus:outline-none focus:border-atlas-accent"
              >
                <option value="Groceries">Groceries</option>
                <option value="Household">Household</option>
                <option value="Tech">Tech</option>
                <option value="Apparel">Apparel</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-atlas-muted font-semibold">Quantity</label>
              <input
                type="number"
                min="1"
                value={quantity}
                onChange={(e) => setQuantity(Math.max(1, Number(e.target.value)))}
                className="w-full px-3 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text focus:outline-none focus:border-atlas-accent font-mono"
              />
            </div>

            <div className="space-y-1">
              <label className="text-atlas-muted font-semibold">Est. Price (₹)</label>
              <input
                type="number"
                placeholder="Optional"
                value={estimatedPrice}
                onChange={(e) => setEstimatedPrice(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text focus:outline-none focus:border-atlas-accent font-mono"
              />
            </div>
          </div>

          <div className="flex items-center justify-end space-x-3 pt-3 border-t border-atlas-border">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-muted hover:text-atlas-text"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-bold"
            >
              Add Item
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
