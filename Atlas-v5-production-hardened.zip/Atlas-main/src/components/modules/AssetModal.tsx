import React, { useState } from 'react';
import { X, Package } from 'lucide-react';
import { assetService } from '../../core/services/lifeModuleServices';

interface AssetModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AssetModal: React.FC<AssetModalProps> = ({ isOpen, onClose }) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState('Electronics');
  const [purchaseDate, setPurchaseDate] = useState('');
  const [purchasePrice, setPurchasePrice] = useState('');
  const [warrantyExpiry, setWarrantyExpiry] = useState('');
  const [serialNumber, setSerialNumber] = useState('');
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const price = parseFloat(purchasePrice);

    await assetService.addAsset({
      name: name.trim(),
      category,
      purchaseDate: purchaseDate || undefined,
      purchasePrice: !isNaN(price) && price > 0 ? price : undefined,
      warrantyExpiry: warrantyExpiry || undefined,
      serialNumber: serialNumber.trim() || undefined,
      notes: notes.trim() || undefined,
    });

    setName('');
    setPurchaseDate('');
    setPurchasePrice('');
    setWarrantyExpiry('');
    setSerialNumber('');
    setNotes('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md max-h-[90vh] overflow-y-auto rounded-2xl bg-atlas-card border border-atlas-border p-6 shadow-2xl space-y-5 animate-fadeIn">
        <div className="flex items-center justify-between border-b border-atlas-border pb-3">
          <div className="flex items-center space-x-2">
            <Package className="w-5 h-5 text-purple-400" />
            <h3 className="font-bold text-atlas-text text-lg">Catalog Asset / Possession</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-atlas-muted hover:text-atlas-text">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="space-y-1">
            <label className="text-atlas-muted font-semibold">Asset Name *</label>
            <input
              type="text"
              placeholder="e.g. MacBook Pro M3 / Sony Headphones"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text focus:outline-none focus:border-atlas-accent"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-atlas-muted font-semibold">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text focus:outline-none focus:border-atlas-accent"
              >
                <option value="Electronics">Electronics</option>
                <option value="Appliance">Appliances</option>
                <option value="Furniture">Furniture</option>
                <option value="Vehicles">Vehicles</option>
                <option value="Personal">Personal Items</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-atlas-muted font-semibold">Purchase Price (₹)</label>
              <input
                type="number"
                placeholder="0.00"
                value={purchasePrice}
                onChange={(e) => setPurchasePrice(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text focus:outline-none focus:border-atlas-accent font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-atlas-muted font-semibold">Purchase Date</label>
              <input
                type="date"
                value={purchaseDate}
                onChange={(e) => setPurchaseDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text focus:outline-none focus:border-atlas-accent"
              />
            </div>

            <div className="space-y-1">
              <label className="text-atlas-muted font-semibold">Warranty Expiry</label>
              <input
                type="date"
                value={warrantyExpiry}
                onChange={(e) => setWarrantyExpiry(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text focus:outline-none focus:border-atlas-accent"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-atlas-muted font-semibold">Serial Number</label>
            <input
              type="text"
              placeholder="S/N or Model Number"
              value={serialNumber}
              onChange={(e) => setSerialNumber(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text focus:outline-none focus:border-atlas-accent font-mono"
            />
          </div>

          <div className="space-y-1">
            <label className="text-atlas-muted font-semibold">Notes / Receipt Location</label>
            <textarea
              placeholder="e.g. Receipt saved in Drive / Invoice #1042"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              className="w-full px-3.5 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text focus:outline-none focus:border-atlas-accent resize-none font-mono"
            />
          </div>

          <div className="flex items-center justify-end space-x-3 pt-3 border-t border-atlas-border">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-muted hover:text-atlas-text"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold"
            >
              Save Asset
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
