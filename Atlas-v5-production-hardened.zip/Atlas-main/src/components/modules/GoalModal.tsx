import React, { useState } from 'react';
import { X, Target, Plus, Trash2 } from 'lucide-react';
import { goalService } from '../../core/services/lifeModuleServices';
import { Goal } from '../../types/models';

interface GoalModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GoalModal: React.FC<GoalModalProps> = ({ isOpen, onClose }) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Personal');
  const [targetDate, setTargetDate] = useState('');
  const [progress, setProgress] = useState(0);
  const [milestones, setMilestones] = useState<string[]>([]);
  const [newMilestone, setNewMilestone] = useState('');

  if (!isOpen) return null;

  const handleAddMilestone = () => {
    if (!newMilestone.trim()) return;
    setMilestones([...milestones, newMilestone.trim()]);
    setNewMilestone('');
  };

  const handleRemoveMilestone = (index: number) => {
    setMilestones(milestones.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    await goalService.addGoal({
      title: title.trim(),
      category,
      targetDate: targetDate || undefined,
      progress,
      milestones: milestones.length > 0 ? milestones : undefined,
      status: 'active',
    });

    setTitle('');
    setTargetDate('');
    setProgress(0);
    setMilestones([]);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md max-h-[90vh] overflow-y-auto rounded-2xl bg-atlas-card border border-atlas-border p-6 shadow-2xl space-y-5 animate-fadeIn">
        <div className="flex items-center justify-between border-b border-atlas-border pb-3">
          <div className="flex items-center space-x-2">
            <Target className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-atlas-text text-lg">Create Life Goal</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-atlas-muted hover:text-atlas-text">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="space-y-1">
            <label className="text-atlas-muted font-semibold">Goal Objective *</label>
            <input
              type="text"
              placeholder="e.g. Save ₹2,00,000 Emergency Fund"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text focus:outline-none focus:border-atlas-accent"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-atlas-muted font-semibold">Domain Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text focus:outline-none focus:border-atlas-accent"
              >
                <option value="Personal">Personal & Life</option>
                <option value="Work">Work & Career</option>
                <option value="Health">Health & Fitness</option>
                <option value="Finance">Finance & Wealth</option>
                <option value="Learning">Learning & Skills</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-atlas-muted font-semibold">Target Date</label>
              <input
                type="date"
                value={targetDate}
                onChange={(e) => setTargetDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text focus:outline-none focus:border-atlas-accent"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between">
              <label className="text-atlas-muted font-semibold">Initial Progress</label>
              <span className="font-mono font-bold text-emerald-400">{progress}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={progress}
              onChange={(e) => setProgress(Number(e.target.value))}
              className="w-full accent-emerald-500"
            />
          </div>

          {/* Milestones */}
          <div className="space-y-2">
            <label className="text-atlas-muted font-semibold">Key Milestones</label>
            <div className="flex space-x-2">
              <input
                type="text"
                placeholder="Add milestone..."
                value={newMilestone}
                onChange={(e) => setNewMilestone(e.target.value)}
                className="flex-1 px-3 py-1.5 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text focus:outline-none focus:border-atlas-accent"
              />
              <button
                type="button"
                onClick={handleAddMilestone}
                className="px-3 py-1.5 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text hover:bg-atlas-surface-hover font-bold"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            {milestones.length > 0 && (
              <div className="space-y-1 max-h-24 overflow-y-auto pt-1">
                {milestones.map((ms, idx) => (
                  <div key={idx} className="p-2 rounded-lg bg-atlas-surface border border-atlas-border flex items-center justify-between">
                    <span className="text-[11px] text-atlas-text">{ms}</span>
                    <button type="button" onClick={() => handleRemoveMilestone(idx)} className="text-atlas-muted hover:text-rose-400">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="flex items-center justify-end space-x-3 pt-3 border-t border-atlas-border">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-muted hover:text-atlas-text"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold"
            >
              Create Goal
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
