import React from 'react';
import { Search, Plus, Moon, Sun, Monitor, ShieldCheck, Menu } from 'lucide-react';
import { useThemeStore } from '../../stores/themeStore';
import { useNavigationStore } from '../../stores/navigationStore';

export const Header: React.FC = () => {
  const { theme, setTheme } = useThemeStore();
  const { setActiveTab, setQuickCaptureOpen } = useNavigationStore();

  const cycleTheme = () => setTheme(theme === 'dark' ? 'light' : theme === 'light' ? 'system' : 'dark');

  return (
    <header className="sticky top-0 z-30 border-b border-atlas-border/80 bg-atlas-bg/90 backdrop-blur-xl">
      <div className="flex h-[68px] items-center justify-between px-4 sm:px-6 lg:px-8">
        <div className="flex min-w-0 items-center gap-3">
          <div className="md:hidden flex h-9 w-9 items-center justify-center rounded-xl border border-atlas-border bg-atlas-card text-atlas-text font-black tracking-[-.08em]">A/</div>
          <div className="hidden sm:block">
            <p className="atlas-kicker">Personal operating system</p>
            <p className="text-sm font-semibold tracking-tight text-atlas-text">Good to see you, Karma</p>
          </div>
          <div className="hidden lg:flex items-center gap-2 rounded-full border border-atlas-border bg-atlas-surface px-3 py-1.5 text-[11px] font-medium text-atlas-muted">
            <ShieldCheck className="h-3.5 w-3.5 text-atlas-accent" /> Local-first
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button onClick={() => setActiveTab('search')} className="atlas-control hidden sm:flex items-center gap-2 px-3 py-2 text-xs text-atlas-muted hover:text-atlas-text" title="Search">
            <Search className="h-4 w-4" /><span>Search</span><kbd className="rounded-md border border-atlas-border bg-atlas-bg px-1.5 py-0.5 font-mono text-[9px]">/</kbd>
          </button>
          <button onClick={() => setQuickCaptureOpen(true)} className="flex h-9 items-center gap-2 rounded-xl bg-atlas-accent px-3.5 text-xs font-bold text-black transition-transform active:scale-95">
            <Plus className="h-4 w-4" strokeWidth={2.7} /><span className="hidden sm:inline">Capture</span>
          </button>
          <button onClick={cycleTheme} className="atlas-control flex h-9 w-9 items-center justify-center" title={`Theme: ${theme}`}>
            {theme === 'dark' ? <Moon className="h-4 w-4" /> : theme === 'light' ? <Sun className="h-4 w-4" /> : <Monitor className="h-4 w-4" />}
          </button>
        </div>
      </div>
    </header>
  );
};
