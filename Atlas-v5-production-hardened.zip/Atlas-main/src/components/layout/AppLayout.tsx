import React, { useEffect } from 'react';
import { Header } from './Header';
import { Sidebar } from './Sidebar';
import { MobileNav } from './MobileNav';
import { QuickCaptureModal } from '../capture/QuickCaptureModal';
import { NotificationBanner } from '../notifications/NotificationBanner';
import { ToastContainer } from '../common/ToastContainer';
import { notificationService } from '../../core/services/notificationService';
import { automationService } from '../../core/services/automationService';
import { useNavigationStore } from '../../stores/navigationStore';
import { GlancePage } from '../../pages/GlancePage';
import { CapturePage } from '../../pages/CapturePage';
import { TasksPage } from '../../pages/TasksPage';
import { HabitsPage } from '../../pages/HabitsPage';
import { MoneyPage } from '../../pages/MoneyPage';
import { LifePage } from '../../pages/LifePage';
import { SearchPage } from '../../pages/SearchPage';
import { ActivityPage } from '../../pages/ActivityPage';
import { AutomationsPage } from '../../pages/AutomationsPage';
import { SettingsPage } from '../../pages/SettingsPage';
import { useNativeLifecycle } from '../../hooks/useNativeLifecycle';
import { onNativeUrlOpen } from '../../core/services/nativeService';
import { getNativeCaptureText } from '../../core/services/nativeCapture';

export const AppLayout: React.FC = () => {
  const { activeTab, setActiveTab, setQuickCaptureOpen, isQuickCaptureOpen } = useNavigationStore();
  useNativeLifecycle();

  useEffect(() => {
    const stopEngine = notificationService.startNotificationEngine(20000);
    automationService.seedDefaultTemplates();
    const autoInterval = setInterval(() => automationService.evaluateAutomations(), 30000);
    const onKey = (e: KeyboardEvent) => {
      const el = document.activeElement as HTMLElement | null;
      const input = !!el && ['INPUT','TEXTAREA','SELECT'].includes(el.tagName);
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setQuickCaptureOpen(!isQuickCaptureOpen); }
      if (e.key === '/' && !input) { e.preventDefault(); setActiveTab('search'); }
      if (e.key === 'Escape' && isQuickCaptureOpen) setQuickCaptureOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => { stopEngine(); clearInterval(autoInterval); window.removeEventListener('keydown', onKey); };
  }, [setActiveTab, setQuickCaptureOpen, isQuickCaptureOpen]);

  useEffect(() => {
    const stop = onNativeUrlOpen((url) => {
      const route = url.split('://')[1]?.split('?')[0]?.replace(/^\//, '');
      const routes: Record<string, any> = { home: 'glance', capture: 'capture', tasks: 'tasks', habits: 'habits', money: 'money', life: 'life', search: 'search', activity: 'activity', automations: 'automations', settings: 'settings' };
      const target = routes[route];
      if (target) setActiveTab(target);
      if (route === 'capture') {
        const sharedText = getNativeCaptureText(url);
        setQuickCaptureOpen(true);
        if (sharedText) window.dispatchEvent(new CustomEvent('atlas:native-capture', { detail: { text: sharedText } }));
      }
    });
    return stop;
  }, [setActiveTab, setQuickCaptureOpen]);
  const page = ({glance:<GlancePage/>,capture:<CapturePage/>,tasks:<TasksPage/>,habits:<HabitsPage/>,money:<MoneyPage/>,life:<LifePage/>,search:<SearchPage/>,activity:<ActivityPage/>,automations:<AutomationsPage/>,settings:<SettingsPage/>} as any)[activeTab] || <GlancePage/>;
  return <div className="flex h-screen overflow-hidden bg-atlas-bg text-atlas-text"><Sidebar/><div className="flex min-w-0 flex-1 flex-col overflow-hidden"><Header/><main className="min-h-0 flex-1 overflow-y-auto overscroll-contain">{page}</main><MobileNav/></div><NotificationBanner/><QuickCaptureModal/><ToastContainer/></div>;
};
