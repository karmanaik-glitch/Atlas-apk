import React from 'react';
import { LayoutDashboard, Plus, CheckSquare, Flame, Wallet, HeartHandshake, Search, History, Settings, Zap, Compass } from 'lucide-react';
import { useNavigationStore } from '../../stores/navigationStore';
import { NavTab } from '../../types/navigation';

const primary: { id: NavTab; label: string; icon: React.ElementType }[] = [
  { id: 'glance', label: 'Overview', icon: LayoutDashboard },
  { id: 'tasks', label: 'Tasks', icon: CheckSquare },
  { id: 'habits', label: 'Habits', icon: Flame },
  { id: 'money', label: 'Money', icon: Wallet },
  { id: 'life', label: 'Life', icon: HeartHandshake },
];
const system: { id: NavTab; label: string; icon: React.ElementType }[] = [
  { id: 'search', label: 'Search', icon: Search },
  { id: 'activity', label: 'Activity', icon: History },
  { id: 'automations', label: 'Automations', icon: Zap },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab, setQuickCaptureOpen } = useNavigationStore();
  const item = (x: typeof primary[number]) => {
    const Icon = x.icon; const active = activeTab === x.id;
    return <button key={x.id} onClick={() => setActiveTab(x.id)} className={`group flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all ${active ? 'bg-atlas-accent text-black font-semibold' : 'text-atlas-muted hover:bg-atlas-surface-hover hover:text-atlas-text'}`}><Icon className="h-4 w-4" /><span>{x.label}</span></button>;
  };
  return <aside className="hidden h-screen w-[252px] shrink-0 border-r border-atlas-border bg-atlas-surface md:flex md:flex-col">
    <div className="flex h-[84px] items-center gap-3 border-b border-atlas-border px-6">
      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-atlas-text text-atlas-bg"><Compass className="h-5 w-5" /></div>
      <div><div className="font-black tracking-[-.06em] text-atlas-text">ATLAS</div><div className="text-[9px] font-bold uppercase tracking-[.18em] text-atlas-muted">Personal OS</div></div>
    </div>
    <div className="px-4 pt-5">
      <button onClick={() => setQuickCaptureOpen(true)} className="mb-5 flex w-full items-center justify-between rounded-xl border border-atlas-border bg-atlas-card px-3 py-2.5 text-xs font-semibold text-atlas-text hover:border-atlas-accent/50"><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Quick capture</span><kbd className="font-mono text-[9px] text-atlas-muted">⌘K</kbd></button>
      <p className="atlas-kicker px-3 pb-2">Workspace</p><nav className="space-y-1">{primary.map(item)}</nav>
      <p className="atlas-kicker mt-7 px-3 pb-2">System</p><nav className="space-y-1">{system.map(item as any)}</nav>
    </div>
    <div className="mt-auto border-t border-atlas-border p-4"><div className="rounded-xl bg-atlas-bg p-3"><div className="flex items-center justify-between"><span className="text-[10px] font-semibold uppercase tracking-[.14em] text-atlas-muted">Storage</span><span className="h-2 w-2 rounded-full bg-atlas-accent" /></div><div className="mt-2 text-xs font-medium text-atlas-text">Private · Offline ready</div><div className="mt-1 text-[10px] text-atlas-muted">Your data stays on this device.</div></div></div>
  </aside>;
};
