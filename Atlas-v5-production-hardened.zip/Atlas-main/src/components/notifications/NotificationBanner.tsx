import React, { useState, useEffect } from 'react';
import { Bell, X, CheckCircle2 } from 'lucide-react';
import { notificationService } from '../../core/services/notificationService';

export const NotificationBanner: React.FC = () => {
  const [showBanner, setShowBanner] = useState(false);

  useEffect(() => {
    if (notificationService.isSupported() && notificationService.getPermissionStatus() === 'default') {
      const dismissed = localStorage.getItem('atlas_notif_banner_dismissed');
      if (!dismissed) {
        setShowBanner(true);
      }
    }
  }, []);

  if (!showBanner) return null;

  const handleEnable = async () => {
    const perm = await notificationService.requestPermission();
    if (perm === 'granted') {
      notificationService.sendNotification('Project Atlas Notifications Enabled', {
        body: 'You will now receive timely reminders and alerts.',
      });
    }
    setShowBanner(false);
  };

  const handleDismiss = () => {
    localStorage.setItem('atlas_notif_banner_dismissed', 'true');
    setShowBanner(false);
  };

  return (
    <div className="bg-indigo-600/20 border-b border-indigo-500/30 px-4 py-2 text-xs flex items-center justify-between animate-fadeIn">
      <div className="flex items-center space-x-2 text-indigo-200">
        <Bell className="w-4 h-4 text-indigo-400 shrink-0" />
        <span>Enable desktop notifications to receive timely task and reminder alerts.</span>
      </div>

      <div className="flex items-center space-x-2 shrink-0">
        <button
          onClick={handleEnable}
          className="px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-[11px] transition-all flex items-center space-x-1"
        >
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>Enable</span>
        </button>

        <button
          onClick={handleDismiss}
          className="p-1 text-atlas-muted hover:text-atlas-text"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
