import React, { useEffect, useState } from 'react';
import { X, Plus, CheckSquare, Wallet, Flame, FileText, CheckCircle2, Mic } from 'lucide-react';
import { useNavigationStore } from '../../stores/navigationStore';
import { taskService } from '../../core/services/taskService';
import { financeService } from '../../core/services/financeService';
import { habitService } from '../../core/services/habitService';
import { noteService } from '../../core/services/noteService';
import { useCategories } from '../../hooks/useAtlasData';
import { VoiceCaptureModal } from '../voice/VoiceCaptureModal';
import { tapHaptic } from '../../core/services/nativeService';

type CaptureType = 'task' | 'expense' | 'habit' | 'note';

export const QuickCaptureModal: React.FC = () => {
  const { isQuickCaptureOpen, setQuickCaptureOpen } = useNavigationStore();
  const { categories } = useCategories();
  const [captureType, setCaptureType] = useState<CaptureType>('task');
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);

  // Form states
  const [taskTitle, setTaskTitle] = useState('');
  const [taskPriority, setTaskPriority] = useState<'low' | 'medium' | 'high'>('medium');

  const [expenseAmount, setExpenseAmount] = useState('');
  const [expenseCategory, setExpenseCategory] = useState('Food & Dining');

  const [habitName, setHabitName] = useState('');

  const [noteTitle, setNoteTitle] = useState('');
  const [noteContent, setNoteContent] = useState('');

  const [successMsg, setSuccessMsg] = useState('');

  useEffect(() => {
    const onNativeCapture = (event: Event) => {
      const text = (event as CustomEvent<{ text?: string }>).detail?.text?.trim();
      if (!text) return;
      setCaptureType('note');
      setNoteTitle(text.slice(0, 80));
      setNoteContent(text);
      setQuickCaptureOpen(true);
      void tapHaptic();
    };
    window.addEventListener('atlas:native-capture', onNativeCapture);
    return () => window.removeEventListener('atlas:native-capture', onNativeCapture);
  }, [setQuickCaptureOpen]);

  if (!isQuickCaptureOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMsg('');

    try {
      if (captureType === 'task') {
        if (!taskTitle.trim()) return;
        await taskService.addTask({
          title: taskTitle.trim(),
          priority: taskPriority,
          status: 'today',
          dueDate: new Date().toISOString().split('T')[0],
        });
        setTaskTitle('');
        setSuccessMsg('Task added to Today!');
        void tapHaptic();
      } else if (captureType === 'expense') {
        const amt = parseFloat(expenseAmount);
        if (isNaN(amt) || amt <= 0) return;
        await financeService.addExpense({
          amount: amt,
          category: expenseCategory,
          date: new Date().toISOString().split('T')[0],
        });
        setExpenseAmount('');
        setSuccessMsg('Expense logged!');
        void tapHaptic();
      } else if (captureType === 'habit') {
        if (!habitName.trim()) return;
        await habitService.addHabit({
          name: habitName.trim(),
          frequency: 'daily',
        });
        setHabitName('');
        setSuccessMsg('Habit created!');
        void tapHaptic();
      } else if (captureType === 'note') {
        if (!noteTitle.trim()) return;
        await noteService.addNote({
          title: noteTitle.trim(),
          content: noteContent.trim(),
        });
        setNoteTitle('');
        setNoteContent('');
        setSuccessMsg('Note saved!');
        void tapHaptic();
      }

      setTimeout(() => {
        setSuccessMsg('');
        setQuickCaptureOpen(false);
      }, 600);
    } catch (err) {
      console.error('Quick capture error:', err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-atlas-bg/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-md max-h-[90vh] overflow-y-auto rounded-2xl bg-atlas-card border border-atlas-border p-6 shadow-2xl space-y-5 animate-fadeIn">
        <div className="flex items-center justify-between border-b border-atlas-border pb-3">
          <div className="flex items-center space-x-2">
            <Plus className="w-5 h-5 text-atlas-text" />
            <h3 className="font-bold text-atlas-text text-lg">Quick Capture</h3>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setIsVoiceModalOpen(true)}
              className="px-2.5 py-1 rounded-lg bg-atlas-surface border border-atlas-border text-atlas-text text-xs font-semibold flex items-center space-x-1 hover:bg-atlas-surface-hover transition-all"
              title="Voice Dictation"
            >
              <Mic className="w-3.5 h-3.5" />
              <span>Voice</span>
            </button>
            <button onClick={() => setQuickCaptureOpen(false)} className="p-1 rounded-lg text-atlas-muted hover:text-atlas-text">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Capture Type Selector */}
        <div className="grid grid-cols-4 gap-2">
          {[
            { id: 'task' as CaptureType, label: 'Task', icon: CheckSquare, color: 'text-indigo-400' },
            { id: 'expense' as CaptureType, label: 'Expense', icon: Wallet, color: 'text-rose-400' },
            { id: 'habit' as CaptureType, label: 'Habit', icon: Flame, color: 'text-atlas-text' },
            { id: 'note' as CaptureType, label: 'Note', icon: FileText, color: 'text-sky-400' },
          ].map((type) => {
            const Icon = type.icon;
            const isSelected = captureType === type.id;
            return (
              <button
                key={type.id}
                onClick={() => setCaptureType(type.id)}
                className={`p-3 rounded-xl border flex flex-col items-center justify-center space-y-1 transition-all ${
                  isSelected
                    ? 'bg-atlas-accent/15 border-atlas-accent text-atlas-text font-semibold'
                    : 'bg-atlas-surface border-atlas-border text-atlas-muted hover:text-atlas-text'
                }`}
              >
                <Icon className={`w-4 h-4 ${type.color}`} />
                <span className="text-[11px]">{type.label}</span>
              </button>
            );
          })}
        </div>

        {successMsg ? (
          <div className="p-4 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-atlas-text text-xs font-semibold flex items-center justify-center space-x-2 animate-fadeIn">
            <CheckCircle2 className="w-4 h-4" />
            <span>{successMsg}</span>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            {/* Quick Task */}
            {captureType === 'task' && (
              <div className="space-y-3">
                <input
                  type="text"
                  placeholder="Task title..."
                  value={taskTitle}
                  onChange={(e) => setTaskTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text text-sm focus:outline-none focus:border-atlas-accent"
                  autoFocus
                  required
                />
                <div className="flex items-center justify-between text-xs">
                  <span className="text-atlas-muted">Priority:</span>
                  <div className="flex space-x-1">
                    {(['low', 'medium', 'high'] as const).map((p) => (
                      <button
                        key={p}
                        type="button"
                        onClick={() => setTaskPriority(p)}
                        className={`px-2.5 py-1 rounded text-[10px] uppercase font-semibold border ${
                          taskPriority === p
                            ? 'bg-atlas-accent/20 border-atlas-accent text-atlas-text'
                            : 'border-atlas-border text-atlas-muted'
                        }`}
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Quick Expense */}
            {captureType === 'expense' && (
              <div className="space-y-3">
                <input
                  type="number"
                  placeholder="Amount (₹)"
                  value={expenseAmount}
                  onChange={(e) => setExpenseAmount(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text text-sm font-mono font-bold focus:outline-none focus:border-atlas-accent"
                  autoFocus
                  required
                />
                <select
                  value={expenseCategory}
                  onChange={(e) => setExpenseCategory(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text text-xs focus:outline-none focus:border-atlas-accent"
                >
                  {categories.length > 0 ? (
                    categories.map((c) => (
                      <option key={c.id} value={c.name}>
                        {c.name}
                      </option>
                    ))
                  ) : (
                    <option value="Food & Dining">Food & Dining</option>
                  )}
                </select>
              </div>
            )}

            {/* Quick Habit */}
            {captureType === 'habit' && (
              <div className="space-y-3">
                <input
                  type="text"
                  placeholder="Habit name (e.g., Read 15 mins)..."
                  value={habitName}
                  onChange={(e) => setHabitName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text text-sm focus:outline-none focus:border-atlas-accent"
                  autoFocus
                  required
                />
              </div>
            )}

            {/* Quick Note */}
            {captureType === 'note' && (
              <div className="space-y-3">
                <input
                  type="text"
                  placeholder="Note title..."
                  value={noteTitle}
                  onChange={(e) => setNoteTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text text-sm focus:outline-none focus:border-atlas-accent"
                  autoFocus
                  required
                />
                <textarea
                  placeholder="Note content..."
                  value={noteContent}
                  onChange={(e) => setNoteContent(e.target.value)}
                  rows={3}
                  className="w-full px-3.5 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text text-xs focus:outline-none focus:border-atlas-accent resize-none font-mono"
                />
              </div>
            )}

            <div className="flex items-center justify-end space-x-3 pt-3 border-t border-atlas-border">
              <button
                type="button"
                onClick={() => setQuickCaptureOpen(false)}
                className="px-4 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-muted hover:text-atlas-text transition-all"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-atlas-accent hover:brightness-95 text-slate-950 font-bold text-xs shadow-lg transition-all active:scale-95"
              >
                Save {captureType.charAt(0).toUpperCase() + captureType.slice(1)}
              </button>
            </div>
          </form>
        )}
      </div>

      <VoiceCaptureModal isOpen={isVoiceModalOpen} onClose={() => setIsVoiceModalOpen(false)} />
    </div>
  );
};
