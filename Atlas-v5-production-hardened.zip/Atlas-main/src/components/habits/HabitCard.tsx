import React, { useState } from 'react';
import { Flame, Check, Award, Trash2, Calendar } from 'lucide-react';
import { Habit } from '../../types/models';
import { habitService } from '../../core/services/habitService';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../../db/schema';

interface HabitCardProps {
  habit: Habit;
}

export const HabitCard: React.FC<HabitCardProps> = ({ habit }) => {
  const [isDeleting, setIsDeleting] = useState(false);
  const todayStr = new Date().toISOString().split('T')[0];

  // Fetch last 14 days records for this habit
  const habitRecords = useLiveQuery(
    async () => {
      if (!habit.id) return [];
      return await db.habitRecords.where({ habitId: habit.id }).toArray();
    },
    [habit.id]
  );

  const isCompletedToday = habit.lastCompletedDate === todayStr;

  // Build array of past 14 dates (oldest to newest)
  const past14Days = Array.from({ length: 14 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (13 - i));
    return d.toISOString().split('T')[0];
  });

  const recordMap = new Set((habitRecords || []).filter((r) => r.status === 'completed').map((r) => r.date));

  const handleDelete = async () => {
    if (habit.id) {
      await habitService.deleteHabit(habit.id);
    }
  };

  return (
    <div className="p-5 rounded-2xl bg-atlas-card border border-atlas-border space-y-4 hover:border-atlas-muted transition-all shadow-sm">
      {/* Header Info */}
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <h3 className="font-bold text-atlas-text text-base">{habit.name}</h3>
          <div className="flex items-center space-x-3 text-xs font-mono">
            <div className="flex items-center space-x-1 text-atlas-text font-semibold">
              <Flame className="w-4 h-4 fill-atlas-text/20" />
              <span>{habit.streak} day streak</span>
            </div>
            <div className="flex items-center space-x-1 text-atlas-text">
              <Award className="w-3.5 h-3.5" />
              <span>Best: {habit.bestStreak}d</span>
            </div>
          </div>
        </div>

        {/* Completion Button */}
        <button
          onClick={() => habit.id && habitService.toggleHabitCompletion(habit.id)}
          className={`px-4 py-2 rounded-xl font-bold text-xs transition-all flex items-center space-x-1.5 active:scale-95 ${
            isCompletedToday
              ? 'bg-atlas-accent text-slate-950 shadow-glow'
              : 'bg-atlas-surface border border-atlas-border text-atlas-muted hover:text-atlas-text hover:border-atlas-accent/50'
          }`}
        >
          {isCompletedToday ? (
            <>
              <Check className="w-4 h-4 stroke-[3]" />
              <span>Done Today</span>
            </>
          ) : (
            <span>Mark Complete</span>
          )}
        </button>
      </div>

      {/* 14-Day Visual Heatmap */}
      <div className="space-y-1.5 pt-2 border-t border-atlas-border/60">
        <div className="flex items-center justify-between text-[10px] text-atlas-muted font-mono uppercase">
          <span>Past 14 Days</span>
          <span>Today</span>
        </div>

        <div className="grid grid-cols-14 gap-1">
          {past14Days.map((dateStr) => {
            const isDone = recordMap.has(dateStr);
            const isToday = dateStr === todayStr;

            return (
              <div
                key={dateStr}
                className={`h-7 rounded-md flex items-center justify-center text-[9px] font-mono transition-all ${
                  isDone
                    ? 'bg-atlas-accent text-slate-950 font-bold shadow-sm'
                    : isToday
                    ? 'bg-atlas-surface border border-atlas-accent/50 text-atlas-text'
                    : 'bg-atlas-bg border border-atlas-border/50 text-atlas-muted/40'
                }`}
                title={`${dateStr}: ${isDone ? 'Completed' : 'Missed'}`}
              >
                {isDone ? '✓' : ''}
              </div>
            );
          })}
        </div>
      </div>

      {/* Footer Controls */}
      <div className="flex justify-end pt-1">
        {isDeleting ? (
          <div className="flex items-center space-x-2">
            <button
              onClick={handleDelete}
              className="px-2.5 py-1 rounded bg-rose-500 text-white font-bold text-[10px]"
            >
              Confirm Delete
            </button>
            <button
              onClick={() => setIsDeleting(false)}
              className="px-2 py-1 text-atlas-muted text-[10px]"
            >
              Cancel
            </button>
          </div>
        ) : (
          <button
            onClick={() => setIsDeleting(true)}
            className="text-[11px] text-atlas-muted hover:text-atlas-text transition-colors flex items-center space-x-1"
          >
            <Trash2 className="w-3 h-3" />
            <span>Delete</span>
          </button>
        )}
      </div>
    </div>
  );
};
