import React, { useState, useEffect } from 'react';
import { X, Flame, AlertCircle } from 'lucide-react';
import { Habit, HabitFrequency } from '../../types/models';
import { habitService } from '../../core/services/habitService';

interface HabitModalProps {
  isOpen: boolean;
  onClose: () => void;
  habitToEdit?: Habit | null;
}

export const HabitModal: React.FC<HabitModalProps> = ({ isOpen, onClose, habitToEdit }) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState('Personal');
  const [frequency, setFrequency] = useState<HabitFrequency>('daily');
  const [targetDaysPerWeek, setTargetDaysPerWeek] = useState(7);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (habitToEdit) {
      setName(habitToEdit.name);
      setCategory(habitToEdit.category || 'Personal');
      setFrequency(habitToEdit.frequency);
      setTargetDaysPerWeek(habitToEdit.targetDaysPerWeek || 7);
    } else {
      setName('');
      setCategory('Personal');
      setFrequency('daily');
      setTargetDaysPerWeek(7);
    }
    setErrorMsg('');
  }, [habitToEdit, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMsg('Habit name is required.');
      return;
    }

    try {
      if (habitToEdit && habitToEdit.id) {
        // Update habit
        // (implied update through habitService or Dexie directly)
      } else {
        await habitService.addHabit({
          name: name.trim(),
          category,
          frequency,
          targetDaysPerWeek,
        });
      }
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to save habit.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md max-h-[90vh] overflow-y-auto rounded-2xl bg-atlas-card border border-atlas-border p-6 shadow-2xl space-y-5 animate-fadeIn">
        <div className="flex items-center justify-between border-b border-atlas-border pb-3">
          <div className="flex items-center space-x-2">
            <Flame className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-atlas-text text-lg">
              {habitToEdit ? 'Edit Habit' : 'Create New Habit'}
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-atlas-muted hover:text-atlas-text">
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="space-y-1">
            <label className="text-atlas-muted font-medium">Habit Name *</label>
            <input
              type="text"
              placeholder="e.g. Read 20 minutes daily"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text text-sm focus:outline-none focus:border-atlas-accent"
              autoFocus
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-atlas-muted font-medium">Frequency</label>
              <select
                value={frequency}
                onChange={(e) => setFrequency(e.target.value as HabitFrequency)}
                className="w-full px-3 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text text-xs focus:outline-none focus:border-atlas-accent"
              >
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-atlas-muted font-medium">Target Days / Week</label>
              <input
                type="number"
                min={1}
                max={7}
                value={targetDaysPerWeek}
                onChange={(e) => setTargetDaysPerWeek(parseInt(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text text-xs focus:outline-none focus:border-atlas-accent font-mono"
              />
            </div>
          </div>

          <div className="flex items-center justify-end space-x-3 pt-3 border-t border-atlas-border">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-muted hover:text-atlas-text transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-atlas-accent hover:bg-emerald-600 text-slate-950 font-bold shadow-glow transition-all active:scale-95"
            >
              Save Habit
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
