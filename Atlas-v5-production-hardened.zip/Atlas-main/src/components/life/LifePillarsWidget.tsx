import React from 'react';
import { User, Briefcase, Heart, Wallet, BookOpen, Layers } from 'lucide-react';
import { useTasks, useNotes } from '../../hooks/useAtlasData';

interface Pillar {
  id: string;
  name: string;
  description: string;
  icon: any;
  color: string;
}

const PILLARS: Pillar[] = [
  { id: 'personal', name: 'Personal & Life', description: 'Daily routines, hobbies, and personal goals', icon: User, color: 'text-emerald-400 bg-emerald-500/15' },
  { id: 'work', name: 'Work & Career', description: 'Projects, deadlines, and professional growth', icon: Briefcase, color: 'text-indigo-400 bg-indigo-500/15' },
  { id: 'health', name: 'Health & Fitness', description: 'Habits, workouts, hydration, and wellness', icon: Heart, color: 'text-rose-400 bg-rose-500/15' },
  { id: 'finance', name: 'Finance & Money', description: 'Budgets, expenses, savings, and investments', icon: Wallet, color: 'text-amber-400 bg-amber-500/15' },
  { id: 'learning', name: 'Learning & Notes', description: 'Books, research notes, and skill development', icon: BookOpen, color: 'text-sky-400 bg-sky-500/15' },
];

export const LifePillarsWidget: React.FC = () => {
  const { tasks } = useTasks();
  const { notes } = useNotes();

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <Layers className="w-5 h-5 text-indigo-400" />
        <h2 className="font-bold text-atlas-text text-base">Life Pillars & Areas</h2>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {PILLARS.map((pillar) => {
          const Icon = pillar.icon;
          const relatedTasksCount = tasks.filter(
            (t) => (t.category || '').toLowerCase().includes(pillar.id) || (t.category || '').toLowerCase().includes(pillar.name.split(' ')[0].toLowerCase())
          ).length;

          return (
            <div
              key={pillar.id}
              className="p-5 rounded-2xl bg-atlas-card border border-atlas-border hover:border-atlas-muted transition-all space-y-3 shadow-sm"
            >
              <div className="flex items-center justify-between">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${pillar.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-[11px] font-mono text-atlas-muted px-2 py-0.5 rounded bg-atlas-bg border border-atlas-border">
                  {relatedTasksCount} items
                </span>
              </div>

              <div>
                <h3 className="font-bold text-atlas-text text-sm">{pillar.name}</h3>
                <p className="text-xs text-atlas-muted mt-0.5">{pillar.description}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
