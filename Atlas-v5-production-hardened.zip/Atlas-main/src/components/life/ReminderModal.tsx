import React, { useState } from 'react';
import { X, Bell, AlertCircle } from 'lucide-react';
import { reminderService } from '../../core/services/reminderService';

interface ReminderModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReminderModal: React.FC<ReminderModalProps> = ({ isOpen, onClose }) => {
  const [title, setTitle] = useState('');
  const [datetime, setDatetime] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !datetime) {
      setErrorMsg('Title and scheduled date/time are required.');
      return;
    }

    try {
      await reminderService.addReminder({
        title: title.trim(),
        datetime: new Date(datetime).toISOString(),
        entityType: 'custom',
      });

      setTitle('');
      setDatetime('');
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to save reminder.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md max-h-[90vh] overflow-y-auto rounded-2xl bg-atlas-card border border-atlas-border p-6 shadow-2xl space-y-5 animate-fadeIn">
        <div className="flex items-center justify-between border-b border-atlas-border pb-3">
          <div className="flex items-center space-x-2">
            <Bell className="w-5 h-5 text-indigo-400" />
            <h3 className="font-bold text-atlas-text text-lg">Set Reminder</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-atlas-muted hover:text-atlas-text">
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="space-y-1">
            <label className="text-atlas-muted font-medium">Reminder Title *</label>
            <input
              type="text"
              placeholder="e.g. Call dentist or submit weekly report"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text text-sm focus:outline-none focus:border-atlas-accent"
              autoFocus
              required
            />
          </div>

          <div className="space-y-1">
            <label className="text-atlas-muted font-medium">Date & Time *</label>
            <input
              type="datetime-local"
              value={datetime}
              onChange={(e) => setDatetime(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text text-xs focus:outline-none focus:border-atlas-accent"
              required
            />
          </div>

          <div className="flex items-center justify-end space-x-3 pt-3 border-t border-atlas-border">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-muted hover:text-atlas-text transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-all active:scale-95"
            >
              Set Reminder
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
