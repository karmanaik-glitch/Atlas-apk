import React, { useState } from 'react';
import { X, Zap, ArrowRight } from 'lucide-react';
import { automationService } from '../../core/services/automationService';
import { TriggerType, ActionType } from '../../types/models';

interface AutomationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AutomationModal: React.FC<AutomationModalProps> = ({ isOpen, onClose }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [triggerType, setTriggerType] = useState<TriggerType>('schedule');
  const [scheduleTime, setScheduleTime] = useState('19:00');
  const [scheduleDay, setScheduleDay] = useState('Friday');
  const [actionType, setActionType] = useState<ActionType>('send_notification');
  const [actionTitle, setActionTitle] = useState('');
  const [actionBody, setActionBody] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    await automationService.addRule({
      name: name.trim(),
      description: description.trim() || undefined,
      triggerType,
      triggerConfig: {
        scheduleTime,
        scheduleDays: [scheduleDay],
      },
      actionType,
      actionConfig: {
        title: actionTitle.trim() || name.trim(),
        body: actionBody.trim() || undefined,
      },
      isActive: true,
    });

    setName('');
    setDescription('');
    setActionTitle('');
    setActionBody('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md max-h-[90vh] overflow-y-auto rounded-2xl bg-atlas-card border border-atlas-border p-6 shadow-2xl space-y-5 animate-fadeIn">
        <div className="flex items-center justify-between border-b border-atlas-border pb-3">
          <div className="flex items-center space-x-2">
            <Zap className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-atlas-text text-lg">Build Automation Rule</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-atlas-muted hover:text-atlas-text">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="space-y-1">
            <label className="text-atlas-muted font-semibold">Automation Name *</label>
            <input
              type="text"
              placeholder="e.g. Friday Evening Spending Audit"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text focus:outline-none focus:border-atlas-accent"
              required
            />
          </div>

          {/* Trigger Section */}
          <div className="p-3.5 rounded-xl bg-atlas-surface border border-atlas-border space-y-3">
            <div className="font-mono text-amber-400 font-bold uppercase text-[10px]">1. Trigger Configuration</div>

            <div className="grid grid-cols-2 gap-2">
              <select
                value={scheduleDay}
                onChange={(e) => setScheduleDay(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-atlas-card border border-atlas-border text-atlas-text focus:outline-none"
              >
                <option value="daily">Every Day</option>
                <option value="Monday">Every Monday</option>
                <option value="Friday">Every Friday</option>
                <option value="Sunday">Every Sunday</option>
              </select>

              <input
                type="time"
                value={scheduleTime}
                onChange={(e) => setScheduleTime(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-atlas-card border border-atlas-border text-atlas-text focus:outline-none font-mono"
              />
            </div>
          </div>

          <div className="flex justify-center">
            <ArrowRight className="w-4 h-4 text-atlas-muted rotate-90" />
          </div>

          {/* Action Section */}
          <div className="p-3.5 rounded-xl bg-atlas-surface border border-atlas-border space-y-3">
            <div className="font-mono text-indigo-400 font-bold uppercase text-[10px]">2. Action Execution</div>

            <select
              value={actionType}
              onChange={(e) => setActionType(e.target.value as ActionType)}
              className="w-full px-3 py-2 rounded-xl bg-atlas-card border border-atlas-border text-atlas-text focus:outline-none"
            >
              <option value="send_notification">Send Desktop Browser Notification</option>
              <option value="create_task">Create Daily Review Task</option>
            </select>

            <input
              type="text"
              placeholder="Action Title / Notification Headline"
              value={actionTitle}
              onChange={(e) => setActionTitle(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-atlas-card border border-atlas-border text-atlas-text focus:outline-none"
            />
          </div>

          <div className="flex items-center justify-end space-x-3 pt-3 border-t border-atlas-border">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-muted hover:text-atlas-text"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold"
            >
              Save Automation Rule
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
