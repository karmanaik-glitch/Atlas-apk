import React, { useState } from 'react';
import { Check, Calendar, Clock, Edit2, Trash2, FastForward, Tag } from 'lucide-react';
import { Task, TaskPriority } from '../../types/models';
import { taskService } from '../../core/services/taskService';

interface TaskCardProps {
  task: Task;
  onEdit: (task: Task) => void;
}

export const TaskCard: React.FC<TaskCardProps> = ({ task, onEdit }) => {
  const [isDeleting, setIsDeleting] = useState(false);
  const isCompleted = task.status === 'completed';

  const handleToggleComplete = () => {
    if (task.id) taskService.toggleTaskComplete(task.id);
  };

  const handlePostpone = (days: number) => {
    if (!task.id) return;
    const baseDate = task.dueDate ? new Date(task.dueDate) : new Date();
    baseDate.setDate(baseDate.getDate() + days);
    const newDueDateStr = baseDate.toISOString().split('T')[0];

    taskService.updateTask(task.id, {
      dueDate: newDueDateStr,
      status: newDueDateStr === new Date().toISOString().split('T')[0] ? 'today' : 'upcoming',
    });
  };

  const handleDelete = async () => {
    if (task.id) {
      await taskService.deleteTask(task.id);
    }
  };

  const getPriorityBadge = (priority: TaskPriority) => {
    switch (priority) {
      case 'high':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-500/15 text-atlas-text border border-rose-500/20">High</span>;
      case 'medium':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/15 text-amber-400 border border-amber-500/20">Medium</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-500/15 text-slate-400 border border-slate-500/20">Low</span>;
    }
  };

  return (
    <div
      className={`p-4 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 group ${
        isCompleted
          ? 'bg-atlas-bg/40 border-atlas-border/50 opacity-60'
          : 'bg-atlas-surface border-atlas-border hover:border-atlas-muted shadow-sm'
      }`}
    >
      {/* Left: Checkbox + Info */}
      <div className="flex items-start space-x-3 min-w-0 flex-1">
        <button
          onClick={handleToggleComplete}
          className={`w-5 h-5 mt-0.5 rounded-md border flex items-center justify-center transition-all shrink-0 ${
            isCompleted
              ? 'bg-atlas-accent border-atlas-accent text-slate-950 shadow-glow'
              : 'border-atlas-muted hover:border-atlas-text text-transparent'
          }`}
        >
          <Check className="w-3.5 h-3.5 stroke-[3]" />
        </button>

        <div className="space-y-1 min-w-0">
          <div className="flex items-center space-x-2 flex-wrap">
            <span className={`text-sm font-semibold truncate ${isCompleted ? 'line-through text-atlas-muted' : 'text-atlas-text'}`}>
              {task.title}
            </span>
            {getPriorityBadge(task.priority)}
            {task.category && (
              <span className="text-[10px] px-2 py-0.5 rounded bg-atlas-bg border border-atlas-border text-atlas-text font-mono">
                {task.category}
              </span>
            )}
          </div>

          {task.description && (
            <p className="text-xs text-atlas-muted line-clamp-2">{task.description}</p>
          )}

          {/* Meta Info */}
          <div className="flex items-center space-x-3 text-[11px] text-atlas-muted pt-0.5 font-mono">
            {task.dueDate && (
              <span className="flex items-center space-x-1">
                <Calendar className="w-3 h-3 text-atlas-text" />
                <span>{task.dueDate}</span>
              </span>
            )}
            {task.recurrence && task.recurrence !== 'none' && (
              <span className="px-1.5 py-0.5 rounded bg-indigo-500/10 text-atlas-muted capitalize text-[10px]">
                ↻ {task.recurrence}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center space-x-1.5 self-end sm:self-center shrink-0">
        {!isCompleted && (
          <div className="flex items-center space-x-1 bg-atlas-bg p-1 rounded-lg border border-atlas-border">
            <button
              onClick={() => handlePostpone(1)}
              className="px-2 py-1 rounded text-[10px] font-mono font-medium text-atlas-muted hover:text-atlas-text hover:bg-atlas-surface transition-colors"
              title="Postpone 1 day"
            >
              +1d
            </button>
            <button
              onClick={() => handlePostpone(7)}
              className="px-2 py-1 rounded text-[10px] font-mono font-medium text-atlas-muted hover:text-atlas-text hover:bg-atlas-surface transition-colors"
              title="Postpone 1 week"
            >
              +1w
            </button>
          </div>
        )}

        <button
          onClick={() => onEdit(task)}
          className="p-1.5 rounded-lg bg-atlas-bg border border-atlas-border text-atlas-muted hover:text-atlas-text transition-colors"
          title="Edit task"
        >
          <Edit2 className="w-3.5 h-3.5" />
        </button>

        {isDeleting ? (
          <div className="flex items-center space-x-1">
            <button
              onClick={handleDelete}
              className="px-2 py-1 rounded bg-rose-500 text-white font-bold text-[10px]"
            >
              Confirm
            </button>
            <button
              onClick={() => setIsDeleting(false)}
              className="px-2 py-1 text-atlas-muted text-[10px]"
            >
              Cancel
            </button>
          </div>
        ) : (
          <button
            onClick={() => setIsDeleting(true)}
            className="p-1.5 rounded-lg bg-atlas-bg border border-atlas-border text-atlas-muted hover:text-atlas-text transition-colors"
            title="Delete task"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
