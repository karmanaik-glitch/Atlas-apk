import React, { useState } from 'react';
import { X, PieChart, AlertCircle } from 'lucide-react';
import { db } from '../../db/schema';
import { useCategories } from '../../hooks/useAtlasData';

interface BudgetModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BudgetModal: React.FC<BudgetModalProps> = ({ isOpen, onClose }) => {
  const { categories } = useCategories();
  const [category, setCategory] = useState('Food & Dining');
  const [monthlyLimit, setMonthlyLimit] = useState('');
  const [warningThreshold, setWarningThreshold] = useState('80');
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const limitNum = parseFloat(monthlyLimit);
    if (isNaN(limitNum) || limitNum <= 0) {
      setErrorMsg('Please enter a valid monthly limit.');
      return;
    }

    try {
      const existing = await db.budgets.where({ category }).first();
      if (existing) {
        await db.budgets.update(existing.id!, {
          monthlyLimit: limitNum,
          warningThreshold: parseInt(warningThreshold),
        });
      } else {
        await db.budgets.add({
          category,
          monthlyLimit: limitNum,
          warningThreshold: parseInt(warningThreshold),
        });
      }

      setMonthlyLimit('');
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to save budget.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md max-h-[90vh] overflow-y-auto rounded-2xl bg-atlas-card border border-atlas-border p-6 shadow-2xl space-y-5 animate-fadeIn">
        <div className="flex items-center justify-between border-b border-atlas-border pb-3">
          <div className="flex items-center space-x-2">
            <PieChart className="w-5 h-5 text-indigo-400" />
            <h3 className="font-bold text-atlas-text text-lg">Set Category Budget</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-atlas-muted hover:text-atlas-text">
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="space-y-1">
            <label className="text-atlas-muted font-medium">Category *</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text text-xs focus:outline-none focus:border-atlas-accent"
            >
              {categories.map((c) => (
                <option key={c.id} value={c.name}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-atlas-muted font-medium">Monthly Limit (₹) *</label>
              <input
                type="number"
                placeholder="10000"
                value={monthlyLimit}
                onChange={(e) => setMonthlyLimit(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text text-sm font-mono font-bold focus:outline-none focus:border-atlas-accent"
                autoFocus
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-atlas-muted font-medium">Alert Threshold</label>
              <select
                value={warningThreshold}
                onChange={(e) => setWarningThreshold(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text text-xs focus:outline-none focus:border-atlas-accent"
              >
                <option value="80">80% of budget</option>
                <option value="90">90% of budget</option>
                <option value="100">100% of budget</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-end space-x-3 pt-3 border-t border-atlas-border">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-muted hover:text-atlas-text transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-all active:scale-95"
            >
              Save Budget
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
