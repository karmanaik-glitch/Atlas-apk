import React from 'react';
import { PieChart as PieIcon } from 'lucide-react';

interface SpendingChartProps {
  byCategory: Record<string, number>;
  total: number;
}

const CATEGORY_COLORS: Record<string, string> = {
  'Food & Dining': '#f59e0b',
  'Transport': '#3b82f6',
  'Bills & Utilities': '#ef4444',
  'Shopping': '#ec4899',
  'Health & Fitness': '#10b981',
  'Entertainment': '#8b5cf6',
  'Tech & Software': '#06b6d4',
  'Other': '#64748b',
};

export const SpendingChart: React.FC<SpendingChartProps> = ({ byCategory, total }) => {
  const entries = Object.entries(byCategory).sort((a, b) => b[1] - a[1]);

  return (
    <div className="p-6 rounded-2xl bg-atlas-card border border-atlas-border space-y-4 shadow-sm">
      <div className="flex items-center space-x-2">
        <PieIcon className="w-5 h-5 text-atlas-text" />
        <h2 className="font-bold text-atlas-text text-base">Category Spend Breakdown</h2>
      </div>

      {entries.length === 0 ? (
        <div className="text-xs text-atlas-muted text-center py-6">
          No spending data available for chart.
        </div>
      ) : (
        <div className="space-y-3">
          {/* Multi-segment Progress Bar */}
          <div className="h-3 w-full rounded-full bg-atlas-bg flex overflow-hidden p-0.5 border border-atlas-border">
            {entries.map(([cat, amt]) => {
              const pct = total > 0 ? (amt / total) * 100 : 0;
              const color = CATEGORY_COLORS[cat] || '#6366f1';
              return (
                <div
                  key={cat}
                  className="h-full first:rounded-l-full last:rounded-r-full transition-all duration-500"
                  style={{ width: `${pct}%`, backgroundColor: color }}
                  title={`${cat}: ₹${amt.toLocaleString('en-IN')} (${Math.round(pct)}%)`}
                />
              );
            })}
          </div>

          {/* Legend Items */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
            {entries.map(([cat, amt]) => {
              const pct = total > 0 ? Math.round((amt / total) * 100) : 0;
              const color = CATEGORY_COLORS[cat] || '#6366f1';
              return (
                <div key={cat} className="flex items-center justify-between text-xs p-2 rounded-lg bg-atlas-surface border border-atlas-border/50">
                  <div className="flex items-center space-x-2 min-w-0">
                    <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: color }} />
                    <span className="text-atlas-text font-medium truncate">{cat}</span>
                  </div>
                  <span className="font-mono text-atlas-muted text-[11px] shrink-0">
                    ₹{amt.toLocaleString('en-IN')} ({pct}%)
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
