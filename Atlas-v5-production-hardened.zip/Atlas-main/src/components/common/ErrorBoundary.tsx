import React from 'react';

type Props = { children: React.ReactNode };
type State = { hasError: boolean; message?: string };

export class ErrorBoundary extends React.Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(error: unknown): State {
    return { hasError: true, message: error instanceof Error ? error.message : 'Unexpected application error.' };
  }

  componentDidCatch(error: unknown) {
    console.error('[Atlas] Unhandled render error', error);
  }

  private recover = () => {
    this.setState({ hasError: false, message: undefined });
  };

  render() {
    if (!this.state.hasError) return this.props.children;

    return (
      <main className="flex min-h-screen items-center justify-center bg-atlas-bg px-6 text-atlas-text">
        <section role="alert" className="w-full max-w-md rounded-3xl border border-atlas-border bg-atlas-card p-7 shadow-2xl">
          <p className="atlas-kicker">Atlas recovery</p>
          <h1 className="mt-2 text-2xl font-semibold tracking-tight">Something went wrong.</h1>
          <p className="mt-3 text-sm leading-6 text-atlas-muted">
            Your local data is still stored separately in Atlas. Try recovering the screen first. If the problem continues, restart the app.
          </p>
          {this.state.message && <p className="mt-4 rounded-xl bg-atlas-surface p-3 font-mono text-[11px] text-atlas-muted">{this.state.message}</p>}
          <button type="button" onClick={this.recover} className="atlas-primary mt-5 w-full justify-center">Recover Atlas</button>
        </section>
      </main>
    );
  }
}
