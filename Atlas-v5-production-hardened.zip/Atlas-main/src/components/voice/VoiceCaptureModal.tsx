import React, { useState, useEffect } from 'react';
import { X, Mic, MicOff, Check, AlertCircle } from 'lucide-react';
import { taskService } from '../../core/services/taskService';
import { noteService } from '../../core/services/noteService';
import { financeService } from '../../core/services/financeService';

interface VoiceCaptureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VoiceCaptureModal: React.FC<VoiceCaptureModalProps> = ({ isOpen, onClose }) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [captureType, setCaptureType] = useState<'task' | 'note' | 'expense'>('task');
  const [recognition, setRecognition] = useState<any | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const reco = new SpeechRecognition();
        reco.continuous = true;
        reco.interimResults = true;
        reco.lang = 'en-US';

        reco.onresult = (event: any) => {
          let currentTranscript = '';
          for (let i = event.resultIndex; i < event.results.length; i++) {
            currentTranscript += event.results[i][0].transcript;
          }
          setTranscript(currentTranscript);
        };

        reco.onerror = (e: any) => {
          console.warn('Speech recognition error:', e);
          setErrorMsg('Microphone input error or permission denied.');
          setIsListening(false);
        };

        reco.onend = () => {
          setIsListening(false);
        };

        setRecognition(reco);
      } else {
        setErrorMsg('Web Speech API is not supported in this browser.');
      }
    }
  }, []);

  if (!isOpen) return null;

  const toggleListening = () => {
    if (!recognition) {
      setErrorMsg('Web Speech API is not supported.');
      return;
    }

    if (isListening) {
      recognition.stop();
      setIsListening(false);
    } else {
      setErrorMsg(null);
      setTranscript('');
      try {
        recognition.start();
        setIsListening(true);
      } catch (err) {
        console.error('Failed to start speech recognition:', err);
      }
    }
  };

  const handleSave = async () => {
    if (!transcript.trim()) return;

    if (captureType === 'task') {
      await taskService.addTask({
        title: transcript.trim(),
        priority: 'medium',
        status: 'today',
        dueDate: new Date().toISOString().split('T')[0],
      });
    } else if (captureType === 'note') {
      await noteService.addNote({
        title: `Voice Note (${new Date().toLocaleDateString()})`,
        content: transcript.trim(),
        tags: ['voice'],
      });
    } else if (captureType === 'expense') {
      await financeService.addExpense({
        amount: 100, // default placeholder
        category: 'Other',
        date: new Date().toISOString().split('T')[0],
      });
    }

    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
      setTranscript('');
      onClose();
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md max-h-[90vh] overflow-y-auto rounded-2xl bg-atlas-card border border-atlas-border p-6 shadow-2xl space-y-5 animate-fadeIn">
        <div className="flex items-center justify-between border-b border-atlas-border pb-3">
          <div className="flex items-center space-x-2">
            <Mic className="w-5 h-5 text-indigo-400" />
            <h3 className="font-bold text-atlas-text text-lg">Voice Quick Dictation</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-atlas-muted hover:text-atlas-text">
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMsg ? (
          <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        ) : (
          <div className="space-y-4 text-xs">
            <div className="flex justify-center space-x-2">
              {(['task', 'note', 'expense'] as const).map((type) => (
                <button
                  key={type}
                  onClick={() => setCaptureType(type)}
                  className={`px-3 py-1.5 rounded-xl font-bold capitalize transition-all ${
                    captureType === type
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'bg-atlas-surface border border-atlas-border text-atlas-muted'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>

            {/* Mic Button */}
            <div className="flex flex-col items-center justify-center py-4 space-y-3">
              <button
                onClick={toggleListening}
                className={`w-16 h-16 rounded-full flex items-center justify-center transition-all ${
                  isListening
                    ? 'bg-rose-500 text-white animate-pulse shadow-glow'
                    : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-glow'
                }`}
              >
                {isListening ? <MicOff className="w-7 h-7" /> : <Mic className="w-7 h-7" />}
              </button>

              <span className="text-[11px] font-mono text-atlas-muted">
                {isListening ? 'Listening... Speak clearly into your mic' : 'Click microphone to start speech capture'}
              </span>
            </div>

            {/* Transcript Box */}
            <div className="p-3.5 rounded-xl bg-atlas-surface border border-atlas-border min-h-[80px] text-atlas-text font-mono text-xs">
              {transcript || <span className="text-atlas-muted italic">Transcript will appear here as you speak...</span>}
            </div>

            <div className="flex items-center justify-end space-x-3 pt-3 border-t border-atlas-border">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-muted hover:text-atlas-text"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSave}
                disabled={!transcript.trim()}
                className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold disabled:opacity-50 flex items-center space-x-1"
              >
                {isSaved ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Saved!</span>
                  </>
                ) : (
                  <span>Save Record</span>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
