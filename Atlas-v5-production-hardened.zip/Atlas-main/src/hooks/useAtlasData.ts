import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../db/schema';
import { Task, Habit, Expense, Category, ActivityRecord } from '../types/models';

export function useTasks() {
  const tasks = useLiveQuery(() => db.tasks.orderBy('createdAt').reverse().toArray(), []);
  return {
    tasks: tasks || [],
    isLoading: tasks === undefined,
  };
}

export function useTodayTasks() {
  const todayStr = new Date().toISOString().split('T')[0];
  const todayTasks = useLiveQuery(
    () =>
      db.tasks
        .filter((t) => t.status === 'today' || (t.dueDate === todayStr && t.status !== 'completed'))
        .toArray(),
    [todayStr]
  );
  return {
    tasks: todayTasks || [],
    isLoading: todayTasks === undefined,
  };
}

export function useHabits() {
  const habits = useLiveQuery(() => db.habits.toArray(), []);
  return {
    habits: habits || [],
    isLoading: habits === undefined,
  };
}

export function useExpenses() {
  const expenses = useLiveQuery(() => db.expenses.orderBy('date').reverse().toArray(), []);
  return {
    expenses: expenses || [],
    isLoading: expenses === undefined,
  };
}

export function useMonthlySpend() {
  const currentYM = new Date().toISOString().substring(0, 7);
  const expenses = useLiveQuery(() => db.expenses.toArray(), []);

  if (!expenses) return { total: 0, byCategory: {}, isLoading: true };

  const monthlyExpenses = expenses.filter((e) => e.date.startsWith(currentYM));
  let total = 0;
  const byCategory: Record<string, number> = {};

  monthlyExpenses.forEach((e) => {
    total += e.amount;
    byCategory[e.category] = (byCategory[e.category] || 0) + e.amount;
  });

  return { total, byCategory, isLoading: false };
}

export function useCategories() {
  const categories = useLiveQuery(() => db.categories.toArray(), []);
  return {
    categories: categories || [],
    isLoading: categories === undefined,
  };
}

export function useRecentActivity(limit = 10) {
  const activity = useLiveQuery(
    () => db.activity.orderBy('timestamp').reverse().limit(limit).toArray(),
    [limit]
  );
  return {
    activity: activity || [],
    isLoading: activity === undefined,
  };
}

export function useBudgets() {
  const budgets = useLiveQuery(() => db.budgets.toArray(), []);
  return {
    budgets: budgets || [],
    isLoading: budgets === undefined,
  };
}

export function useSubscriptions() {
  const subscriptions = useLiveQuery(() => db.subscriptions.toArray(), []);
  return {
    subscriptions: subscriptions || [],
    isLoading: subscriptions === undefined,
  };
}

export function useNotes() {
  const notes = useLiveQuery(() => db.notes.orderBy('updatedAt').reverse().toArray(), []);
  return {
    notes: notes || [],
    isLoading: notes === undefined,
  };
}

export function useReminders() {
  const reminders = useLiveQuery(() => db.reminders.orderBy('datetime').toArray(), []);
  return {
    reminders: reminders || [],
    isLoading: reminders === undefined,
  };
}

export function useGoals() {
  const goals = useLiveQuery(() => db.goals.orderBy('createdAt').reverse().toArray(), []);
  return {
    goals: goals || [],
    isLoading: goals === undefined,
  };
}

export function useWaitingItems() {
  const waitingItems = useLiveQuery(() => db.waitingItems.orderBy('dateRequested').reverse().toArray(), []);
  return {
    waitingItems: waitingItems || [],
    isLoading: waitingItems === undefined,
  };
}

export function useShoppingItems() {
  const shoppingItems = useLiveQuery(() => db.shoppingItems.toArray(), []);
  return {
    shoppingItems: shoppingItems || [],
    isLoading: shoppingItems === undefined,
  };
}

export function useAssetItems() {
  const assetItems = useLiveQuery(() => db.assetItems.toArray(), []);
  return {
    assetItems: assetItems || [],
    isLoading: assetItems === undefined,
  };
}

export function useAutomations() {
  const automations = useLiveQuery(() => db.automations.toArray(), []);
  return {
    automations: automations || [],
    isLoading: automations === undefined,
  };
}




