import { useEffect } from 'react';
import { App } from '@capacitor/app';
import { isNative } from '../core/services/nativeService';

export function useNativeLifecycle(onResume?: () => void, onBack?: () => void) {
  useEffect(() => {
    if (!isNative()) return;
    const resume = App.addListener('appStateChange', ({ isActive }) => {
      if (isActive) onResume?.();
    });
    const back = App.addListener('backButton', ({ canGoBack }) => {
      if (onBack) onBack();
      else if (canGoBack) window.history.back();
      else App.exitApp();
    });
    return () => { resume.remove(); back.remove(); };
  }, [onResume, onBack]);
}
