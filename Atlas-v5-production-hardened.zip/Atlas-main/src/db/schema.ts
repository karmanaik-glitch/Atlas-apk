import Dexie, { Table } from 'dexie';
import { 
  Task, 
  Habit, 
  HabitRecord, 
  Expense, 
  Category, 
  Note, 
  Reminder, 
  ActivityRecord, 
  SettingItem,
  Budget,
  Subscription,
  Goal,
  WaitingItem,
  ShoppingItem,
  AssetItem,
  AutomationRule
} from '../types/models';

export class AtlasDatabase extends Dexie {
  tasks!: Table<Task, number>;
  habits!: Table<Habit, number>;
  habitRecords!: Table<HabitRecord, number>;
  expenses!: Table<Expense, number>;
  categories!: Table<Category, number>;
  notes!: Table<Note, number>;
  reminders!: Table<Reminder, number>;
  activity!: Table<ActivityRecord, number>;
  settings!: Table<SettingItem, string>;
  budgets!: Table<Budget, number>;
  subscriptions!: Table<Subscription, number>;
  goals!: Table<Goal, number>;
  waitingItems!: Table<WaitingItem, number>;
  shoppingItems!: Table<ShoppingItem, number>;
  assetItems!: Table<AssetItem, number>;
  automations!: Table<AutomationRule, number>;

  constructor() {
    super('AtlasDatabase');

    // Schema Version 1
    this.version(1).stores({
      tasks: '++id, status, priority, category, dueDate, createdAt',
      habits: '++id, name, frequency, streak, createdAt',
      habitRecords: '++id, habitId, date, [habitId+date]',
      expenses: '++id, amount, category, date, createdAt',
      categories: '++id, name, type',
      notes: '++id, title, createdAt, updatedAt',
      reminders: '++id, datetime, entityType, isTriggered',
      activity: '++id, type, timestamp',
      settings: 'key',
    });

    // Schema Version 2 (Phase 5)
    this.version(2).stores({
      tasks: '++id, status, priority, category, dueDate, createdAt',
      habits: '++id, name, frequency, streak, createdAt',
      habitRecords: '++id, habitId, date, [habitId+date]',
      expenses: '++id, amount, category, date, createdAt',
      categories: '++id, name, type',
      notes: '++id, title, createdAt, updatedAt',
      reminders: '++id, datetime, entityType, isTriggered',
      activity: '++id, type, timestamp',
      settings: 'key',
      budgets: '++id, category',
      subscriptions: '++id, name, category, isActive',
    });

    // Schema Version 3 (Phase 10: Life Modules)
    this.version(3).stores({
      tasks: '++id, status, priority, category, dueDate, createdAt',
      habits: '++id, name, frequency, streak, createdAt',
      habitRecords: '++id, habitId, date, [habitId+date]',
      expenses: '++id, amount, category, date, createdAt',
      categories: '++id, name, type',
      notes: '++id, title, createdAt, updatedAt',
      reminders: '++id, datetime, entityType, isTriggered',
      activity: '++id, type, timestamp',
      settings: 'key',
      budgets: '++id, category',
      subscriptions: '++id, name, category, isActive',
      goals: '++id, title, category, status, createdAt',
      waitingItems: '++id, title, personOrSource, status, dateRequested',
      shoppingItems: '++id, name, category, isPurchased',
      assetItems: '++id, name, category',
    });

    // Schema Version 4 (Phase 11: Automations)
    this.version(4).stores({
      tasks: '++id, status, priority, category, dueDate, createdAt',
      habits: '++id, name, frequency, streak, createdAt',
      habitRecords: '++id, habitId, date, [habitId+date]',
      expenses: '++id, amount, category, date, createdAt',
      categories: '++id, name, type',
      notes: '++id, title, createdAt, updatedAt',
      reminders: '++id, datetime, entityType, isTriggered',
      activity: '++id, type, timestamp',
      settings: 'key',
      budgets: '++id, category',
      subscriptions: '++id, name, category, isActive',
      goals: '++id, title, category, status, createdAt',
      waitingItems: '++id, title, personOrSource, status, dateRequested',
      shoppingItems: '++id, name, category, isPurchased',
      assetItems: '++id, name, category',
      automations: '++id, name, triggerType, isActive',
    });

    // Schema Version 5: production hardening. Keep indexes stable while making the migration boundary explicit.
    this.version(5).stores({
      tasks: '++id, status, priority, category, dueDate, createdAt',
      habits: '++id, name, frequency, streak, createdAt',
      habitRecords: '++id, habitId, date, [habitId+date]',
      expenses: '++id, amount, category, date, createdAt',
      categories: '++id, name, type',
      notes: '++id, title, createdAt, updatedAt',
      reminders: '++id, datetime, entityType, isTriggered',
      activity: '++id, type, timestamp',
      settings: 'key',
      budgets: '++id, category',
      subscriptions: '++id, name, category, isActive',
      goals: '++id, title, category, status, createdAt',
      waitingItems: '++id, title, personOrSource, status, dateRequested',
      shoppingItems: '++id, name, category, isPurchased',
      assetItems: '++id, name, category',
      automations: '++id, name, triggerType, isActive',
    });
  }
}

// Singleton DB Instance
export const db = new AtlasDatabase();
