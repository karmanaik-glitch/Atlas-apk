import { db } from './schema';
import { Category } from '../types/models';

export const defaultCategories: Category[] = [
  { name: 'Food & Dining', color: '#f59e0b', icon: 'Utensils', type: 'expense' },
  { name: 'Transport', color: '#3b82f6', icon: 'Car', type: 'expense' },
  { name: 'Bills & Utilities', color: '#ef4444', icon: 'Receipt', type: 'expense' },
  { name: 'Shopping', color: '#ec4899', icon: 'ShoppingBag', type: 'expense' },
  { name: 'Health & Fitness', color: '#10b981', icon: 'Heart', type: 'expense' },
  { name: 'Entertainment', color: '#8b5cf6', icon: 'Film', type: 'expense' },
  { name: 'Tech & Software', color: '#06b6d4', icon: 'Laptop', type: 'expense' },
  { name: 'Other', color: '#64748b', icon: 'MoreHorizontal', type: 'expense' },
];

export async function initializeDatabaseSeed() {
  try {
    const categoryCount = await db.categories.count();
    if (categoryCount === 0) {
      await db.categories.bulkAdd(defaultCategories);
      console.log('Atlas DB: Default categories seeded successfully.');
    }

    const taskCount = await db.tasks.count();
    if (taskCount === 0) {
      const todayStr = new Date().toISOString().split('T')[0];
      await db.tasks.bulkAdd([
        {
          title: 'Explore Atlas Glance Dashboard',
          description: 'Review your local daily overview and setup habit streaks.',
          priority: 'high',
          status: 'today',
          category: 'Personal',
          dueDate: todayStr,
          createdAt: new Date().toISOString(),
        },
        {
          title: 'Review monthly budget',
          description: 'Log recent expenses and set warning thresholds.',
          priority: 'medium',
          status: 'inbox',
          createdAt: new Date().toISOString(),
        },
      ]);

      await db.habits.bulkAdd([
        {
          name: 'Morning Hydration (500ml)',
          frequency: 'daily',
          streak: 3,
          bestStreak: 7,
          createdAt: new Date().toISOString(),
        },
        {
          name: 'Read 15 mins',
          frequency: 'daily',
          streak: 5,
          bestStreak: 12,
          createdAt: new Date().toISOString(),
        },
      ]);

      await db.activity.add({
        type: 'task_created',
        description: 'Atlas Database initialized locally with seed data.',
        timestamp: new Date().toISOString(),
      });
    }
  } catch (error) {
    console.error('Atlas DB Seed Error:', error);
  }
}
