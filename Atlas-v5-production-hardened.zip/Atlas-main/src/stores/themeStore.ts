import { create } from 'zustand';

export type ThemeMode = 'dark' | 'light' | 'system';

interface ThemeState {
  theme: ThemeMode;
  setTheme: (theme: ThemeMode) => void;
  resolvedTheme: 'dark' | 'light';
}

const getStoredTheme = (): ThemeMode => {
  if (typeof window === 'undefined') return 'dark';
  return (localStorage.getItem('atlas_theme') as ThemeMode) || 'dark';
};

const getSystemTheme = (): 'dark' | 'light' => {
  if (typeof window === 'undefined') return 'dark';
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
};

const applyThemeToDOM = (theme: ThemeMode) => {
  const resolved = theme === 'system' ? getSystemTheme() : theme;
  const root = document.documentElement;
  
  if (resolved === 'dark') {
    root.classList.add('dark');
    root.classList.remove('light');
  } else {
    root.classList.add('light');
    root.classList.remove('dark');
  }
};

export const useThemeStore = create<ThemeState>((set, get) => {
  const initialTheme = getStoredTheme();
  const resolvedTheme = initialTheme === 'system' ? getSystemTheme() : initialTheme;
  
  // Apply initially
  if (typeof window !== 'undefined') {
    applyThemeToDOM(initialTheme);

    // Listen for OS system theme changes
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
      if (get().theme === 'system') {
        const sysTheme = getSystemTheme();
        applyThemeToDOM('system');
        set({ resolvedTheme: sysTheme });
      }
    });
  }

  return {
    theme: initialTheme,
    resolvedTheme,
    setTheme: (theme: ThemeMode) => {
      localStorage.setItem('atlas_theme', theme);
      applyThemeToDOM(theme);
      const newResolved = theme === 'system' ? getSystemTheme() : theme;
      set({ theme, resolvedTheme: newResolved });
    },
  };
});
