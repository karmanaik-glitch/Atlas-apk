import { create } from 'zustand';
import { NavTab } from '../types/navigation';

interface NavigationState {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  isQuickCaptureOpen: boolean;
  setQuickCaptureOpen: (open: boolean) => void;
}

export const useNavigationStore = create<NavigationState>((set) => ({
  activeTab: 'glance',
  setActiveTab: (tab: NavTab) => set({ activeTab: tab }),
  isQuickCaptureOpen: false,
  setQuickCaptureOpen: (open: boolean) => set({ isQuickCaptureOpen: open }),
}));
