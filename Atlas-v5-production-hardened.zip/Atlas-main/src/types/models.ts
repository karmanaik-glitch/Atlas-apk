import { z } from 'zod';

// ==================== TASK MODEL ====================
export type TaskPriority = 'low' | 'medium' | 'high';
export type TaskStatus = 'inbox' | 'today' | 'upcoming' | 'completed' | 'archived';

export interface Task {
  id?: number;
  title: string;
  description?: string;
  priority: TaskPriority;
  status: TaskStatus;
  category?: string;
  dueDate?: string; // YYYY-MM-DD
  dueTime?: string; // HH:MM
  recurrence?: 'none' | 'daily' | 'weekly' | 'monthly';
  createdAt: string;
  completedAt?: string;
}

export const TaskSchema = z.object({
  id: z.number().optional(),
  title: z.string().min(1, 'Task title is required'),
  description: z.string().optional(),
  priority: z.enum(['low', 'medium', 'high']).default('medium'),
  status: z.enum(['inbox', 'today', 'upcoming', 'completed', 'archived']).default('inbox'),
  category: z.string().optional(),
  dueDate: z.string().optional(),
  dueTime: z.string().optional(),
  recurrence: z.enum(['none', 'daily', 'weekly', 'monthly']).optional(),
  createdAt: z.string(),
  completedAt: z.string().optional(),
});

// ==================== HABIT MODEL ====================
export type HabitFrequency = 'daily' | 'weekly';

export interface Habit {
  id?: number;
  name: string;
  category?: string;
  frequency: HabitFrequency;
  targetDaysPerWeek?: number;
  streak: number;
  bestStreak: number;
  lastCompletedDate?: string; // YYYY-MM-DD
  createdAt: string;
}

export interface HabitRecord {
  id?: number;
  habitId: number;
  date: string; // YYYY-MM-DD
  status: 'completed' | 'skipped';
}

export const HabitSchema = z.object({
  id: z.number().optional(),
  name: z.string().min(1, 'Habit name is required'),
  category: z.string().optional(),
  frequency: z.enum(['daily', 'weekly']).default('daily'),
  targetDaysPerWeek: z.number().min(1).max(7).optional(),
  streak: z.number().default(0),
  bestStreak: z.number().default(0),
  lastCompletedDate: z.string().optional(),
  createdAt: z.string(),
});

// ==================== EXPENSE MODEL ====================
export interface Expense {
  id?: number;
  amount: number;
  category: string;
  merchant?: string;
  note?: string;
  paymentMethod?: 'cash' | 'card' | 'upi' | 'other';
  date: string; // YYYY-MM-DD
  createdAt: string;
}

export const ExpenseSchema = z.object({
  id: z.number().optional(),
  amount: z.number().positive('Amount must be positive'),
  category: z.string().min(1, 'Category is required'),
  merchant: z.string().optional(),
  note: z.string().optional(),
  paymentMethod: z.enum(['cash', 'card', 'upi', 'other']).optional(),
  date: z.string().min(1, 'Date is required'),
  createdAt: z.string(),
});

// ==================== CATEGORY MODEL ====================
export interface Category {
  id?: number;
  name: string;
  icon?: string;
  color?: string;
  type: 'expense' | 'task' | 'habit';
}

// ==================== NOTE MODEL ====================
export interface Note {
  id?: number;
  title: string;
  content: string;
  tags?: string[];
  archived: boolean;
  createdAt: string;
  updatedAt: string;
}

// ==================== REMINDER MODEL ====================
export interface Reminder {
  id?: number;
  title: string;
  datetime: string;
  entityType?: 'task' | 'habit' | 'expense' | 'custom';
  entityId?: number;
  isTriggered: boolean;
}

// ==================== ACTIVITY MODEL ====================
export type ActivityType = 
  | 'task_created' 
  | 'task_completed' 
  | 'habit_completed' 
  | 'expense_added' 
  | 'reminder_triggered'
  | 'backup_created';

export interface ActivityRecord {
  id?: number;
  type: ActivityType;
  description: string;
  timestamp: string;
  entityId?: number;
}

// ==================== SETTINGS MODEL ====================
export interface SettingItem {
  key: string;
  value: any;
}

// ==================== BUDGET MODEL ====================
export interface Budget {
  id?: number;
  category: string;
  monthlyLimit: number;
  warningThreshold?: number; // 80, 90, 100
}

// ==================== SUBSCRIPTION MODEL ====================
export interface Subscription {
  id?: number;
  name: string;
  amount: number;
  frequency: 'monthly' | 'yearly';
  nextPaymentDate: string; // YYYY-MM-DD
  category: string;
  isActive: boolean;
}

// ==================== LIFE MODULES MODELS ====================
export interface Goal {
  id?: number;
  title: string;
  category: string; // Personal, Work, Health, Finance, Learning
  targetDate?: string;
  progress: number; // 0 - 100
  milestones?: string[];
  status: 'active' | 'completed' | 'paused';
  createdAt: string;
}

export interface WaitingItem {
  id?: number;
  title: string;
  personOrSource: string; // John, Amazon, Bank, etc.
  dateRequested: string;
  expectedDate?: string;
  status: 'pending' | 'resolved';
  notes?: string;
}

export interface ShoppingItem {
  id?: number;
  name: string;
  category: string;
  quantity?: number;
  estimatedPrice?: number;
  isPurchased: boolean;
}

export interface AssetItem {
  id?: number;
  name: string;
  category: string;
  purchaseDate?: string;
  purchasePrice?: number;
  warrantyExpiry?: string;
  serialNumber?: string;
  notes?: string;
}

// ==================== AUTOMATIONS MODEL ====================
export type TriggerType = 'schedule' | 'budget_threshold' | 'task_completed';
export type ActionType = 'send_notification' | 'create_task' | 'log_activity';

export interface AutomationRule {
  id?: number;
  name: string;
  description?: string;
  triggerType: TriggerType;
  triggerConfig: {
    scheduleTime?: string; // e.g. "19:00"
    scheduleDays?: string[]; // e.g. ["Friday"] or ["daily"]
    category?: string;
    thresholdPercent?: number; // e.g. 80
  };
  actionType: ActionType;
  actionConfig: {
    title?: string;
    body?: string;
  };
  isActive: boolean;
  lastRunAt?: string;
}



