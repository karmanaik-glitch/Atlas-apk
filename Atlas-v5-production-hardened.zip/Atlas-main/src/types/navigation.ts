export type NavTab = 
  | 'glance' 
  | 'capture' 
  | 'tasks' 
  | 'habits' 
  | 'money' 
  | 'life' 
  | 'search' 
  | 'activity' 
  | 'automations' 
  | 'settings';

export interface NavItem {
  id: NavTab;
  label: string;
  iconName: string;
  isSecondary?: boolean;
}
