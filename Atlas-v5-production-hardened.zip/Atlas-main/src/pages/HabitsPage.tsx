import React, { useState } from 'react';
import { Flame, Plus, Target, Trophy } from 'lucide-react';
import { useHabits } from '../hooks/useAtlasData';
import { HabitCard } from '../components/habits/HabitCard';
import { HabitModal } from '../components/habits/HabitModal';

export const HabitsPage: React.FC = () => {
 const {habits}=useHabits(); const [open,setOpen]=useState(false); const today=new Date().toISOString().slice(0,10);
 const done=habits.filter(h=>h.lastCompletedDate===today).length; const best=habits.reduce((m,h)=>Math.max(m,h.bestStreak),0); const rate=habits.length?Math.round(done/habits.length*100):0;
 return <div className="atlas-page atlas-stagger">
  <header className="mb-7 flex items-end justify-between gap-4"><div><div className="atlas-kicker">Consistency</div><h1 className="atlas-title mt-1">Habits</h1><p className="mt-2 text-sm text-atlas-muted">Build systems that make good days easier to repeat.</p></div><button onClick={()=>setOpen(true)} className="atlas-primary"><Plus size={17}/> New habit</button></header>
  <section className="mb-6 grid gap-3 md:grid-cols-[1.4fr_1fr_1fr]">
   <div className="atlas-feature"><div className="atlas-kicker">Today’s rhythm</div><div className="mt-2 flex items-end gap-2"><span className="text-4xl font-semibold tracking-[-.05em]">{rate}%</span><span className="mb-1 text-xs text-atlas-muted">complete</span></div><div className="mt-5 h-1.5 rounded-full bg-atlas-border"><div className="h-full rounded-full bg-atlas-accent" style={{width:`${rate}%`}}/></div></div>
   <Stat icon={<Flame size={17}/>} label="Completed" value={`${done}/${habits.length}`}/><Stat icon={<Trophy size={17}/>} label="Best streak" value={`${best} days`}/>
  </section>
  <div className="mb-4 flex items-center justify-between"><div><div className="text-sm font-semibold">Your rituals</div><div className="text-xs text-atlas-muted">Tap a habit to record today.</div></div><Target size={17} className="text-atlas-muted"/></div>
  <div className="grid gap-3 md:grid-cols-2">{habits.length?habits.map(h=><HabitCard key={h.id} habit={h}/>):<div className="atlas-panel col-span-full p-10 text-center"><div className="text-sm font-semibold">Nothing on the board yet.</div><p className="mt-1 text-xs text-atlas-muted">Start with one habit small enough to keep on your worst day.</p><button onClick={()=>setOpen(true)} className="atlas-secondary mt-4"><Plus size={15}/> Create habit</button></div>}</div>
  <HabitModal isOpen={open} onClose={()=>setOpen(false)}/>
 </div>
}
function Stat({icon,label,value}:{icon:React.ReactNode;label:string;value:string}){return <div className="atlas-panel p-5"><div className="atlas-icon">{icon}</div><div className="atlas-kicker mt-5">{label}</div><div className="mt-1 text-2xl font-semibold tracking-tight">{value}</div></div>}
