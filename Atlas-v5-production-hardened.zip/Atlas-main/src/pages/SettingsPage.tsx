import React, { useState } from 'react';
import { Settings, Download, Upload, Trash2, ShieldCheck, Database, CheckCircle2, AlertCircle, RefreshCw, Bell, Sun, Moon, Monitor, Palette } from 'lucide-react';
import { settingsService } from '../core/services/settingsService';
import { notificationService } from '../core/services/notificationService';
import { useTasks, useHabits, useExpenses, useNotes, useReminders, useBudgets, useSubscriptions } from '../hooks/useAtlasData';
import { initializeDatabaseSeed } from '../db/seedData';
import { useThemeStore, ThemeMode } from '../stores/themeStore';
import { shareAtlas } from '../core/services/nativeService';
import { requestNativeNotifications } from '../core/services/nativeNotifications';

export const SettingsPage: React.FC = () => {
  const { theme, setTheme, resolvedTheme } = useThemeStore();
  const { tasks } = useTasks();
  const { habits } = useHabits();
  const { expenses } = useExpenses();
  const { notes } = useNotes();
  const { reminders } = useReminders();
  const { budgets } = useBudgets();
  const { subscriptions } = useSubscriptions();

  const [message, setMessage] = useState<{ text: string; isError?: boolean } | null>(null);
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);

  const totalRecordCount = tasks.length + habits.length + expenses.length + notes.length + reminders.length + budgets.length + subscriptions.length;

  const showMessage = (text: string, isError = false) => {
    setMessage({ text, isError });
    setTimeout(() => setMessage(null), 4000);
  };

  const handleExportJSON = async () => {
    try {
      const jsonStr = await settingsService.exportFullBackup();
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const dateStr = new Date().toISOString().split('T')[0];

      const a = document.createElement('a');
      a.href = url;
      a.download = `atlas-backup-${dateStr}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      showMessage('JSON backup file downloaded successfully!');
      await shareAtlas(`Atlas backup created: atlas-backup-${dateStr}.json`, 'Atlas backup');
    } catch (err: any) {
      showMessage(`Export failed: ${err.message}`, true);
    }
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const content = event.target?.result as string;
      if (content) {
        const res = await settingsService.importFullBackup(content);
        if (res.success) {
          showMessage(res.message);
        } else {
          showMessage(res.message, true);
        }
      }
    };
    reader.readAsText(file);
  };

  const handleResetData = async () => {
    await settingsService.clearAllData();
    setIsResetConfirmOpen(false);
    showMessage('All Atlas local data has been erased.');
  };

  const handleReSeedData = async () => {
    await initializeDatabaseSeed();
    showMessage('Database re-seeded with default sample categories and data.');
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-atlas-text flex items-center space-x-2">
          <Settings className="w-6 h-6 text-indigo-400" />
          <span>System Settings & Data Portability</span>
        </h1>
        <p className="text-sm text-atlas-muted">Karma's local-first privacy, appearance themes, JSON backup & restore, and system diagnostics.</p>
      </div>

      {message && (
        <div
          className={`p-4 rounded-xl border text-xs font-semibold flex items-center space-x-2 animate-fadeIn ${
            message.isError
              ? 'bg-rose-500/15 border-rose-500/30 text-rose-400'
              : 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400'
          }`}
        >
          {message.isError ? <AlertCircle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
          <span>{message.text}</span>
        </div>
      )}

      {/* Theme & Appearance Control */}
      <div className="p-6 rounded-2xl bg-atlas-card border border-atlas-border space-y-4 shadow-sm">
        <div className="flex items-center space-x-2">
          <Palette className="w-5 h-5 text-indigo-400" />
          <h2 className="font-bold text-atlas-text text-base">Appearance & Theme System</h2>
        </div>

        <p className="text-xs text-atlas-muted">
          Choose your preferred theme mode. System mode automatically mirrors your operating system settings.
        </p>

        <div className="grid grid-cols-3 gap-3 pt-1">
          {[
            { id: 'dark' as ThemeMode, label: 'Dark Mode', icon: Moon, desc: 'High contrast dark palette' },
            { id: 'light' as ThemeMode, label: 'Light Mode', icon: Sun, desc: 'Clean slate light palette' },
            { id: 'system' as ThemeMode, label: 'System OS', icon: Monitor, desc: `Matches device (${resolvedTheme})` },
          ].map((option) => {
            const Icon = option.icon;
            const isSelected = theme === option.id;
            return (
              <button
                key={option.id}
                onClick={() => setTheme(option.id)}
                className={`p-4 rounded-xl border flex flex-col items-start space-y-2 text-left transition-all ${
                  isSelected
                    ? 'bg-atlas-accent/15 border-atlas-accent text-emerald-400 font-semibold shadow-sm'
                    : 'bg-atlas-surface border-atlas-border text-atlas-muted hover:text-atlas-text hover:bg-atlas-surface-hover'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <Icon className={`w-5 h-5 ${isSelected ? 'text-emerald-400' : 'text-atlas-muted'}`} />
                  {isSelected && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>}
                </div>
                <div>
                  <div className="text-xs font-bold text-atlas-text">{option.label}</div>
                  <div className="text-[10px] text-atlas-muted mt-0.5">{option.desc}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Storage Diagnostics */}
      <div className="p-6 rounded-2xl bg-atlas-card border border-atlas-border space-y-4 shadow-sm">
        <div className="flex items-center space-x-2">
          <Database className="w-5 h-5 text-indigo-400" />
          <h2 className="font-bold text-atlas-text text-base">IndexedDB Storage Diagnostics</h2>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-atlas-surface border border-atlas-border">
            <div className="text-atlas-muted">Total Records</div>
            <div className="text-lg font-bold font-mono text-atlas-text mt-0.5">{totalRecordCount}</div>
          </div>

          <div className="p-3 rounded-xl bg-atlas-surface border border-atlas-border">
            <div className="text-atlas-muted">Schema Version</div>
            <div className="text-lg font-bold font-mono text-emerald-400 mt-0.5">v5.0</div>
          </div>

          <div className="p-3 rounded-xl bg-atlas-surface border border-atlas-border">
            <div className="text-atlas-muted">Tasks / Habits</div>
            <div className="text-lg font-bold font-mono text-atlas-text mt-0.5">{tasks.length} / {habits.length}</div>
          </div>

          <div className="p-3 rounded-xl bg-atlas-surface border border-atlas-border">
            <div className="text-atlas-muted">Expenses / Notes</div>
            <div className="text-lg font-bold font-mono text-atlas-text mt-0.5">{expenses.length} / {notes.length}</div>
          </div>
        </div>
      </div>

      {/* Backup & Portability */}
      <div className="p-6 rounded-2xl bg-atlas-card border border-atlas-border space-y-4 shadow-sm">
        <div className="flex items-center space-x-2">
          <Download className="w-5 h-5 text-emerald-400" />
          <h2 className="font-bold text-atlas-text text-base">Full Data Backup & Restore</h2>
        </div>

        <p className="text-xs text-atlas-muted">
          Your Atlas data belongs exclusively to you. Export your entire IndexedDB database to a standard JSON backup file at any time.
        </p>

        <div className="flex flex-col sm:flex-row gap-3 pt-2">
          <button
            onClick={handleExportJSON}
            className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-xs shadow-glow transition-all active:scale-95 flex items-center justify-center space-x-2"
          >
            <Download className="w-4 h-4 stroke-[2.5]" />
            <span>Export Full JSON Backup</span>
          </button>

          <label className="px-5 py-2.5 rounded-xl bg-atlas-surface border border-atlas-border hover:bg-atlas-surface-hover text-atlas-text font-bold text-xs transition-all cursor-pointer flex items-center justify-center space-x-2">
            <Upload className="w-4 h-4 text-indigo-400" />
            <span>Import JSON Backup</span>
            <input type="file" accept=".json" onChange={handleImportJSON} className="hidden" />
          </label>

          <button
            onClick={handleReSeedData}
            className="px-4 py-2.5 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-muted hover:text-atlas-text text-xs transition-all flex items-center justify-center space-x-2"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Re-seed Sample Data</span>
          </button>
        </div>
      </div>

      {/* Notification Settings */}
      <div className="p-6 rounded-2xl bg-atlas-card border border-atlas-border space-y-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Bell className="w-5 h-5 text-indigo-400" />
            <h2 className="font-bold text-atlas-text text-base">Desktop & Web Notifications</h2>
          </div>

          <span
            className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase ${
              notificationService.getPermissionStatus() === 'granted'
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                : notificationService.getPermissionStatus() === 'denied'
                ? 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                : 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
            }`}
          >
            Permission: {notificationService.getPermissionStatus()}
          </span>
        </div>

        <p className="text-xs text-atlas-muted">
          Receive native desktop browser notifications for scheduled reminders and due tasks.
        </p>

        <div className="flex flex-col sm:flex-row gap-3 pt-1">
          <button
            onClick={async () => {
              const nativeGranted = await requestNativeNotifications();
              if (nativeGranted) {
                showMessage('Native Android notifications enabled.');
                return;
              }
              const perm = await notificationService.requestPermission();
              showMessage(`Notification permission set to: ${perm}`);
            }}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-all active:scale-95 flex items-center justify-center space-x-2"
          >
            <Bell className="w-4 h-4" />
            <span>Enable Notifications</span>
          </button>

          <button
            onClick={async () => {
              const ok = await notificationService.sendTestNotification();
              if (ok) {
                showMessage('Sent test notification!');
              } else {
                showMessage('Notifications permission is not granted in browser settings.', true);
              }
            }}
            className="px-4 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-text font-bold text-xs hover:bg-atlas-surface-hover transition-all flex items-center justify-center space-x-2"
          >
            <span>Send Test Notification</span>
          </button>
        </div>
      </div>

      {/* Privacy Manifesto */}
      <div className="p-6 rounded-2xl bg-atlas-card border border-atlas-border space-y-3 shadow-sm">
        <div className="flex items-center space-x-2">
          <ShieldCheck className="w-5 h-5 text-emerald-400" />
          <h2 className="font-bold text-atlas-text text-base">Local-First Privacy Manifesto</h2>
        </div>

        <div className="space-y-2 text-xs text-atlas-muted leading-relaxed">
          <p>
            <strong className="text-atlas-text">100% Offline Capability:</strong> Project Atlas is built with Dexie IndexedDB. All tasks, habits, expenses, notes, and metrics remain strictly stored inside your web browser.
          </p>
          <p>
            <strong className="text-atlas-text">₹0 Operational Cost:</strong> Zero telemetry, zero analytics tracking, and zero remote database servers.
          </p>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="p-6 rounded-2xl bg-rose-500/5 border border-rose-500/20 space-y-4">
        <div className="flex items-center space-x-2">
          <Trash2 className="w-5 h-5 text-rose-400" />
          <h2 className="font-bold text-rose-400 text-base">Danger Zone</h2>
        </div>

        <p className="text-xs text-atlas-muted">
          Permanently clear all tasks, habits, expenses, and notes stored in browser IndexedDB. This action cannot be undone unless you have a JSON backup.
        </p>

        <button
          onClick={() => setIsResetConfirmOpen(true)}
          className="px-4 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 font-bold text-xs transition-all active:scale-95"
        >
          Erase All Local Data
        </button>
      </div>

      {/* Confirmation Modal */}
      {isResetConfirmOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm rounded-2xl bg-atlas-card border border-rose-500/30 p-6 shadow-2xl space-y-4 animate-fadeIn max-h-[90vh] overflow-y-auto">
            <h3 className="font-bold text-rose-400 text-lg">Confirm Database Erase</h3>
            <p className="text-xs text-atlas-muted">
              Are you completely sure? This will delete all {totalRecordCount} records stored in IndexedDB.
            </p>

            <div className="flex items-center justify-end space-x-3 pt-3 border-t border-atlas-border">
              <button
                onClick={() => setIsResetConfirmOpen(false)}
                className="px-4 py-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-muted hover:text-atlas-text text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleResetData}
                className="px-5 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs"
              >
                Yes, Erase Data
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
