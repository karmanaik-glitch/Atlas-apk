import React, { useState } from 'react';
import { CheckSquare2, FileText, Flame, Wallet } from 'lucide-react';
import { taskService } from '../core/services/taskService';
import { financeService } from '../core/services/financeService';
import { habitService } from '../core/services/habitService';
import { noteService } from '../core/services/noteService';
import { useCategories } from '../hooks/useAtlasData';

export const CapturePage: React.FC = () => {
 const {categories}=useCategories(); const [type,setType]=useState<'task'|'expense'|'habit'|'note'>('task'); const [value,setValue]=useState(''); const [amount,setAmount]=useState(''); const [done,setDone]=useState('');
 const submit=async(e:React.FormEvent)=>{e.preventDefault(); const now=new Date().toISOString(); if(type==='task'&&value.trim()) await taskService.addTask({title:value.trim(),priority:'medium',status:'today',dueDate:now.slice(0,10)}); if(type==='habit'&&value.trim()) await habitService.addHabit({name:value.trim(),frequency:'daily'}); if(type==='note'&&value.trim()) await noteService.addNote({title:value.trim(),content:''}); if(type==='expense'&&Number(amount)>0) await financeService.addExpense({amount:Number(amount),category:value||'Other',date:now.slice(0,10)}); setValue('');setAmount('');setDone(type==='expense'?'Expense logged':`${type[0].toUpperCase()+type.slice(1)} captured`);setTimeout(()=>setDone(''),1800)};
 const options=[['task','Task',CheckSquare2],['expense','Expense',Wallet],['habit','Habit',Flame],['note','Note',FileText]] as const;
 return <div className="atlas-page flex min-h-full items-center justify-center"><div className="w-full max-w-xl">
  <div className="mb-8 text-center"><div className="atlas-kicker">Quick capture</div><h1 className="mt-2 text-4xl font-semibold tracking-[-.05em]">Get it out of your head.</h1><p className="mx-auto mt-3 max-w-md text-sm text-atlas-muted">One action. One field. Atlas handles the rest.</p></div>
  <div className="atlas-panel overflow-hidden p-2 shadow-2xl shadow-black/5"><div className="grid grid-cols-4 gap-1">{options.map(([id,label,Icon])=><button key={id} onClick={()=>setType(id)} className={`flex flex-col items-center gap-1.5 rounded-xl px-2 py-3 text-[10px] font-semibold ${type===id?'bg-atlas-accent text-black':'text-atlas-muted hover:bg-atlas-surface-hover'}`}><Icon size={17}/>{label}</button>)}</div>
  <form onSubmit={submit} className="p-5 sm:p-7"><label className="atlas-kicker">{type==='expense'?'What did you spend on?':`New ${type}`}</label>{type==='expense'&&<div className="mt-4 text-5xl font-semibold tracking-[-.06em]">₹ <input autoFocus inputMode="decimal" value={amount} onChange={e=>setAmount(e.target.value)} className="w-[80%] bg-transparent outline-none" placeholder="0"/></div>}
  <input autoFocus={type!=='expense'} value={value} onChange={e=>setValue(e.target.value)} className={`mt-4 w-full border-0 bg-transparent text-2xl font-medium tracking-[-.03em] outline-none placeholder:text-atlas-muted/40 ${type==='expense'?'text-sm':''}`} placeholder={type==='task'?'What needs doing?':type==='habit'?'What do you want to repeat?':type==='note'?'Give this thought a title':'Category (e.g. Food & Dining)'}/>
  {type==='expense'&&categories.length>0&&<select value={value} onChange={e=>setValue(e.target.value)} className="atlas-control mt-4 w-full px-3 py-2 text-xs"><option value="">Choose category</option>{categories.map(c=><option key={c.id} value={c.name}>{c.name}</option>)}</select>}
  <div className="mt-7 flex items-center justify-between"><span className="text-xs text-atlas-muted">Press Enter to capture</span><button className="atlas-primary" type="submit">Capture</button></div>{done&&<div className="mt-4 text-xs font-semibold text-atlas-text">✓ {done}</div>}</form></div>
  <div className="mt-5 text-center text-[10px] uppercase tracking-[.16em] text-atlas-muted">Private · local-first · offline</div>
 </div></div>
}
