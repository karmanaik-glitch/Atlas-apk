import React from 'react';
import { ArrowUpRight, CheckCircle2, ChevronRight, CircleDollarSign, Flame, Plus, ShieldCheck, Sparkles } from 'lucide-react';
import { useTodayTasks, useHabits, useMonthlySpend } from '../hooks/useAtlasData';
import { useNavigationStore } from '../stores/navigationStore';
import { GreetingBriefingCard } from '../components/glance/GreetingBriefingCard';
import { TodayTasksWidget } from '../components/glance/TodayTasksWidget';
import { HabitStreakWidget } from '../components/glance/HabitStreakWidget';
import { SpendingOverviewWidget } from '../components/glance/SpendingOverviewWidget';
import { RecentActivityWidget } from '../components/glance/RecentActivityWidget';

export const GlancePage: React.FC = () => {
  const { tasks } = useTodayTasks();
  const { habits } = useHabits();
  const { total: spend } = useMonthlySpend();
  const { setActiveTab, setQuickCaptureOpen } = useNavigationStore();
  const pending = tasks.filter(t => t.status !== 'completed').length;
  const completed = tasks.length - pending;
  const completion = tasks.length ? Math.round((completed / tasks.length) * 100) : 0;

  return <div className="atlas-page atlas-enter">
    <div className="mb-6 flex items-end justify-between gap-4">
      <div><p className="atlas-kicker">{new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}</p><h1 className="atlas-title mt-1">Your day, in one place.</h1><p className="mt-2 max-w-xl text-sm text-atlas-muted">A quiet command center for what matters now — tasks, habits, money and the things you don't want to lose track of.</p></div>
      <button onClick={() => setQuickCaptureOpen(true)} className="hidden sm:flex items-center gap-2 rounded-xl bg-atlas-text px-4 py-2.5 text-xs font-bold text-atlas-bg transition-transform active:scale-95"><Plus className="h-4 w-4"/> Capture</button>
    </div>

    <div className="grid gap-4 lg:grid-cols-[1.65fr_.8fr_.8fr]">
      <section className="atlas-panel overflow-hidden bg-atlas-text text-atlas-bg p-6 sm:p-8">
        <div className="flex items-start justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[.18em] opacity-50">Today</p><p className="mt-5 text-3xl font-semibold tracking-[-.045em]">Good morning, Karma.</p><p className="mt-2 max-w-md text-sm leading-6 opacity-65">You have {pending} open {pending === 1 ? 'task' : 'tasks'} and {habits.length} active habits. Keep the day simple.</p></div><div className="rounded-full border border-white/10 px-2.5 py-1 text-[10px] font-semibold opacity-70">LOCAL</div></div>
        <div className="mt-10 grid grid-cols-3 gap-3 border-t border-white/10 pt-4"><div><p className="text-2xl font-semibold">{pending}</p><p className="mt-1 text-[10px] uppercase tracking-wider opacity-45">Open tasks</p></div><div><p className="text-2xl font-semibold">{completion}%</p><p className="mt-1 text-[10px] uppercase tracking-wider opacity-45">Task progress</p></div><div><p className="text-2xl font-semibold">₹{spend.toLocaleString('en-IN')}</p><p className="mt-1 text-[10px] uppercase tracking-wider opacity-45">This month</p></div></div>
      </section>
      <MetricCard label="Momentum" value={`${habits.length}`} detail="active habits" icon={<Flame className="h-4 w-4"/>} onClick={() => setActiveTab('habits')}/>
      <MetricCard label="Spending" value={`₹${spend.toLocaleString('en-IN')}`} detail="month to date" icon={<CircleDollarSign className="h-4 w-4"/>} onClick={() => setActiveTab('money')}/>
    </div>

    <div className="mt-4 grid gap-4 lg:grid-cols-[1.25fr_.75fr] atlas-stagger">
      <section className="atlas-panel p-5 sm:p-6"><SectionHeading eyebrow="Focus" title="What needs you now" action="View tasks" onClick={() => setActiveTab('tasks')}/><div className="mt-5"><TodayTasksWidget/></div></section>
      <section className="atlas-panel p-5 sm:p-6"><SectionHeading eyebrow="Consistency" title="Keep the streak" action="Habits" onClick={() => setActiveTab('habits')}/><div className="mt-5"><HabitStreakWidget/></div></section>
    </div>

    <div className="mt-4 grid gap-4 lg:grid-cols-2 atlas-stagger">
      <section className="atlas-panel p-5 sm:p-6"><SectionHeading eyebrow="Money" title="Spend with context" action="Open money" onClick={() => setActiveTab('money')}/><div className="mt-5"><SpendingOverviewWidget/></div></section>
      <section className="atlas-panel p-5 sm:p-6"><SectionHeading eyebrow="Timeline" title="Recently changed" action="Activity" onClick={() => setActiveTab('activity')}/><div className="mt-5"><RecentActivityWidget/></div></section>
    </div>

    <div className="mt-4 flex items-center justify-between rounded-2xl border border-atlas-border bg-atlas-surface px-4 py-3"><div className="flex items-center gap-3"><ShieldCheck className="h-4 w-4 text-atlas-accent"/><div><p className="text-xs font-semibold text-atlas-text">Private by design</p><p className="text-[10px] text-atlas-muted">Atlas stores your workspace locally on this device.</p></div></div><Sparkles className="h-4 w-4 text-atlas-muted"/></div>
  </div>;
};

function MetricCard({label,value,detail,icon,onClick}:{label:string;value:string;detail:string;icon:React.ReactNode;onClick:()=>void}) { return <button onClick={onClick} className="atlas-panel group p-5 text-left transition-transform hover:-translate-y-0.5"><div className="flex items-center justify-between"><span className="atlas-kicker">{label}</span><span className="text-atlas-muted">{icon}</span></div><p className="mt-7 text-3xl font-semibold tracking-[-.05em] text-atlas-text">{value}</p><div className="mt-1 flex items-center justify-between"><span className="text-xs text-atlas-muted">{detail}</span><ArrowUpRight className="h-4 w-4 text-atlas-muted transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5"/></div></button> }
function SectionHeading({eyebrow,title,action,onClick}:{eyebrow:string;title:string;action:string;onClick:()=>void}) { return <div className="flex items-end justify-between gap-3"><div><p className="atlas-kicker">{eyebrow}</p><h2 className="mt-1 text-lg font-semibold tracking-[-.025em] text-atlas-text">{title}</h2></div><button onClick={onClick} className="flex items-center gap-1 text-[11px] font-semibold text-atlas-muted hover:text-atlas-text">{action}<ChevronRight className="h-3.5 w-3.5"/></button></div> }
