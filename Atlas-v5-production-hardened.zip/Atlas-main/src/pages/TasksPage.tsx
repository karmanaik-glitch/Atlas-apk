import React, { useMemo, useState } from 'react';
import { Check, CheckSquare2, ChevronRight, Plus, Search, Sparkles } from 'lucide-react';
import { useTasks } from '../hooks/useAtlasData';
import { Task } from '../types/models';
import { TaskCard } from '../components/tasks/TaskCard';
import { TaskModal } from '../components/tasks/TaskModal';

type View = 'today' | 'inbox' | 'upcoming' | 'done';

export const TasksPage: React.FC = () => {
  const { tasks } = useTasks();
  const [view, setView] = useState<View>('today');
  const [query, setQuery] = useState('');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Task | null>(null);
  const today = new Date().toISOString().slice(0, 10);

  const todayTasks = tasks.filter(t => t.status !== 'completed' && (t.status === 'today' || t.dueDate === today));
  const completedToday = tasks.filter(t => t.completedAt?.slice(0,10) === today).length;
  const inbox = tasks.filter(t => t.status === 'inbox');
  const upcoming = tasks.filter(t => t.status !== 'completed' && !!t.dueDate && t.dueDate > today);
  const done = tasks.filter(t => t.status === 'completed');
  const source = view === 'today' ? todayTasks : view === 'inbox' ? inbox : view === 'upcoming' ? upcoming : done;
  const visible = useMemo(() => source.filter(t => !query.trim() || `${t.title} ${t.description || ''}`.toLowerCase().includes(query.toLowerCase())), [source, query]);
  const openCreate = () => { setEditing(null); setModal(true); };

  return <div className="atlas-page atlas-stagger">
    <header className="mb-7 flex items-end justify-between gap-4">
      <div><div className="atlas-kicker">Execution</div><h1 className="atlas-title mt-1">Tasks</h1><p className="mt-2 max-w-xl text-sm text-atlas-muted">A focused queue for what actually needs your attention.</p></div>
      <button onClick={openCreate} className="atlas-primary"><Plus size={17}/><span>New task</span></button>
    </header>

    <section className="mb-6 grid gap-3 md:grid-cols-[1.6fr_.8fr_.8fr]">
      <div className="atlas-feature"><div className="flex items-start justify-between"><div><div className="atlas-kicker">Today</div><div className="mt-2 text-3xl font-semibold tracking-tight">{todayTasks.length}</div><div className="text-xs text-atlas-muted">open items</div></div><div className="atlas-icon"><Sparkles size={17}/></div></div><div className="mt-6 h-1.5 overflow-hidden rounded-full bg-atlas-border"><div className="h-full rounded-full bg-atlas-accent" style={{width:`${todayTasks.length ? Math.min(100, (completedToday / Math.max(1, todayTasks.length + completedToday))*100) : 0}%`}}/></div></div>
      <Metric label="Inbox" value={inbox.length}/><Metric label="Upcoming" value={upcoming.length}/>
    </section>

    <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex gap-1 overflow-x-auto rounded-xl border border-atlas-border bg-atlas-surface p-1">{([['today','Today',todayTasks.length],['inbox','Inbox',inbox.length],['upcoming','Upcoming',upcoming.length],['done','Done',done.length]] as const).map(([id,label,count]) => <button key={id} onClick={()=>setView(id)} className={`atlas-tab ${view===id?'atlas-tab-active':''}`}>{label}<span>{count}</span></button>)}</div>
      <label className="relative block sm:w-64"><Search className="absolute left-3 top-2.5 text-atlas-muted" size={15}/><input className="atlas-control w-full py-2 pl-9 pr-3 text-xs" placeholder="Find a task" value={query} onChange={e=>setQuery(e.target.value)}/></label>
    </div>

    <section className="space-y-2">{visible.length ? visible.map(task=><TaskCard key={task.id} task={task} onEdit={t=>{setEditing(t);setModal(true)}}/>) : <EmptyTask onCreate={openCreate} view={view}/>}</section>
    <TaskModal isOpen={modal} onClose={()=>setModal(false)} taskToEdit={editing}/>
  </div>;
};
function Metric({label,value}:{label:string;value:number}){return <div className="atlas-panel p-5"><div className="atlas-kicker">{label}</div><div className="mt-2 text-2xl font-semibold tracking-tight">{value}</div></div>}
function EmptyTask({onCreate,view}:{onCreate:()=>void;view:View}){return <div className="atlas-panel flex min-h-48 flex-col items-center justify-center text-center"><div className="atlas-icon mb-3"><Check size={17}/></div><div className="text-sm font-semibold">{view==='today'?'Clear runway.':`No ${view} tasks.`}</div><p className="mt-1 max-w-xs text-xs text-atlas-muted">Capture the next concrete action instead of keeping it in your head.</p><button onClick={onCreate} className="mt-4 atlas-secondary"><Plus size={15}/> Add task</button></div>}
