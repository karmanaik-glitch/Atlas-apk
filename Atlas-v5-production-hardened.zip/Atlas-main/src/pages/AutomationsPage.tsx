import React, { useState, useEffect } from 'react';
import { Zap, Plus, Trash2, Power, Bell, CheckSquare } from 'lucide-react';
import { useAutomations } from '../hooks/useAtlasData';
import { automationService } from '../core/services/automationService';
import { AutomationModal } from '../components/automations/AutomationModal';

export const AutomationsPage: React.FC = () => {
  const { automations } = useAutomations();
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    automationService.seedDefaultTemplates();
  }, []);

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-atlas-text flex items-center space-x-2">
            <Zap className="w-6 h-6 text-amber-400" />
            <span>Automations Engine</span>
          </h1>
          <p className="text-sm text-atlas-muted">Visual Trigger → Condition → Action background automation rules.</p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-glow transition-all flex items-center space-x-2 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>New Automation</span>
        </button>
      </div>

      {/* Rules Feed */}
      <div className="space-y-4">
        {automations.length === 0 ? (
          <div className="p-12 rounded-2xl bg-atlas-card border border-dashed border-atlas-border text-center space-y-2">
            <Zap className="w-8 h-8 mx-auto text-atlas-muted opacity-40" />
            <div className="font-semibold text-atlas-text text-sm">No automation rules configured</div>
            <p className="text-xs text-atlas-muted max-w-sm mx-auto">
              Create rules to automatically remind you to audit spending, trigger habit notifications, or log recurring tasks.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {automations.map((rule) => (
              <div
                key={rule.id}
                className={`p-5 rounded-2xl border transition-all ${
                  rule.isActive ? 'bg-atlas-card border-atlas-border' : 'bg-atlas-bg/40 border-atlas-border/50 opacity-60'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-atlas-text text-sm">{rule.name}</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] uppercase font-mono font-bold border ${
                          rule.isActive
                            ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400'
                            : 'bg-atlas-surface border-atlas-border text-atlas-muted'
                        }`}
                      >
                        {rule.isActive ? 'Active' : 'Disabled'}
                      </span>
                    </div>

                    {rule.description && <p className="text-xs text-atlas-muted">{rule.description}</p>}

                    <div className="flex items-center space-x-4 pt-2 text-[11px] font-mono text-atlas-muted">
                      <div className="flex items-center space-x-1">
                        <span className="text-amber-400">Trigger:</span>
                        <span className="capitalize">{rule.triggerType.replace('_', ' ')}</span>
                      </div>

                      <div className="flex items-center space-x-1">
                        <span className="text-indigo-400">Action:</span>
                        <span className="capitalize">{rule.actionType.replace('_', ' ')}</span>
                      </div>

                      {rule.lastRunAt && (
                        <div>Last Run: {new Date(rule.lastRunAt).toLocaleString()}</div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 shrink-0">
                    <button
                      onClick={() => rule.id && automationService.toggleActive(rule.id, rule.isActive)}
                      className={`p-2 rounded-xl border transition-all ${
                        rule.isActive
                          ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                          : 'bg-atlas-surface border-atlas-border text-atlas-muted'
                      }`}
                      title={rule.isActive ? 'Disable rule' : 'Enable rule'}
                    >
                      <Power className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => rule.id && automationService.deleteRule(rule.id)}
                      className="p-2 rounded-xl bg-atlas-surface border border-atlas-border text-atlas-muted hover:text-rose-400 transition-all"
                      title="Delete rule"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <AutomationModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </div>
  );
};
