import React, { useState } from 'react';
import { History, CheckCircle2, Flame, Wallet, Sparkles, Trash2, Filter } from 'lucide-react';
import { useRecentActivity } from '../hooks/useAtlasData';
import { db } from '../db/schema';

export const ActivityPage: React.FC = () => {
  const { activity } = useRecentActivity(100);
  const [filterType, setFilterType] = useState<string>('all');

  const filteredActivity = activity.filter((item) => {
    if (filterType === 'tasks') return item.type.includes('task');
    if (filterType === 'habits') return item.type.includes('habit');
    if (filterType === 'expenses') return item.type.includes('expense');
    if (filterType === 'system') return item.type.includes('backup') || item.type.includes('reminder');
    return true;
  });

  const handleClearHistory = async () => {
    if (confirm('Are you sure you want to clear your activity history log?')) {
      await db.activity.clear();
    }
  };

  const getActivityIcon = (type: string) => {
    if (type.includes('task')) return <CheckCircle2 className="w-4 h-4 text-indigo-400" />;
    if (type.includes('habit')) return <Flame className="w-4 h-4 text-emerald-400" />;
    if (type.includes('expense')) return <Wallet className="w-4 h-4 text-rose-400" />;
    return <Sparkles className="w-4 h-4 text-sky-400" />;
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-atlas-text flex items-center space-x-2">
            <History className="w-6 h-6 text-sky-400" />
            <span>Activity Audit Trail</span>
          </h1>
          <p className="text-sm text-atlas-muted">Complete audit log of system actions, tasks completed, and expenses logged.</p>
        </div>

        {activity.length > 0 && (
          <button
            onClick={handleClearHistory}
            className="px-3.5 py-1.5 rounded-xl bg-atlas-card border border-atlas-border text-atlas-muted hover:text-rose-400 text-xs transition-all flex items-center space-x-1.5 self-start sm:self-auto"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear History</span>
          </button>
        )}
      </div>

      {/* Filter Type Pills */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1 text-xs">
        {[
          { id: 'all', label: 'All Activity' },
          { id: 'tasks', label: 'Tasks' },
          { id: 'habits', label: 'Habits' },
          { id: 'expenses', label: 'Expenses' },
          { id: 'system', label: 'System & Backups' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setFilterType(tab.id)}
            className={`px-3.5 py-1.5 rounded-xl font-semibold transition-all whitespace-nowrap ${
              filterType === tab.id
                ? 'bg-atlas-accent/15 text-emerald-400 border border-atlas-accent/30'
                : 'bg-atlas-card border border-atlas-border text-atlas-muted hover:text-atlas-text'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Audit Log Timeline */}
      <div className="rounded-2xl bg-atlas-card border border-atlas-border overflow-hidden shadow-sm">
        {filteredActivity.length === 0 ? (
          <div className="p-12 text-center text-xs text-atlas-muted space-y-1">
            <History className="w-8 h-8 mx-auto text-atlas-muted opacity-40" />
            <p className="font-semibold text-atlas-text">No activity recorded for this filter</p>
          </div>
        ) : (
          <div className="divide-y divide-atlas-border/50">
            {filteredActivity.map((item) => (
              <div key={item.id} className="p-4 flex items-center justify-between hover:bg-atlas-surface/40 transition-colors text-xs">
                <div className="flex items-center space-x-3">
                  <div className="p-2 rounded-xl bg-atlas-surface border border-atlas-border">
                    {getActivityIcon(item.type)}
                  </div>
                  <div>
                    <div className="font-semibold text-atlas-text">{item.description}</div>
                    <div className="text-[10px] text-atlas-muted font-mono uppercase mt-0.5">
                      {item.type.replace('_', ' ')}
                    </div>
                  </div>
                </div>

                <div className="text-[11px] text-atlas-muted font-mono shrink-0">
                  {new Date(item.timestamp).toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
