# ATLAS — MOBILE + THEME REPAIR PASS

## Objective

Atlas is now running, but two major foundational problems remain:

1. **Mobile layout is distorted / broken**
2. **Light/Dark/System theme switching is not working correctly**

This is a focused **debug + repair pass**.

Do **not** rebuild Atlas.
Do **not** add new features.

The goal is to make the existing application reliable and visually correct across desktop and mobile, with a fully functional theme system.

---

# OWNER

The application belongs to:

**Karma Naik**

Use **Karma** naturally in personalized UI such as greetings.

Do not repeatedly display the name.

---

# PRIORITY

Treat these as high-priority bugs.

### P0
- Broken responsive layout
- Content overflowing the viewport
- Navigation becoming unusable
- Theme controls not changing appearance
- Components remaining stuck in one theme
- Theme preference not persisting

### P1
- Inconsistent spacing
- Incorrect mobile hierarchy
- Broken modals/drawers on mobile
- Components with incorrect dark/light styling
- Poor contrast
- Theme flickering
- Incorrect system-theme behavior

Do not work on unrelated features until these issues are resolved.

---

# PHASE 1 — INSPECT BEFORE MODIFYING

**DO NOT immediately start rewriting CSS.**

First inspect the current implementation.

Identify:

- CSS architecture
- Tailwind configuration
- Global styles
- Theme implementation
- Theme provider/store
- Root HTML structure
- App shell
- Navigation
- Layout containers
- Breakpoints
- Responsive utilities
- Component styling
- Modal/drawer implementation
- Tables
- Charts
- Forms
- Cards
- Buttons
- Inputs
- PWA setup

Determine exactly why the current mobile layout and theme system are failing.

---

# PHASE 2 — MOBILE DEBUGGING

Test the application at:

```text
320 × 568
375 × 667
390 × 844
430 × 932
768 × 1024
1024 × 768
1280 × 800
1440 × 900
1920 × 1080
```

Do not assume desktop CSS will automatically produce good mobile UX.

---

## MOBILE RULE 1 — NO HORIZONTAL OVERFLOW

At mobile widths:

```text
320px
375px
390px
430px
```

the application must not unintentionally create horizontal scrolling.

Find the actual cause of overflow.

Check for:

- Fixed widths
- `min-width`
- Oversized cards
- Long text
- Tables
- Charts
- Navigation
- Absolute positioning
- Transforms
- Negative margins
- Fixed-width modals
- Large buttons
- Flex children refusing to shrink
- Grid columns with excessive minimum widths

Do not solve overflow merely with:

```css
overflow-x: hidden;
```

unless it is genuinely appropriate.

Fix the underlying layout.

---

## MOBILE RULE 2 — CONTAINERS

Review all main page containers.

Avoid layouts such as:

```css
width: 1200px;
```

or unnecessarily large minimum widths.

Prefer responsive constraints such as:

```text
width: 100%
max-width: ...
padding: responsive
```

Content should naturally fit the viewport.

---

## MOBILE RULE 3 — GRIDS

Audit every grid.

A desktop layout such as:

```text
4 columns
```

may become:

```text
2 columns
```

and eventually:

```text
1 column
```

on small screens.

Do not force desktop card layouts onto mobile.

---

## MOBILE RULE 4 — FLEXBOX

Look for flex containers where children refuse to shrink.

Pay particular attention to:

```text
min-width
flex-shrink
white-space
overflow
```

Use:

```css
min-width: 0;
```

where appropriate.

---

## MOBILE RULE 5 — NAVIGATION

Inspect the primary navigation.

It must remain usable on mobile.

If the current design uses a sidebar:

Desktop:

```text
Sidebar + Content
```

Mobile should become an appropriate compact mobile navigation pattern, such as a bottom navigation or another pattern already consistent with Atlas.

Do not simply compress a desktop sidebar until it becomes unusable.

---

## MOBILE RULE 6 — HEADER

The mobile header must not:

- Overflow
- Wrap awkwardly
- Push content off-screen
- Contain oversized controls
- Create excessive vertical space

Prioritize:

```text
Page context
Primary action
Essential navigation
```

Everything else can move into menus.

---

## MOBILE RULE 7 — CARDS

Cards must adapt.

Do not force fixed-width desktop cards onto a 320px screen.

Cards should:

- Fit the viewport
- Reflow content
- Reduce secondary information when appropriate
- Maintain readable hierarchy

Do not simply make every card smaller.

---

## MOBILE RULE 8 — TABLES

Tables are a common source of mobile breakage.

For each table determine whether it should:

1. Become a mobile card/list
2. Collapse secondary columns
3. Scroll horizontally only when genuinely necessary

Never create a tiny unreadable table.

---

## MOBILE RULE 9 — MODALS

Audit every modal.

On mobile:

- Fit inside viewport
- Avoid fixed desktop widths
- Allow scrolling when content is long
- Keep actions accessible
- Avoid buttons being pushed below the viewport

A modal should never trap the user in an unusable layout.

---

## MOBILE RULE 10 — FORMS

Forms must work comfortably on mobile.

Check:

- Input width
- Label wrapping
- Date inputs
- Time inputs
- Selects
- Buttons
- Validation messages
- Keyboard behavior

Inputs should generally be full-width within their form container.

---

## MOBILE RULE 11 — TOUCH TARGETS

Interactive controls should be comfortably tappable.

Avoid tiny icon-only buttons unless the control is genuinely obvious and accessible.

Do not sacrifice usability merely to fit more controls on one row.

---

## MOBILE RULE 12 — TYPOGRAPHY

Do not shrink typography excessively.

Mobile should still have:

- Clear page title
- Strong hierarchy
- Readable body text
- Comfortable line height
- Legible numbers

---

## MOBILE RULE 13 — SPACING

Do not simply scale every desktop spacing value down.

Instead establish deliberate mobile spacing:

```text
Less wasted space
+
Enough breathing room
+
Clear hierarchy
```

---

## MOBILE RULE 14 — CHARTS

Charts must not overflow.

Check:

- Width
- Height
- Labels
- Legends
- Tooltips
- Axis text

Charts may need simplified mobile configurations.

---

## MOBILE RULE 15 — REAL DEVICE MENTALITY

Do not judge responsiveness only from browser resizing.

Think about:

- Touch
- Small viewport
- Browser address bar
- Virtual keyboard
- Portrait orientation
- Landscape orientation

---

# PHASE 3 — THEME SYSTEM REPAIR

Atlas must support:

```text
Light
Dark
System
```

The selected theme must actually affect the entire application.

---

## THEME RULE 1 — FIND THE CURRENT SYSTEM

First determine how theme currently works.

Inspect:

- Theme provider
- Zustand stores
- Context
- LocalStorage
- Tailwind configuration
- CSS variables
- `prefers-color-scheme`
- `document.documentElement`
- `<html>` classes
- Component-level colors

Do not create a second competing theme system.

Fix the existing one if possible.

---

## THEME RULE 2 — SINGLE SOURCE OF TRUTH

There must be one authoritative theme state.

Conceptually:

```text
themePreference
    ↓
Light / Dark / System
    ↓
resolvedTheme
    ↓
document
    ↓
CSS
```

Avoid multiple unrelated theme states.

---

## THEME RULE 3 — PERSISTENCE

If Karma selects:

```text
Dark
```

and refreshes the page:

```text
Dark
```

must remain active.

Same for:

```text
Light
System
```

Use local browser persistence.

---

## THEME RULE 4 — SYSTEM MODE

If Karma chooses:

```text
System
```

Atlas should follow:

```text
prefers-color-scheme
```

If the OS changes from light → dark, Atlas should update appropriately.

Do not treat System as simply another static color mode.

---

## THEME RULE 5 — HTML ROOT

Inspect the `<html>` element.

If using Tailwind's class strategy, ensure the theme class is applied consistently to the document root.

For example:

```html
<html class="dark">
```

for dark mode.

Do not randomly apply theme classes to individual components.

---

## THEME RULE 6 — CSS VARIABLES

Prefer semantic design tokens.

Conceptually:

```css
--background
--foreground
--surface
--surface-muted
--border
--primary
--primary-foreground
--muted
--muted-foreground
--success
--warning
--danger
```

Light and dark themes should provide appropriate values.

Do not hardcode dozens of unrelated colors throughout components.

---

## THEME RULE 7 — FIND HARDCODED COLORS

Search the entire codebase for:

```text
bg-white
text-black
bg-black
text-white
border-gray
text-gray
#fff
#ffffff
#000
#000000
rgb(
rgba(
```

Do not blindly replace all of them.

Determine whether each use should instead reference a semantic theme token.

---

## THEME RULE 8 — COMPONENT AUDIT

Test both themes for:

- Background
- Text
- Cards
- Borders
- Buttons
- Inputs
- Dropdowns
- Modals
- Tooltips
- Tables
- Charts
- Navigation
- Empty states
- Loading states
- Error states
- Toasts
- Badges
- Progress indicators

A theme is not working if only the page background changes.

---

## THEME RULE 9 — CONTRAST

Check:

```text
Primary text
Secondary text
Disabled text
Borders
Interactive elements
Error messages
Warning messages
Success messages
```

Dark mode should not simply invert colors.

It should be intentionally designed.

---

## THEME RULE 10 — CHARTS

Charts frequently remain stuck in light mode.

Audit:

- Axis colors
- Grid lines
- Labels
- Tooltip
- Legend
- Data colors
- Backgrounds

Charts must remain readable in both themes.

---

## THEME RULE 11 — IMAGES / ILLUSTRATIONS

Check whether visual assets become awkward in dark mode.

Do not blindly invert images.

---

## THEME RULE 12 — NO FLASH

Avoid an obvious flash of the wrong theme during page load.

If technically appropriate, resolve the saved theme before the application visually renders.

Desired:

```text
Load
↓
Correct theme
```

Not:

```text
Load light
↓
flash
↓
dark
```

---

## THEME RULE 13 — THEME SWITCHER

The theme control itself must work.

Test:

```text
Light
↓
Dark
↓
System
```

and:

```text
Dark
↓
Light
↓
System
```

Every transition should immediately update the application.

---

# PHASE 4 — GLOBAL UI AUDIT

Once the two major problems are fixed, perform a light consistency pass.

Do **not** redesign the whole product.

Check:

- Border radius consistency
- Button heights
- Input heights
- Typography
- Spacing
- Icon sizes
- Shadows
- Surface hierarchy

Fix obvious inconsistencies only.

---

# PHASE 5 — ACCESSIBILITY

Check:

- Keyboard navigation
- Focus states
- Labels
- Contrast
- Screen reader labels
- Touch targets
- Reduced motion

Theme changes must remain accessible.

---

# PHASE 6 — REGRESSION TEST

After the fixes, test:

## Desktop

```text
1024
1280
1440
1920
```

## Mobile

```text
320
375
390
430
```

## Theme

```text
Light
Dark
System
Refresh
Close/reopen
```

## Navigation

```text
Glance
Capture
Tasks
Life
Money
Settings
```

## Core interactions

```text
Create
Edit
Delete
Complete
Search
```

## Persistence

```text
Create data
Refresh
Verify data remains
```

---

# PHASE 7 — DO NOT BREAK FUNCTIONALITY

While fixing responsive design and themes, do not accidentally break:

- IndexedDB
- Tasks
- Habits
- Finance
- Notes
- Reminders
- Search
- Activity
- Backup
- PWA
- Notifications

If a UI change affects a functional module, test that module.

---

# IMPORTANT — NO NEW FEATURES

For this pass:

DO NOT add:

- New modules
- New dashboards
- New AI features
- New integrations
- New backend
- New paid services
- New authentication
- New command system

This pass is about:

# FIX → POLISH → VERIFY

---

# FINAL QUALITY BAR

Do not stop when:

> "It doesn't overflow anymore."

Stop when:

> "The application feels genuinely responsive and intentional."

Do not stop when:

> "The theme button changes the background."

Stop when:

> "Every important component looks correct in Light, Dark, and System mode."

---

# FINAL REPORT

When finished, report:

## MOBILE

- Problems found
- Problems fixed
- Breakpoints tested
- Remaining limitations

## THEME

- Root cause
- Theme architecture used
- Light mode status
- Dark mode status
- System mode status
- Persistence status

## REGRESSION

- Core features tested
- Any remaining bugs

## FILES CHANGED

List the important files changed and briefly explain why.

Do not claim a test was performed if it was not actually performed.

---

# START

Begin by inspecting the existing application.

Do not rewrite it.

Identify the root causes of:

1. Mobile layout distortion
2. Theme switching failure

Then fix those issues systematically.

Only after they are genuinely resolved should you perform minor UI consistency polish.

The goal is not to make Atlas look different.

The goal is to make the **existing Atlas experience work properly.**
