# ATLAS ARCHITECTURE

## System Overview

```text
                     PROJECT ATLAS
                           │
                     GitHub Pages
                           │
                  React + TypeScript
                           │
                         Vite
                           │
          ┌────────────────┼────────────────┐
          │                │                │
        UI Layer       Domain Logic      Storage
          │                │                │
        React          Atlas Services    Dexie.js
          │                │                │
        Zustand       Business Rules    IndexedDB
```

## Core Principles
1. **Local-First**: All data stays inside IndexedDB in the user's browser.
2. **Zero Latency**: Actions resolve in < 5ms without network calls.
3. **No Mandatory Backend**: Deploys statically to GitHub Pages.
4. **Button/Form Driven**: Predictable, transparent user controls.
