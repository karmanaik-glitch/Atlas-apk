# ATLAS DESIGN SYSTEM

## Color Tokens

- **Background**: `#090a0f` (Calm Obsidian Dark)
- **Surface**: `#12141d`
- **Card**: `#161926`
- **Border**: `#24283b`
- **Zero Latency Accent**: `#10b981` (Emerald Green)
- **Primary Accent**: `#6366f1` (Indigo Blue)

## Typography

- **Body & Headlines**: `Inter`
- **Code, Data & Numbers**: `JetBrains Mono`

## Interaction Rules
- All save actions must feel instant.
- Destructive actions require explicit confirmation modals.
- Glassmorphism is used with restraint (`backdrop-filter: blur(12px)`).
