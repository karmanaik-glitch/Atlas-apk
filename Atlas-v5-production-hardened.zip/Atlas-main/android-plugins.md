# Atlas native capability matrix

| Capability | Web/PWA | Android | Notes |
|---|---:|---:|---|
| Haptics | — | ✓ | Capacitor Haptics |
| System share | ✓ | ✓ | Web Share / Capacitor Share |
| Local notifications | Browser API | ✓ | Capacitor Local Notifications |
| Deep links | URL routing | ✓ | `appUrlOpen` boundary |
| App lifecycle | — | ✓ | Capacitor App |
| Preferences | local storage | ✓ | Capacitor Preferences |
| Biometrics | — | ready | Requires a native biometric provider |

## Biometric release option

The current open source project keeps the biometric boundary provider-neutral. If you want production biometric unlock, install a maintained Capacitor biometric provider and implement the two functions in `src/core/services/biometricService.ts`.

Capawesome's current Biometrics plugin supports Android/iOS, fingerprint/face/iris, and device-credential fallback, but its distribution currently requires the Capawesome Insiders registry/license.
