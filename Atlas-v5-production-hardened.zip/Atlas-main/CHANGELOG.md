# Atlas 3.0

## Product experience overhaul

- Reframed Atlas around a personal command-center model rather than a generic dashboard.
- Redesigned Tasks as an execution queue with Today / Inbox / Upcoming / Done views.
- Redesigned Habits as a consistency board with progress and streak emphasis.
- Redesigned Money as a financial cockpit with spending context, budgets, and subscriptions.
- Redesigned Life as a lightweight personal inventory for goals, waiting, shopping, assets, notes, and reminders.
- Rebuilt Quick Capture around a single-action composer.
- Rebuilt Search as a universal local index.
- Unified mobile navigation around a thumb-friendly command bar.
- Reworked visual language to remove excessive glass, gradients, neon accents, and template-like cards.
- Preserved Dexie / IndexedDB local-first data architecture.
- Fixed the hard-coded Overview date.
- Android / PWA packaging remains part of the release path.

## Validation note

The project was statically reviewed in the provided environment. Dependency installation and a final TypeScript/Vite build could not be completed because the package registry connection timed out in this environment. GitHub Actions is configured to perform the reproducible install/build.

## 5.0.0 — Production Hardening
- Added explicit Dexie schema v5 migration boundary.
- Added validated, checksummed backup/restore service.
- Added atomic restore protection and 25 MB backup guard.
- Added React error recovery boundary.
- Added reduced-motion and focus-visible accessibility baseline.
- Added CI quality gate for typecheck and production builds.
- Added production readiness/release checklist.
