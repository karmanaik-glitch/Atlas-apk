/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        atlas: {
          bg: 'var(--bg-color)',
          surface: 'var(--surface-color)',
          'surface-hover': 'var(--surface-hover-color)',
          card: 'var(--card-color)',
          border: 'var(--border-color)',
          text: 'var(--text-color)',
          muted: 'var(--muted-color)',
          accent: 'var(--accent-color)',
          primary: '#171815',
          highlight: '#b8f34a',
        },
      },
      gridTemplateColumns: {
        '14': 'repeat(14, minmax(0, 1fr))',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
        mono: ['JetBrains Mono', 'Menlo', 'monospace'],
      },
      boxShadow: {
        soft: '0 12px 36px rgba(0, 0, 0, 0.08)',
      },
    },
  },
  plugins: [],
};
